"""
output.py - عرض النتائج باستخدام Rich
========================================
S1  Console singleton
S2  Severity colorizers
S3  Banner + connection status
S4  Scan results router
S5  Hosts table
S6  Services table
S7  Warnings panel
S8  Summary dashboard
S9  Modules list table
S10 Export JSON
S11 Export CSV
S12 Progress bar factory
"""

import csv
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

from rich import box
from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from msf_ot.scanner import HostResult, ScanResult, ScanStatus

logger = logging.getLogger(__name__)
console = Console()


# S2 - Severity Colorizers

_CRITICAL_PORTS: set[int] = {23, 102, 502, 20000, 44818, 2404, 18245, 9600, 1200}
_HIGH_PORTS: set[int] = {21, 22, 25, 80, 135, 443, 445, 1911, 4840, 34964, 47808}


def colorize_port(port: int) -> Text:
    text = Text(str(port))
    if port in _CRITICAL_PORTS:
        text.stylize("bold red")
    elif port in _HIGH_PORTS:
        text.stylize("bold yellow")
    else:
        text.stylize("bright_green")
    return text


def colorize_status(status: str) -> Text:
    text = Text(status)
    s = status.lower()
    if s in ("alive", "up", "open"):
        text.stylize("bold green")
    elif s in ("down", "closed"):
        text.stylize("dim red")
    elif s in ("filtered", "unknown"):
        text.stylize("yellow")
    else:
        text.stylize("dim white")
    return text


def colorize_risk(risk: str) -> Text:
    text = Text(risk.upper() if risk else "-")
    r = risk.lower() if risk else ""
    if r == "critical":
        text.stylize("bold red on dark_red")
    elif r == "high":
        text.stylize("bold red")
    elif r == "medium":
        text.stylize("bold yellow")
    elif r == "low":
        text.stylize("green")
    else:
        text.stylize("dim")
    return text


def colorize_scan_status(status: ScanStatus) -> Text:
    mapping = {
        ScanStatus.COMPLETED: ("COMPLETED", "bold green"),
        ScanStatus.DRY_RUN:   ("DRY-RUN",   "bold yellow"),
        ScanStatus.RUNNING:   ("RUNNING",   "bold cyan"),
        ScanStatus.FAILED:    ("FAILED",    "bold red"),
        ScanStatus.BLOCKED:   ("BLOCKED",   "bold red"),
        ScanStatus.TIMEOUT:   ("TIMEOUT",   "bold orange3"),
        ScanStatus.PENDING:   ("PENDING",   "dim"),
    }
    label, style = mapping.get(status, (status.name, "white"))
    return Text(label, style=style)


# S3 - Banner + Connection Status

def print_banner() -> None:
    console.print()
    console.print(
        "[bold cyan]"
        "  ███╗   ███╗███████╗███████╗      ██████╗ ████████╗\n"
        "  ████╗ ████║██╔════╝██╔════╝     ██╔═══██╗╚══██╔══╝\n"
        "  ██╔████╔██║███████╗█████╗       ██║   ██║   ██║   \n"
        "  ██║╚██╔╝██║╚════██║██╔══╝       ██║   ██║   ██║   \n"
        "  ██║ ╚═╝ ██║███████║██║          ╚██████╔╝   ██║   \n"
        "  ╚═╝     ╚═╝╚══════╝╚═╝           ╚═════╝    ╚═╝   "
        "[/bold cyan]"
    )
    console.print(
        "[bold yellow]  🛡️  Metasploit OT Security CLI — Scanner Only Mode[/bold yellow]"
    )
    console.print(
        "[dim]  ⚠️  For isolated lab environments only. "
        "Never use on live OT systems.[/dim]"
    )
    console.print(
        "[dim]  Developed by [bold white]Ibtisam Alsharafi[/bold white][/dim]"
    )
    console.print()


def print_connection_status(
    host: str,
    port: int,
    version: dict,
    dry_run: bool,
    jobs: int = 0,
    sessions: int = 0,
    db_ok: bool = False,
) -> None:
    mode = "[bold red]DRY-RUN[/bold red]" if dry_run else "[bold green]LIVE[/bold green]"
    msf_ver = version.get("version", "unknown") if isinstance(version, dict) else str(version)
    ruby_ver = version.get("ruby", "") if isinstance(version, dict) else ""
    db_badge = "[green]Connected[/green]" if db_ok else "[dim]Not connected[/dim]"

    body = (
        f"[green]Connected[/green] to [bold cyan]{host}:{port}[/bold cyan]\n"
        f"MSF Version : [yellow]{msf_ver}[/yellow]"
    )
    if ruby_ver:
        body += f"  |  Ruby: [dim]{ruby_ver}[/dim]"
    body += (
        f"\nMode        : {mode}\n"
        f"Database    : {db_badge}\n"
        f"Active Jobs : [yellow]{jobs}[/yellow]   "
        f"Sessions: [yellow]{sessions}[/yellow]"
    )
    console.print(Panel(body, title="[bold]Connection Status[/bold]", border_style="green", padding=(0, 2)))


# S4 - Scan Results Router

def print_scan_results(result: ScanResult) -> None:
    console.print()
    if result.status == ScanStatus.DRY_RUN:
        _print_dry_run(result)
    elif result.status == ScanStatus.BLOCKED:
        _print_blocked(result)
    elif result.status == ScanStatus.FAILED:
        _print_failed(result)
    else:
        _print_completed(result)
    if result.warnings:
        print_warnings(result.warnings)


def _print_dry_run(result: ScanResult) -> None:
    console.print(Panel(
        f"[yellow]DRY-RUN MODE[/yellow]\n\n"
        f"Module : [cyan]{result.module}[/cyan]\n"
        f"Target : [cyan]{result.target}[/cyan]\n"
        f"Ports  : [dim]{result.ports or 'default'}[/dim]\n\n"
        f"[dim]لتشغيل المسح الحقيقي: عين OT_DRY_RUN=false في .env[/dim]",
        title="[bold yellow]Dry-Run Simulation[/bold yellow]",
        border_style="yellow",
        padding=(0, 2),
    ))


def _print_blocked(result: ScanResult) -> None:
    console.print(Panel(
        f"[bold red]{result.error or 'تم حظر العملية بواسطة OT Safety'}[/bold red]",
        title="[bold red]Blocked by OT Safety[/bold red]",
        border_style="red",
        padding=(0, 2),
    ))


def _print_failed(result: ScanResult) -> None:
    console.print(Panel(
        f"[red]{result.error or 'حدث خطا غير معروف'}[/red]",
        title="[bold red]Scan Failed[/bold red]",
        border_style="red",
        padding=(0, 2),
    ))


def _print_completed(result: ScanResult) -> None:
    timeout_note = "\n[yellow]Timeout - النتائج قد تكون جزئية[/yellow]" if result.status == ScanStatus.TIMEOUT else ""
    console.print(Panel(
        f"Module   : [cyan]{result.module}[/cyan]\n"
        f"Target   : [cyan]{result.target}[/cyan]\n"
        f"Status   : {colorize_scan_status(result.status)}\n"
        f"Hosts    : [bold green]{result.host_count}[/bold green] found  "
        f"([bold]{result.ot_host_count}[/bold] with OT services)\n"
        f"Services : [bold]{result.service_count}[/bold] total\n"
        f"Duration : [yellow]{result.duration:.1f}s[/yellow]" + timeout_note,
        title="[bold]Scan Summary[/bold]",
        border_style="cyan",
        padding=(0, 2),
    ))
    if not result.hosts:
        console.print("[dim]  No hosts discovered.[/dim]\n")
        return
    print_hosts_table(result.hosts)
    for host in result.hosts:
        if host.services:
            print_services_table(host)


# S5 - Hosts Table

def print_hosts_table(hosts: list[HostResult]) -> None:
    table = Table(
        title="Discovered Hosts",
        box=box.ROUNDED,
        border_style="cyan",
        show_lines=True,
        header_style="bold cyan",
    )
    table.add_column("IP Address", style="bold cyan",  no_wrap=True, min_width=15)
    table.add_column("Hostname",   style="white",      min_width=12)
    table.add_column("OS",         style="yellow",     min_width=10)
    table.add_column("Status",     no_wrap=True,       min_width=8)
    table.add_column("Ports",      justify="center",   min_width=6)
    table.add_column("OT",         justify="center",   min_width=4)
    table.add_column("Risk",       justify="center",   min_width=8)

    for host in hosts:
        ot_badge = "[bold red]OT[/bold red]" if host.has_ot_services else "[dim]-[/dim]"
        table.add_row(
            host.ip,
            host.hostname or "[dim]-[/dim]",
            host.os_name  or "[dim]Unknown[/dim]",
            colorize_status(host.status),
            str(len(host.services)),
            ot_badge,
            colorize_risk(host.risk_level),
        )
    console.print(table)
    console.print()


# S6 - Services Table

def print_services_table(host: HostResult) -> None:
    ot_count = len(host.ot_services)
    title_suffix = f"  [bold red]{ot_count} OT Protocol(s)[/bold red]" if ot_count else ""
    table = Table(
        title=f"Services on [bold cyan]{host.ip}[/bold cyan]{title_suffix}",
        box=box.SIMPLE_HEAVY,
        border_style="blue",
        header_style="bold blue",
        show_lines=False,
    )
    table.add_column("Port",    justify="right", no_wrap=True, min_width=6)
    table.add_column("Proto",   style="dim",     min_width=5)
    table.add_column("State",   no_wrap=True,    min_width=8)
    table.add_column("Service", style="yellow",  min_width=10)
    table.add_column("Version", style="dim white")
    table.add_column("OT Risk", justify="center", min_width=8)

    for svc in host.services:
        table.add_row(
            colorize_port(svc.port),
            svc.protocol,
            colorize_status(svc.state),
            svc.name    or "[dim]-[/dim]",
            svc.version or "[dim]-[/dim]",
            colorize_risk(svc.ot_risk) if svc.is_ot else Text("-", style="dim"),
        )
    console.print(table)
    console.print()


# S7 - Warnings Panel

def print_warnings(warnings: list[str]) -> None:
    if not warnings:
        return
    body = "\n".join(f"  {w}" for w in warnings)
    console.print(Panel(
        body,
        title=f"[bold yellow]Warnings ({len(warnings)})[/bold yellow]",
        border_style="yellow",
        padding=(0, 1),
    ))
    console.print()


# S8 - Summary Dashboard

def print_summary_dashboard(results: list[ScanResult]) -> None:
    if not results:
        return
    console.print(Rule("[bold cyan]Scan Summary Dashboard[/bold cyan]"))
    console.print()

    total_hosts    = sum(r.host_count    for r in results)
    total_services = sum(r.service_count for r in results)
    total_ot_hosts = sum(r.ot_host_count for r in results)
    total_duration = sum(r.duration      for r in results)
    total_warnings = sum(len(r.warnings) for r in results)
    completed = sum(1 for r in results if r.status == ScanStatus.COMPLETED)
    dry_runs  = sum(1 for r in results if r.status == ScanStatus.DRY_RUN)
    failed    = sum(1 for r in results if r.status == ScanStatus.FAILED)
    blocked   = sum(1 for r in results if r.status == ScanStatus.BLOCKED)

    stats = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    stats.add_column("Metric", style="dim")
    stats.add_column("Value",  style="bold")
    stats.add_row("Modules Run",    str(len(results)))
    stats.add_row("Completed",      f"[green]{completed}[/green]")
    stats.add_row("Dry-Run",        f"[yellow]{dry_runs}[/yellow]")
    stats.add_row("Failed",         f"[red]{failed}[/red]")
    stats.add_row("Blocked",        f"[red]{blocked}[/red]")
    stats.add_row("Total Hosts",    f"[cyan]{total_hosts}[/cyan]")
    stats.add_row("OT Hosts",       f"[bold red]{total_ot_hosts}[/bold red]")
    stats.add_row("Total Services", str(total_services))
    stats.add_row("Warnings",       f"[yellow]{total_warnings}[/yellow]")
    stats.add_row("Total Duration", f"[yellow]{total_duration:.1f}s[/yellow]")

    modules_table = Table(
        title="Results per Module",
        box=box.ROUNDED,
        border_style="cyan",
        header_style="bold cyan",
    )
    modules_table.add_column("Module",   style="cyan",  min_width=30)
    modules_table.add_column("Status",   justify="center")
    modules_table.add_column("Hosts",    justify="center")
    modules_table.add_column("OT",       justify="center")
    modules_table.add_column("Duration", justify="right", style="dim")

    for r in results:
        modules_table.add_row(
            r.module.split("/")[-1],
            colorize_scan_status(r.status),
            str(r.host_count),
            f"[bold red]{r.ot_host_count}[/bold red]" if r.ot_host_count else "-",
            f"{r.duration:.1f}s",
        )

    console.print(Columns([
        Panel(stats, title="[bold]Overall Stats[/bold]", border_style="cyan"),
        modules_table,
    ]))
    console.print()


# S9 - Modules List Table

def print_modules_list(modules: list[str], filter_str: str = "") -> None:
    title = "Allowed Scanner Modules (OT-Safe)"
    if filter_str:
        title += f"  [dim]filter: '{filter_str}'[/dim]"

    table = Table(
        title=title,
        box=box.ROUNDED,
        border_style="green",
        header_style="bold green",
        show_lines=False,
    )
    table.add_column("#",        justify="right", style="dim",   width=4)
    table.add_column("Module",   style="cyan",    min_width=45)
    table.add_column("Category", style="yellow",  min_width=12)
    table.add_column("OT",       justify="center", width=5)

    _ot_categories = {"scada", "snmp"}
    for i, mod in enumerate(modules, 1):
        parts    = mod.split("/")
        category = parts[2] if len(parts) > 2 else "general"
        is_ot    = category in _ot_categories
        ot_badge = "[bold red]OT[/bold red]" if is_ot else ""
        table.add_row(str(i), mod, category, ot_badge)

    console.print(table)
    console.print(f"[dim]  Total: {len(modules)} module(s) allowed[/dim]\n")


# S10 - Export JSON

def export_json(
    result: ScanResult,
    output_dir: str = "reports",
    filename: Optional[str] = None,
) -> str:
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_file  = filename or f"{output_dir}/scan_{timestamp}.json"

    data = {
        "meta": {
            "tool"      : "msf-ot-cli",
            "version"   : "1.0.0",
            "timestamp" : timestamp,
            "module"    : result.module,
            "target"    : result.target,
            "ports"     : result.ports,
            "threads"   : result.threads,
            "status"    : result.status.name,
            "duration_s": round(result.duration, 2),
            "dry_run"   : result.dry_run,
            "error"     : result.error,
            "warnings"  : result.warnings,
        },
        "stats": result.summary(),
        "hosts": [
            {
                "ip"      : h.ip,
                "hostname": h.hostname,
                "os"      : h.os_name,
                "status"  : h.status,
                "mac"     : h.mac_addr,
                "risk"    : h.risk_level,
                "has_ot"  : h.has_ot_services,
                "services": [
                    {
                        "port"    : s.port,
                        "protocol": s.protocol,
                        "state"   : s.state,
                        "name"    : s.name,
                        "version" : s.version,
                        "is_ot"   : s.is_ot,
                        "ot_risk" : s.ot_risk,
                    }
                    for s in h.services
                ],
            }
            for h in result.hosts
        ],
    }

    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    size = Path(out_file).stat().st_size
    console.print(f"[green]JSON exported:[/green] [cyan]{out_file}[/cyan]  [dim]({size:,} bytes)[/dim]")
    return out_file


# S11 - Export CSV

def export_csv(
    result: ScanResult,
    output_dir: str = "reports",
    filename: Optional[str] = None,
) -> str:
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_file  = filename or f"{output_dir}/scan_{timestamp}.csv"

    headers = [
        "IP", "Hostname", "OS", "Host Status", "MAC",
        "Port", "Protocol", "State", "Service", "Version",
        "Is OT", "OT Risk",
    ]

    with open(out_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        for h in result.hosts:
            if h.services:
                for s in h.services:
                    writer.writerow([
                        h.ip, h.hostname, h.os_name, h.status, h.mac_addr,
                        s.port, s.protocol, s.state, s.name, s.version,
                        "YES" if s.is_ot else "NO", s.ot_risk or "",
                    ])
            else:
                writer.writerow([h.ip, h.hostname, h.os_name, h.status, h.mac_addr,
                                  "", "", "", "", "", "", ""])

    row_count = sum(max(len(h.services), 1) for h in result.hosts)
    console.print(f"[green]CSV exported:[/green] [cyan]{out_file}[/cyan]  [dim]({row_count} rows)[/dim]")
    return out_file


# S12 - Progress Bar Factory

def create_progress(show_eta: bool = True) -> Progress:
    columns = [
        SpinnerColumn(),
        TextColumn("[bold cyan]{task.description}"),
        BarColumn(bar_width=30),
        TaskProgressColumn(),
    ]
    if show_eta:
        columns += [TimeElapsedColumn(), TextColumn("[dim]/[/dim]"), TimeRemainingColumn()]
    else:
        columns.append(TimeElapsedColumn())
    return Progress(*columns, console=console, transient=False)


def create_multi_progress() -> Progress:
    return Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]{task.description}"),
        BarColumn(bar_width=25),
        MofNCompleteColumn(),
        TimeElapsedColumn(),
        console=console,
        transient=False,
    )
