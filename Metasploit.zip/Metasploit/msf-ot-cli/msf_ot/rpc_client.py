"""
rpc_client.py — الاتصال الكامل بـ Metasploit عبر RPC
======================================================
المسؤوليات:
  § 1  Exceptions مخصصة
  § 2  ConnectionState  — تتبع حالة الاتصال
  § 3  MsfClient        — الـ wrapper الرئيسي
       - connect() مع exponential-backoff retry
       - disconnect() آمن
       - Context manager  (with MsfClient() as msf)
       - ping() / health_check()
       - auto-reconnect عند انقطاع الاتصال
  § 4  Module API       — تحميل وتشغيل الـ modules
  § 5  Job API          — إدارة الـ jobs
  § 6  Session API      — إدارة الـ sessions
  § 7  Database API     — استعلام نتائج المسح
  § 8  Console API      — تنفيذ أوامر MSF console
  § 9  دوال مساعدة
"""

import logging
import time
import threading
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Optional

from pymetasploit3.msfrpc import MsfRpcClient

from msf_ot.config import (
    MSF_HOST, MSF_PORT, MSF_PASSWORD, MSF_SSL, MSF_URI,
)

logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# § 1 — Exceptions
# ══════════════════════════════════════════════════════════════════════════════

class MetasploitRPCError(Exception):
    """خطأ عام في الاتصال أو تنفيذ RPC."""


class ConnectionError(MetasploitRPCError):
    """فشل الاتصال بـ msfrpcd."""


class AuthenticationError(MetasploitRPCError):
    """فشل المصادقة — كلمة مرور خاطئة."""


class ModuleError(MetasploitRPCError):
    """خطأ في تحميل أو تشغيل module."""


class JobError(MetasploitRPCError):
    """خطأ في إدارة الـ jobs."""


class DatabaseError(MetasploitRPCError):
    """خطأ في الوصول لقاعدة بيانات Metasploit."""


# ══════════════════════════════════════════════════════════════════════════════
# § 2 — Connection State
# ══════════════════════════════════════════════════════════════════════════════

class ConnState(Enum):
    DISCONNECTED = auto()
    CONNECTING   = auto()
    CONNECTED    = auto()
    RECONNECTING = auto()
    FAILED       = auto()


@dataclass
class ConnectionInfo:
    """معلومات الاتصال الحالي."""
    host          : str  = ""
    port          : int  = 0
    ssl           : bool = True
    state         : ConnState = ConnState.DISCONNECTED
    connected_at  : Optional[float] = None
    attempts      : int  = 0
    msf_version   : str  = ""
    msf_ruby      : str  = ""
    msf_api       : str  = ""

    @property
    def uptime(self) -> float:
        """وقت الاتصال بالثواني."""
        if self.connected_at:
            return time.monotonic() - self.connected_at
        return 0.0

    @property
    def is_connected(self) -> bool:
        return self.state == ConnState.CONNECTED


# ══════════════════════════════════════════════════════════════════════════════
# § 3 — MsfClient — الـ Wrapper الرئيسي
# ══════════════════════════════════════════════════════════════════════════════

class MsfClient:
    """
    Wrapper احترافي لـ MsfRpcClient يوفر:
    ─────────────────────────────────────
    • Exponential-backoff retry عند فشل الاتصال
    • Auto-reconnect عند انقطاع الاتصال أثناء العمل
    • Context manager  (with MsfClient(...) as msf)
    • Thread-safe connection state
    • Health monitoring مع ping دوري
    • APIs منظمة: modules / jobs / sessions / db / console
    """

    def __init__(
        self,
        host        : str   = MSF_HOST,
        port        : int   = MSF_PORT,
        password    : str   = MSF_PASSWORD,
        ssl         : bool  = MSF_SSL,
        uri         : str   = MSF_URI,
        max_retries : int   = 3,
        retry_delay : float = 2.0,   # ثانية — يتضاعف مع كل محاولة
        timeout     : int   = 30,    # ثانية لكل طلب RPC
    ):
        self.host        = host
        self.port        = port
        self.password    = password
        self.ssl         = ssl
        self.uri         = uri
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.timeout     = timeout

        self._client  : Optional[MsfRpcClient] = None
        self._lock    = threading.Lock()
        self._info    = ConnectionInfo(host=host, port=port, ssl=ssl)

    # ─────────────────────────────────────────────────────────────────────────
    # الاتصال
    # ─────────────────────────────────────────────────────────────────────────

    def connect(self) -> "MsfClient":
        """
        يتصل بـ msfrpcd مع exponential-backoff retry.

        Raises:
            AuthenticationError  — كلمة مرور خاطئة
            ConnectionError      — تعذّر الاتصال بعد كل المحاولات
        """
        with self._lock:
            if self._info.is_connected:
                logger.debug("Already connected — skipping connect()")
                return self

            self._info.state = ConnState.CONNECTING
            last_error: Exception = Exception("Unknown")

            for attempt in range(1, self.max_retries + 1):
                self._info.attempts = attempt
                delay = self.retry_delay * (2 ** (attempt - 1))  # exponential backoff

                logger.info(
                    f"[RPC] Connecting → {self.host}:{self.port} "
                    f"ssl={self.ssl}  attempt={attempt}/{self.max_retries}"
                )

                try:
                    self._client = MsfRpcClient(
                        password = self.password,
                        server   = self.host,
                        port     = self.port,
                        ssl      = self.ssl,
                    )

                    # تحقق فوري من الاتصال وجمع معلومات الإصدار
                    ver = self._client.core.version()
                    self._info.msf_version  = ver.get("version", "")
                    self._info.msf_ruby     = ver.get("ruby", "")
                    self._info.msf_api      = ver.get("api", "")
                    self._info.state        = ConnState.CONNECTED
                    self._info.connected_at = time.monotonic()

                    logger.info(
                        f"[RPC] ✅ Connected — MSF {self._info.msf_version} "
                        f"| Ruby {self._info.msf_ruby} | API {self._info.msf_api}"
                    )
                    return self

                except Exception as e:
                    last_error = e
                    err_str = str(e).lower()

                    # كلمة مرور خاطئة — لا فائدة من إعادة المحاولة
                    if any(k in err_str for k in ("login", "auth", "password", "denied")):
                        self._info.state = ConnState.FAILED
                        raise AuthenticationError(
                            f"❌ فشل المصادقة مع msfrpcd\n"
                            f"   تحقق من MSF_PASSWORD في ملف .env\n"
                            f"   الخطأ: {e}"
                        )

                    logger.warning(f"[RPC] Attempt {attempt} failed: {e}")

                    if attempt < self.max_retries:
                        logger.info(f"[RPC] Retrying in {delay:.1f}s ...")
                        time.sleep(delay)

            self._info.state = ConnState.FAILED
            raise ConnectionError(
                f"❌ تعذّر الاتصال بـ msfrpcd بعد {self.max_retries} محاولات\n"
                f"   تأكد أن msfrpcd يعمل:\n"
                f"     msfrpcd -P {self.password} -a {self.host} -n -f\n"
                f"   الخطأ الأخير: {last_error}"
            )

    def disconnect(self) -> None:
        """يقطع الاتصال بأمان ويُحرر الموارد."""
        with self._lock:
            if self._client:
                try:
                    self._client.logout()
                    logger.info("[RPC] Disconnected from Metasploit.")
                except Exception as e:
                    logger.debug(f"[RPC] Logout error (ignored): {e}")
                finally:
                    self._client = None
                    self._info.state        = ConnState.DISCONNECTED
                    self._info.connected_at = None

    def _ensure_connected(self) -> None:
        """
        يتحقق من الاتصال ويُعيد الاتصال تلقائياً إذا انقطع.
        يُستدعى قبل كل عملية RPC.
        """
        if not self._info.is_connected or not self._client:
            logger.warning("[RPC] Connection lost — attempting reconnect ...")
            self._info.state = ConnState.RECONNECTING
            self._info.connected_at = None
            self._client = None
            self.connect()

    # ─────────────────────────────────────────────────────────────────────────
    # Context Manager
    # ─────────────────────────────────────────────────────────────────────────

    def __enter__(self) -> "MsfClient":
        return self.connect()

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.disconnect()

    # ─────────────────────────────────────────────────────────────────────────
    # Properties
    # ─────────────────────────────────────────────────────────────────────────

    @property
    def info(self) -> ConnectionInfo:
        """يُعيد معلومات الاتصال الحالي."""
        return self._info

    @property
    def raw(self) -> MsfRpcClient:
        """
        يُعيد الـ MsfRpcClient الخام.
        يتصل تلقائياً إذا لم يكن متصلاً.
        """
        self._ensure_connected()
        return self._client  # type: ignore[return-value]

    # ─────────────────────────────────────────────────────────────────────────
    # Health Check
    # ─────────────────────────────────────────────────────────────────────────

    def ping(self) -> bool:
        """
        يتحقق أن الاتصال حي بإرسال طلب version.
        Returns: True إذا كان الاتصال سليماً.
        """
        try:
            self._ensure_connected()
            self._client.core.version()  # type: ignore[union-attr]
            return True
        except Exception as e:
            logger.warning(f"[RPC] Ping failed: {e}")
            self._info.state = ConnState.DISCONNECTED
            return False

    def health_check(self) -> dict:
        """
        يُجري فحصاً شاملاً للاتصال.
        Returns: dict مع تفاصيل الحالة.
        """
        result = {
            "connected"   : False,
            "host"        : self.host,
            "port"        : self.port,
            "ssl"         : self.ssl,
            "msf_version" : "",
            "uptime_s"    : 0.0,
            "jobs_count"  : 0,
            "sessions_count": 0,
            "db_connected": False,
            "error"       : None,
        }

        try:
            self._ensure_connected()

            ver = self._client.core.version()  # type: ignore[union-attr]
            result["connected"]    = True
            result["msf_version"]  = ver.get("version", "")
            result["uptime_s"]     = round(self._info.uptime, 1)

            # Jobs
            try:
                result["jobs_count"] = len(self._client.jobs.list)  # type: ignore[union-attr]
            except Exception:
                pass

            # Sessions
            try:
                result["sessions_count"] = len(self._client.sessions.list)  # type: ignore[union-attr]
            except Exception:
                pass

            # Database
            try:
                db_status = self._client.db.status()  # type: ignore[union-attr]
                result["db_connected"] = db_status.get("db", "") == "connected"
            except Exception:
                result["db_connected"] = False

        except Exception as e:
            result["error"] = str(e)
            logger.error(f"[RPC] Health check failed: {e}")

        return result


# ══════════════════════════════════════════════════════════════════════════════
# § 4 — Module API
# ══════════════════════════════════════════════════════════════════════════════

    def get_version(self) -> dict:
        """يُعيد معلومات إصدار Metasploit."""
        try:
            self._ensure_connected()
            return self._client.core.version()  # type: ignore[union-attr]
        except Exception as e:
            raise MetasploitRPCError(f"get_version failed: {e}") from e

    def list_auxiliary_modules(self) -> list[str]:
        """
        يُعيد قائمة كل الـ auxiliary modules المتاحة في MSF.
        مفيد للتحقق أن الـ module موجود قبل تشغيله.
        """
        try:
            self._ensure_connected()
            return list(self._client.modules.auxiliary)  # type: ignore[union-attr]
        except Exception as e:
            raise ModuleError(f"list_auxiliary_modules failed: {e}") from e

    def module_info(self, module_type: str, module_name: str) -> dict:
        """
        يُعيد معلومات module معين (الخيارات، الوصف، المؤلف).

        Args:
            module_type: 'auxiliary'
            module_name: 'scanner/portscan/tcp'
        """
        try:
            self._ensure_connected()
            mod = self._client.modules.use(module_type, module_name)  # type: ignore[union-attr]
            return {
                "name"        : mod.name,
                "description" : mod.description,
                "options"     : mod.options,
                "required"    : mod.required,
                "author"      : getattr(mod, "authors", []),
            }
        except Exception as e:
            raise ModuleError(
                f"module_info failed for '{module_type}/{module_name}': {e}"
            ) from e

    def load_module(self, module_type: str, module_name: str) -> Any:
        """
        يحمّل module ويُعيد الـ object الخاص به.

        Args:
            module_type: 'auxiliary'
            module_name: 'scanner/portscan/tcp'

        Returns:
            MsfModule object جاهز لضبط الخيارات والتشغيل.

        Raises:
            ModuleError
        """
        try:
            self._ensure_connected()
            logger.debug(f"[RPC] Loading module: {module_type}/{module_name}")
            mod = self._client.modules.use(module_type, module_name)  # type: ignore[union-attr]
            return mod
        except Exception as e:
            raise ModuleError(
                f"❌ فشل تحميل module '{module_type}/{module_name}'\n"
                f"   تأكد أن الـ module موجود في MSF\n"
                f"   الخطأ: {e}"
            ) from e

    def execute_module(
        self,
        module_type : str,
        module_name : str,
        options     : dict,
    ) -> str:
        """
        يحمّل module، يضبط خياراته، ويشغّله.

        Args:
            module_type: 'auxiliary'
            module_name: 'scanner/portscan/tcp'
            options:     {'RHOSTS': '192.168.1.0/24', 'PORTS': '1-1024', ...}

        Returns:
            job_id كـ string

        Raises:
            ModuleError
        """
        try:
            mod = self.load_module(module_type, module_name)

            # ضبط الخيارات
            for key, value in options.items():
                try:
                    mod[key] = value
                except Exception as e:
                    logger.warning(f"[RPC] Could not set option {key}={value}: {e}")

            # تشغيل الـ module
            logger.info(
                f"[RPC] Executing {module_type}/{module_name} "
                f"with options: {options}"
            )
            result = mod.execute(payload=None)

            # استخراج job_id
            if isinstance(result, dict):
                job_id = str(result.get("job_id", result.get("uuid", "0")))
            else:
                job_id = str(result)

            logger.info(f"[RPC] Module started — job_id={job_id}")
            return job_id

        except ModuleError:
            raise
        except Exception as e:
            raise ModuleError(
                f"execute_module failed for '{module_type}/{module_name}': {e}"
            ) from e


# ══════════════════════════════════════════════════════════════════════════════
# § 5 — Job API
# ══════════════════════════════════════════════════════════════════════════════

    def get_jobs(self) -> dict:
        """يُعيد الـ jobs النشطة حالياً {job_id: info}."""
        try:
            self._ensure_connected()
            return dict(self._client.jobs.list)  # type: ignore[union-attr]
        except Exception as e:
            raise JobError(f"get_jobs failed: {e}") from e

    def is_job_running(self, job_id: str) -> bool:
        """يتحقق إذا كان job معين لا يزال يعمل."""
        try:
            jobs = self.get_jobs()
            return job_id in jobs
        except Exception:
            return False

    def wait_for_job(
        self,
        job_id  : str,
        timeout : int = 30,
        interval: float = 1.0,
    ) -> bool:
        """
        ينتظر حتى ينتهي job أو يتجاوز الـ timeout.

        Args:
            job_id:   معرّف الـ job
            timeout:  أقصى وقت انتظار بالثواني
            interval: فترة الفحص بالثواني

        Returns:
            True  إذا انتهى الـ job بنجاح
            False إذا انتهى الـ timeout
        """
        deadline = time.monotonic() + timeout
        logger.debug(f"[RPC] Waiting for job {job_id} (timeout={timeout}s)")

        while time.monotonic() < deadline:
            if not self.is_job_running(job_id):
                logger.info(f"[RPC] Job {job_id} completed.")
                return True
            time.sleep(interval)

        logger.warning(f"[RPC] Job {job_id} timed out after {timeout}s.")
        return False

    def stop_job(self, job_id: str) -> bool:
        """يوقف job نشط."""
        try:
            self._ensure_connected()
            self._client.jobs.stop(job_id)  # type: ignore[union-attr]
            logger.info(f"[RPC] Job {job_id} stopped.")
            return True
        except Exception as e:
            logger.warning(f"[RPC] Could not stop job {job_id}: {e}")
            return False

    def stop_all_jobs(self) -> int:
        """يوقف كل الـ jobs النشطة. Returns: عدد الـ jobs التي أُوقفت."""
        stopped = 0
        try:
            jobs = self.get_jobs()
            for job_id in list(jobs.keys()):
                if self.stop_job(str(job_id)):
                    stopped += 1
        except Exception as e:
            logger.warning(f"[RPC] stop_all_jobs error: {e}")
        return stopped


# ══════════════════════════════════════════════════════════════════════════════
# § 6 — Session API
# ══════════════════════════════════════════════════════════════════════════════

    def get_sessions(self) -> dict:
        """يُعيد الـ sessions النشطة {session_id: info}."""
        try:
            self._ensure_connected()
            return dict(self._client.sessions.list)  # type: ignore[union-attr]
        except Exception as e:
            raise MetasploitRPCError(f"get_sessions failed: {e}") from e

    def kill_session(self, session_id: str) -> bool:
        """يُنهي session نشط."""
        try:
            self._ensure_connected()
            self._client.sessions.session(session_id).stop()  # type: ignore[union-attr]
            logger.info(f"[RPC] Session {session_id} killed.")
            return True
        except Exception as e:
            logger.warning(f"[RPC] Could not kill session {session_id}: {e}")
            return False


# ══════════════════════════════════════════════════════════════════════════════
# § 7 — Database API
# ══════════════════════════════════════════════════════════════════════════════

    def db_status(self) -> dict:
        """يُعيد حالة قاعدة بيانات Metasploit."""
        try:
            self._ensure_connected()
            return self._client.db.status()  # type: ignore[union-attr]
        except Exception as e:
            raise DatabaseError(f"db_status failed: {e}") from e

    def db_hosts(self, workspace: str = "default") -> list[dict]:
        """
        يُعيد قائمة الـ hosts المكتشفة في قاعدة البيانات.

        Args:
            workspace: اسم الـ workspace في MSF (افتراضي: 'default')
        """
        try:
            self._ensure_connected()
            result = self._client.db.hosts({})  # type: ignore[union-attr]
            return result.get("hosts", [])
        except Exception as e:
            raise DatabaseError(f"db_hosts failed: {e}") from e

    def db_services(self, host_ip: Optional[str] = None) -> list[dict]:
        """
        يُعيد قائمة الـ services المكتشفة.

        Args:
            host_ip: إذا محدد يُعيد services هذا الـ host فقط
        """
        try:
            self._ensure_connected()
            opts: dict = {}
            if host_ip:
                opts["hosts"] = [host_ip]
            result = self._client.db.services(opts)  # type: ignore[union-attr]
            return result.get("services", [])
        except Exception as e:
            raise DatabaseError(f"db_services failed: {e}") from e

    def db_vulns(self, host_ip: Optional[str] = None) -> list[dict]:
        """يُعيد قائمة الثغرات المكتشفة."""
        try:
            self._ensure_connected()
            opts: dict = {}
            if host_ip:
                opts["hosts"] = [host_ip]
            result = self._client.db.vulns(opts)  # type: ignore[union-attr]
            return result.get("vulns", [])
        except Exception as e:
            raise DatabaseError(f"db_vulns failed: {e}") from e

    def db_clear_hosts(self) -> bool:
        """يمسح كل الـ hosts من قاعدة البيانات (للاختبار فقط)."""
        try:
            self._ensure_connected()
            self._client.db.del_hosts({})  # type: ignore[union-attr]
            logger.info("[RPC] DB hosts cleared.")
            return True
        except Exception as e:
            logger.warning(f"[RPC] db_clear_hosts failed: {e}")
            return False


# ══════════════════════════════════════════════════════════════════════════════
# § 8 — Console API
# ══════════════════════════════════════════════════════════════════════════════

    def console_create(self) -> str:
        """يُنشئ console جديد ويُعيد الـ console_id."""
        try:
            self._ensure_connected()
            result = self._client.consoles.console()  # type: ignore[union-attr]
            console_id = str(result.cid)
            logger.debug(f"[RPC] Console created: id={console_id}")
            return console_id
        except Exception as e:
            raise MetasploitRPCError(f"console_create failed: {e}") from e

    def console_run(self, command: str, console_id: Optional[str] = None) -> str:
        """
        يُشغّل أمر في MSF console ويُعيد الناتج.

        Args:
            command:    الأمر مثل 'version' أو 'show modules'
            console_id: إذا None يُنشئ console جديد تلقائياً

        Returns:
            ناتج الأمر كـ string
        """
        cid = console_id or self.console_create()
        try:
            self._ensure_connected()
            console = self._client.consoles.console(cid)  # type: ignore[union-attr]
            console.write(command + "\n")

            # انتظر حتى ينتهي التنفيذ
            output = ""
            deadline = time.monotonic() + 15
            while time.monotonic() < deadline:
                data = console.read()
                output += data.get("data", "")
                if not data.get("busy", True):
                    break
                time.sleep(0.3)

            return output.strip()

        except Exception as e:
            raise MetasploitRPCError(f"console_run failed: {e}") from e
        finally:
            # أغلق الـ console إذا أنشأناه نحن
            if not console_id:
                try:
                    self._client.consoles.destroy(cid)  # type: ignore[union-attr]
                except Exception:
                    pass


# ══════════════════════════════════════════════════════════════════════════════
# § 9 — دوال مساعدة
# ══════════════════════════════════════════════════════════════════════════════

    def __repr__(self) -> str:
        state = self._info.state.name
        return (
            f"MsfClient("
            f"host={self.host!r}, port={self.port}, "
            f"ssl={self.ssl}, state={state})"
        )

    def __str__(self) -> str:
        if self._info.is_connected:
            return (
                f"MsfClient → {self.host}:{self.port} "
                f"[MSF {self._info.msf_version}] "
                f"uptime={self._info.uptime:.0f}s"
            )
        return f"MsfClient → {self.host}:{self.port} [DISCONNECTED]"
