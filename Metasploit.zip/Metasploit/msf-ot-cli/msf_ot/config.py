"""
config.py — تحميل وتحقق الإعدادات من .env
===========================================
المسؤوليات:
  - تحميل متغيرات البيئة من .env
  - التحقق من صحة القيم (validation)
  - تعريف القوائم البيضاء والسوداء
  - إعدادات بروتوكولات OT
"""

import os
import sys
import ipaddress
import logging
from pathlib import Path
from typing import NamedTuple
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

# ─── تحميل .env (يبحث من المجلد الحالي للأعلى) ──────────────────────────────
_env_path = Path(__file__).parent.parent / ".env"
load_dotenv(dotenv_path=_env_path)


# ══════════════════════════════════════════════════════════════════════════════
# § 1 — إعدادات الاتصال بـ Metasploit RPC
# ══════════════════════════════════════════════════════════════════════════════

MSF_HOST     : str  = os.getenv("MSF_HOST", "127.0.0.1")
MSF_PORT     : int  = int(os.getenv("MSF_PORT", "55553"))
MSF_PASSWORD : str  = os.getenv("MSF_PASSWORD", "")
MSF_SSL      : bool = os.getenv("MSF_SSL", "true").lower() == "true"
MSF_URI      : str  = os.getenv("MSF_URI", "/api/")


# ══════════════════════════════════════════════════════════════════════════════
# § 2 — إعدادات الأمان العامة
# ══════════════════════════════════════════════════════════════════════════════

OT_DRY_RUN      : bool = os.getenv("OT_DRY_RUN", "true").lower() == "true"
OT_RATE_LIMIT   : int  = int(os.getenv("OT_RATE_LIMIT", "5"))      # طلبات/ثانية
OT_SCAN_TIMEOUT : int  = int(os.getenv("OT_SCAN_TIMEOUT", "30"))   # ثانية
OT_MAX_THREADS  : int  = int(os.getenv("OT_MAX_THREADS", "10"))    # حد أقصى للـ threads
OT_INTER_PACKET_DELAY: float = float(os.getenv("OT_INTER_PACKET_DELAY", "0.1"))  # تأخير بين الحزم


# ══════════════════════════════════════════════════════════════════════════════
# § 3 — نطاقات IP
# ══════════════════════════════════════════════════════════════════════════════

def _parse_cidr_list(env_var: str, default: str = "") -> list[str]:
    """يحلّل قائمة CIDR من متغير بيئة."""
    raw = os.getenv(env_var, default)
    result = []
    for item in raw.split(","):
        item = item.strip()
        if not item:
            continue
        try:
            ipaddress.ip_network(item, strict=False)
            result.append(item)
        except ValueError:
            logger.warning(f"[config] Invalid CIDR in {env_var}: '{item}' — skipped")
    return result


# نطاقات OT المحظورة (PLC, SCADA, DCS)
OT_BLACKLIST_RANGES: list[str] = _parse_cidr_list(
    "OT_BLACKLIST_RANGES",
    # افتراضي: نطاقات OT شائعة يجب حمايتها
    "192.168.100.0/24,172.16.0.0/12"
)

# نطاقات مسموح بمسحها (فارغ = كل شيء غير محظور مسموح)
OT_ALLOWED_RANGES: list[str] = _parse_cidr_list("OT_ALLOWED_RANGES")

# نطاقات OT المعروفة للتحذير (ليست محظورة لكن تستدعي تأكيداً)
OT_WARN_RANGES: list[str] = _parse_cidr_list(
    "OT_WARN_RANGES",
    "10.0.0.0/8,172.16.0.0/12,192.168.0.0/16"
)


# ══════════════════════════════════════════════════════════════════════════════
# § 4 — بروتوكولات OT وأرقام منافذها
# ══════════════════════════════════════════════════════════════════════════════

class OTProtocol(NamedTuple):
    name       : str
    port       : int
    transport  : str   # tcp / udp
    risk_level : str   # critical / high / medium
    description: str


OT_PROTOCOLS: list[OTProtocol] = [
    OTProtocol("Modbus",        502,   "tcp", "critical", "Modbus TCP — PLC communication"),
    OTProtocol("DNP3",          20000, "tcp", "critical", "DNP3 — SCADA/RTU protocol"),
    OTProtocol("DNP3-UDP",      20000, "udp", "critical", "DNP3 over UDP"),
    OTProtocol("EtherNet/IP",   44818, "tcp", "critical", "EtherNet/IP — Allen-Bradley PLCs"),
    OTProtocol("EtherNet/IP-U", 2222,  "udp", "high",     "EtherNet/IP UDP"),
    OTProtocol("S7comm",        102,   "tcp", "critical", "Siemens S7 — S7-300/400/1200/1500"),
    OTProtocol("PROFINET",      34964, "udp", "high",     "PROFINET IO"),
    OTProtocol("BACnet",        47808, "udp", "high",     "BACnet — Building automation"),
    OTProtocol("IEC-104",       2404,  "tcp", "critical", "IEC 60870-5-104 — SCADA"),
    OTProtocol("OPC-DA",        135,   "tcp", "high",     "OPC DA — Windows DCOM"),
    OTProtocol("OPC-UA",        4840,  "tcp", "medium",   "OPC UA — Modern SCADA"),
    OTProtocol("ICCP",          102,   "tcp", "high",     "ICCP — Inter-control center"),
    OTProtocol("GE-SRTP",       18245, "tcp", "critical", "GE SRTP — GE PLCs"),
    OTProtocol("Crimson-v3",    789,   "tcp", "high",     "Red Lion Crimson v3"),
    OTProtocol("FINS",          9600,  "udp", "critical", "OMRON FINS — OMRON PLCs"),
    OTProtocol("Niagara-Fox",   1911,  "tcp", "medium",   "Tridium Niagara Fox"),
    OTProtocol("Codesys",       1200,  "tcp", "critical", "CODESYS runtime"),
]

# فهرس سريع: port → OTProtocol
OT_PORT_MAP: dict[int, OTProtocol] = {p.port: p for p in OT_PROTOCOLS}

# المنافذ الحرجة التي تستدعي تحذيراً خاصاً
OT_CRITICAL_PORTS: set[int] = {
    p.port for p in OT_PROTOCOLS if p.risk_level == "critical"
}


# ══════════════════════════════════════════════════════════════════════════════
# § 5 — قائمة الـ Modules المسموحة (Whitelist)
# ══════════════════════════════════════════════════════════════════════════════

ALLOWED_MODULES: list[str] = [

    # ── Port Scanners ─────────────────────────────────────────────────────────
    "auxiliary/scanner/portscan/tcp",
    "auxiliary/scanner/portscan/syn",
    "auxiliary/scanner/portscan/udp",
    "auxiliary/scanner/portscan/ack",
    "auxiliary/scanner/portscan/xmas",

    # ── Discovery ─────────────────────────────────────────────────────────────
    "auxiliary/scanner/discovery/arp_sweep",
    "auxiliary/scanner/discovery/udp_sweep",
    "auxiliary/scanner/discovery/udp_probe",
    "auxiliary/scanner/discovery/ipv6_neighbor",

    # ── SMB (Windows / HMI) ───────────────────────────────────────────────────
    "auxiliary/scanner/smb/smb_version",
    "auxiliary/scanner/smb/smb_enumshares",
    "auxiliary/scanner/smb/smb_ms17_010",       # detection only — no exploit

    # ── HTTP (Web HMI / SCADA Web) ────────────────────────────────────────────
    "auxiliary/scanner/http/http_version",
    "auxiliary/scanner/http/title",
    "auxiliary/scanner/http/options",
    "auxiliary/scanner/http/robots_txt",

    # ── FTP (Historian / File servers) ────────────────────────────────────────
    "auxiliary/scanner/ftp/ftp_version",
    "auxiliary/scanner/ftp/anonymous",

    # ── SSH ───────────────────────────────────────────────────────────────────
    "auxiliary/scanner/ssh/ssh_version",
    "auxiliary/scanner/ssh/ssh_identify_pubkeys",

    # ── Telnet (Legacy OT — HIGH RISK port 23) ────────────────────────────────
    "auxiliary/scanner/telnet/telnet_version",

    # ── SNMP (شائع جداً في OT) ────────────────────────────────────────────────
    "auxiliary/scanner/snmp/snmp_enum",
    "auxiliary/scanner/snmp/snmp_enumusers",
    "auxiliary/scanner/snmp/snmp_enumshares",

    # ── OT / SCADA Protocols ──────────────────────────────────────────────────
    "auxiliary/scanner/scada/modbusdetect",          # Modbus TCP detection
    "auxiliary/scanner/scada/modbus_findunitid",     # Modbus Unit ID enum
    "auxiliary/scanner/scada/dnp3_enumrouter",       # DNP3 router enum
    "auxiliary/scanner/scada/ethernetip_list_identity",  # EtherNet/IP identity
    "auxiliary/scanner/scada/bacnet_device_info",    # BACnet device info

    # ── ICS/SCADA Vulnerability Detection (passive) ───────────────────────────
    "auxiliary/scanner/scada/digi_addp_version",
    "auxiliary/scanner/scada/digi_realport_version",
]

# فهرس سريع للبحث
ALLOWED_MODULES_SET: set[str] = set(ALLOWED_MODULES)


# ══════════════════════════════════════════════════════════════════════════════
# § 6 — قوائم الحظر
# ══════════════════════════════════════════════════════════════════════════════

# بادئات محظورة بالكامل
BLOCKED_MODULE_PREFIXES: list[str] = [
    "exploit/",
    "post/",
    "payload/",
    "encoder/",
    "nop/",
    "evasion/",
]

# كلمات مفتاحية محظورة في اسم الـ module
BLOCKED_MODULE_KEYWORDS: list[str] = [
    "dos",
    "overflow",
    "shellcode",
    "backdoor",
    "rootkit",
    "bruteforce",
    "brute_force",
    "fuzzer",
    "fuzz",
    "crash",
    "denial",
]


# ══════════════════════════════════════════════════════════════════════════════
# § 7 — Config Validator
# ══════════════════════════════════════════════════════════════════════════════

class ConfigValidationError(Exception):
    """يُرفع عند وجود خطأ في الإعدادات."""


def validate_config() -> list[str]:
    """
    يتحقق من صحة جميع الإعدادات.
    Returns: قائمة بالتحذيرات (warnings) — لا تُوقف التشغيل.
    Raises:  ConfigValidationError عند أخطاء حرجة.
    """
    errors   : list[str] = []
    warnings : list[str] = []

    # ── فحص كلمة المرور ───────────────────────────────────────────────────────
    if not MSF_PASSWORD:
        errors.append(
            "MSF_PASSWORD فارغة — أضف كلمة المرور في ملف .env\n"
            "  مثال: MSF_PASSWORD=yourpassword"
        )

    if MSF_PASSWORD and len(MSF_PASSWORD) < 8:
        warnings.append("MSF_PASSWORD قصيرة جداً (أقل من 8 أحرف) — استخدم كلمة مرور أقوى.")

    # ── فحص المنفذ ────────────────────────────────────────────────────────────
    if not (1 <= MSF_PORT <= 65535):
        errors.append(f"MSF_PORT={MSF_PORT} خارج النطاق الصحيح (1-65535).")

    # ── فحص الـ Host ──────────────────────────────────────────────────────────
    try:
        ipaddress.ip_address(MSF_HOST)
    except ValueError:
        # قد يكون hostname وليس IP — تحذير فقط
        warnings.append(f"MSF_HOST='{MSF_HOST}' ليس IP صحيحاً — تأكد أنه hostname صحيح.")

    # ── فحص Timeout ───────────────────────────────────────────────────────────
    if OT_SCAN_TIMEOUT < 5:
        warnings.append(f"OT_SCAN_TIMEOUT={OT_SCAN_TIMEOUT}s قصير جداً — قد تفوتك نتائج.")

    if OT_SCAN_TIMEOUT > 300:
        warnings.append(f"OT_SCAN_TIMEOUT={OT_SCAN_TIMEOUT}s طويل جداً — قد يسبب تأخيراً.")

    # ── فحص Rate Limit ────────────────────────────────────────────────────────
    if OT_RATE_LIMIT > 20:
        warnings.append(
            f"OT_RATE_LIMIT={OT_RATE_LIMIT} مرتفع — قد يُحمّل أجهزة OT الحساسة."
        )

    # ── فحص Threads ───────────────────────────────────────────────────────────
    if OT_MAX_THREADS > 20:
        warnings.append(
            f"OT_MAX_THREADS={OT_MAX_THREADS} مرتفع — خطر على أجهزة OT ذات الموارد المحدودة."
        )

    # ── تحذير Dry-Run ─────────────────────────────────────────────────────────
    if not OT_DRY_RUN:
        warnings.append(
            "⚠️  OT_DRY_RUN=false — وضع التشغيل الحقيقي مفعّل!\n"
            "   تأكد أنك في بيئة معزولة قبل المتابعة."
        )

    # ── رفع الأخطاء الحرجة ────────────────────────────────────────────────────
    if errors:
        raise ConfigValidationError(
            "❌ أخطاء في الإعدادات:\n" +
            "\n".join(f"  • {e}" for e in errors)
        )

    return warnings


# ══════════════════════════════════════════════════════════════════════════════
# § 8 — دالة مساعدة: طباعة ملخص الإعدادات
# ══════════════════════════════════════════════════════════════════════════════

def get_config_summary() -> dict:
    """يُعيد ملخص الإعدادات الحالية (بدون كلمة المرور)."""
    return {
        "msf_host"            : MSF_HOST,
        "msf_port"            : MSF_PORT,
        "msf_ssl"             : MSF_SSL,
        "msf_password_set"    : bool(MSF_PASSWORD),
        "ot_dry_run"          : OT_DRY_RUN,
        "ot_rate_limit"       : OT_RATE_LIMIT,
        "ot_scan_timeout"     : OT_SCAN_TIMEOUT,
        "ot_max_threads"      : OT_MAX_THREADS,
        "blacklist_ranges"    : OT_BLACKLIST_RANGES,
        "allowed_ranges"      : OT_ALLOWED_RANGES,
        "allowed_modules_count": len(ALLOWED_MODULES),
        "ot_protocols_count"  : len(OT_PROTOCOLS),
    }
