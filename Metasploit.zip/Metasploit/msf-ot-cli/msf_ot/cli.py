"""
cli.py — واجهة الأوامر النهائية باستخدام Click
=================================================
الأوامر:
  scan      — تشغيل module مسح على هدف واحد
  multiscan — تشغيل عدة modules على هدف واحد
  modules   — عرض وبحث الـ modules المسموحة
  status    — فحص حالة الاتصال بـ Metasploit
  config    — عرض الإعدادات الحالية
"""

import logging
import sys
from typing import Optional

import click
from rich.console import Console

from msf_ot.config import (
    MSF_HOST, MSF_PORT, MSF_PASSWORD, MSF_SSL,
    OT_DRY_RUN, validate_config, get_config_summary,
    ConfigValidationError,
)
from msf_ot.rpc_client import MsfClient, MetasploitRPCError, AuthenticationError
from msf_ot.scanner import OTScanner
from msf_ot.safety import OTSafetyError
from msf_ot import output

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.WARNING,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger(__name__)
console = Console()


# ══════════════════════════════════════════════════════════════════════════════
# دوال مساعدة
# ══════════════════════════════════════════════════════════════════════════════

def _parse_options(option_tuples: tuple) -> dict:
    """يحلّل خيارات KEY=VALUE من سطر الأوامر."""
    result: dict = {}
    for opt in option_tuples:
        if "=" in opt:
            k, v = opt.split("=", 1)
            result[k.strip().upper()] = v.strip()
        else:
            console.print(
                f"[yellow]  تجاهل خيار غير صحيح: '{opt}' "
                f"(الصيغة الصحيحة: KEY=VALUE)[/yellow]"
            )
    return result


def _make_msf_client(host: str, port: int, password: str, ssl: bool) -> MsfClient:
    """يُنشئ MsfClient بالإعدادات المحددة."""
    return MsfClient(
        host=host,
        port=port,
        password=password or MSF_PASSWORD,
        ssl=ssl,
        max_retries=3,
        retry_delay=2.0,
    )


def _handle_rpc_error(e: Exception) -> None:
    """يعالج أخطاء RPC ويطبع رسالة مناسبة."""
    if isinstance(e, AuthenticationError):
        console.print(
            "\n[bold red]❌ Authentication Failed[/bold red]\n"
            "  تحقق من MSF_PASSWORD في ملف .env\n"
            f"  [dim]{e}[/dim]"
        )
    else:
        console.print(
            f"\n[bold red]❌ RPC Error[/bold red]\n"
            f"  تأكد أن msfrpcd يعمل: [cyan]msfrpcd -P <password> -a 127.0.0.1 -n -f[/cyan]\n"
            f"  [dim]{e}[/dim]"
        )


# ══════════════════════════════════════════════════════════════════════════════
# CLI Group
# ══════════════════════════════════════════════════════════════════════════════

@click.group()
@click.option("--verbose", "-v", is_flag=True, help="تفعيل verbose logging")
@click.option("--no-banner", is_flag=True, help="إخفاء الـ banner")
@click.version_option("1.0.0", prog_name="msf-ot-cli")
@click.pass_context
def cli(ctx: click.Context, verbose: bool, no_banner: bool) -> None:
    """
    Shield  Metasploit OT Security CLI

    أداة مسح آمنة لبيئات OT/ICS — Scanner modules فقط.

    \b
    Warning  للاستخدام في بيئات الاختبار المعزولة فقط.
             لا تستخدم على أنظمة OT حية بدون تصريح رسمي.
    """
    ctx.ensure_object(dict)

    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)
        logging.getLogger("msf_ot").setLevel(logging.DEBUG)
        ctx.obj["verbose"] = True

    if not no_banner:
        output.print_banner()

    # تحقق من الإعدادات عند بدء التشغيل
    try:
        warnings = validate_config()
        if warnings:
            for w in warnings:
                console.print(f"[yellow]  Config Warning: {w}[/yellow]")
    except ConfigValidationError as e:
        console.print(f"[bold red]❌ Config Error:[/bold red]\n{e}")
        sys.exit(1)


# ══════════════════════════════════════════════════════════════════════════════
# الأمر: status
# ══════════════════════════════════════════════════════════════════════════════

@cli.command()
@click.option("--host",     default=MSF_HOST, show_default=True, help="عنوان msfrpcd")
@click.option("--port",     default=MSF_PORT, show_default=True, type=int, help="منفذ msfrpcd")
@click.option("--password", default="",       help="كلمة مرور RPC", hide_input=True)
@click.option("--no-ssl",   is_flag=True,     help="تعطيل SSL")
def status(host: str, port: int, password: str, no_ssl: bool) -> None:
    """فحص حالة الاتصال بـ Metasploit RPC وعرض معلومات الإصدار."""
    ssl = MSF_SSL and not no_ssl
    console.print(f"\n[dim]Connecting to {host}:{port} ...[/dim]\n")

    try:
        with _make_msf_client(host, port, password, ssl) as msf:
            health   = msf.health_check()
            version  = msf.get_version()
            db_ok    = health.get("db_connected", False)
            jobs_n   = health.get("jobs_count", 0)
            sess_n   = health.get("sessions_count", 0)

            output.print_connection_status(
                host=host, port=port, version=version,
                dry_run=OT_DRY_RUN,
                jobs=jobs_n, sessions=sess_n, db_ok=db_ok,
            )

            if not db_ok:
                console.print(
                    "[yellow]  Tip: شغّل PostgreSQL وأضف database في MSF "
                    "لتفعيل حفظ نتائج المسح.[/yellow]\n"
                )

    except MetasploitRPCError as e:
        _handle_rpc_error(e)
        sys.exit(1)


# ══════════════════════════════════════════════════════════════════════════════
# الأمر: modules
# ══════════════════════════════════════════════════════════════════════════════

@cli.command()
@click.option("--filter",    "-f", "filter_str", default="", help="فلترة بكلمة مفتاحية")
@click.option("--category",  "-c", default="",   help="فلترة بالفئة (portscan/scada/snmp/...)")
@click.option("--ot-only",   is_flag=True,        help="عرض modules OT فقط (scada/snmp)")
def modules(filter_str: str, category: str, ot_only: bool) -> None:
    """عرض قائمة الـ Scanner Modules المسموحة مع إمكانية الفلترة."""
    allowed = OTScanner.get_allowed_modules()

    # فلترة بالفئة
    if category:
        allowed = OTScanner.get_modules_by_category(category)
        if not allowed:
            console.print(f"[yellow]  لا توجد modules في الفئة '{category}'[/yellow]")
            console.print(
                f"  الفئات المتاحة: "
                f"[cyan]{', '.join(OTScanner.get_module_categories())}[/cyan]"
            )
            return

    # فلترة بكلمة مفتاحية
    if filter_str:
        allowed = [m for m in allowed if filter_str.lower() in m.lower()]
        if not allowed:
            console.print(f"[yellow]  لا توجد modules تحتوي على '{filter_str}'[/yellow]")
            return

    # OT فقط
    if ot_only:
        ot_cats = {"scada", "snmp"}
        allowed = [m for m in allowed if any(f"/{c}/" in m for c in ot_cats)]

    output.print_modules_list(allowed, filter_str=filter_str or category)

    # عرض الفئات المتاحة
    cats = OTScanner.get_module_categories()
    console.print(
        f"  Categories: [dim]{' | '.join(cats)}[/dim]\n"
    )


# ══════════════════════════════════════════════════════════════════════════════
# الأمر: scan
# ══════════════════════════════════════════════════════════════════════════════

@cli.command()
@click.argument("target")
@click.option(
    "--module", "-m",
    default="auxiliary/scanner/portscan/tcp",
    show_default=True,
    help="الـ module المراد تشغيله",
)
@click.option("--ports",    "-p", default="1-1024", show_default=True, help="نطاق المنافذ")
@click.option("--threads",  "-t", default=5,        show_default=True, type=int, help="عدد الـ threads")
@click.option("--timeout",        default=30,        show_default=True, type=int, help="مهلة المسح (ثانية)")
@click.option("--host",           default=MSF_HOST,  show_default=True, help="عنوان msfrpcd")
@click.option("--port",           default=MSF_PORT,  show_default=True, type=int, help="منفذ msfrpcd")
@click.option("--password",       default="",        help="كلمة مرور RPC", hide_input=True)
@click.option("--no-ssl",         is_flag=True,      help="تعطيل SSL")
@click.option("--export-json",    is_flag=True,      help="تصدير النتائج إلى JSON")
@click.option("--export-csv",     is_flag=True,      help="تصدير النتائج إلى CSV")
@click.option("--output-dir",     default="reports", show_default=True, help="مجلد التصدير")
@click.option(
    "--option", "-o",
    multiple=True,
    metavar="KEY=VALUE",
    help="خيارات إضافية للـ module (مثل: -o TIMEOUT=10 -o VERBOSE=true)",
)
def scan(
    target: str,
    module: str,
    ports: str,
    threads: int,
    timeout: int,
    host: str,
    port: int,
    password: str,
    no_ssl: bool,
    export_json: bool,
    export_csv: bool,
    output_dir: str,
    option: tuple,
) -> None:
    """
    تشغيل module مسح على الهدف المحدد.

    \b
    TARGET: عنوان IP أو نطاق CIDR
    أمثلة:
      msf-ot scan 192.168.1.1
      msf-ot scan 192.168.1.0/24 -m auxiliary/scanner/portscan/tcp -p 1-1024
      msf-ot scan 192.168.1.1 -m auxiliary/scanner/snmp/snmp_enum
      msf-ot scan 192.168.1.100 -m auxiliary/scanner/scada/modbusdetect
      msf-ot scan 192.168.1.1 --export-json --export-csv
    """
    ssl          = MSF_SSL and not no_ssl
    extra_opts   = _parse_options(option)

    # ── عرض إعدادات المسح ────────────────────────────────────────────────────
    mode_badge = (
        "[bold red]DRY-RUN[/bold red]"
        if OT_DRY_RUN else
        "[bold green]LIVE[/bold green]"
    )
    console.print(
        f"\n[bold]Scan Configuration[/bold]\n"
        f"  Target  : [cyan]{target}[/cyan]\n"
        f"  Module  : [cyan]{module}[/cyan]\n"
        f"  Ports   : [yellow]{ports}[/yellow]\n"
        f"  Threads : [yellow]{threads}[/yellow]  "
        f"Timeout: [yellow]{timeout}s[/yellow]\n"
        f"  Mode    : {mode_badge}\n"
    )

    if extra_opts:
        console.print("  Extra Options:")
        for k, v in extra_opts.items():
            console.print(f"    [dim]{k}[/dim] = [yellow]{v}[/yellow]")
        console.print()

    # ── الاتصال والمسح ────────────────────────────────────────────────────────
    result = None
    try:
        with _make_msf_client(host, port, password, ssl) as msf:
            scanner = OTScanner(msf)

            with output.create_progress(show_eta=False) as progress:
                task = progress.add_task(
                    f"Scanning {target} with {module.split('/')[-1]} ...",
                    total=None,
                )

                def on_progress(elapsed: int, total: int) -> None:
                    progress.update(
                        task,
                        description=(
                            f"Scanning {target} ... "
                            f"[dim]{elapsed:.0f}s / {total}s[/dim]"
                        ),
                    )

                result = scanner.scan(
                    module_path = module,
                    target      = target,
                    ports       = ports,
                    threads     = threads,
                    options     = extra_opts or None,
                    timeout     = timeout,
                    on_progress = on_progress,
                )

                progress.update(task, completed=True)

    except AuthenticationError as e:
        _handle_rpc_error(e)
        sys.exit(1)

    except MetasploitRPCError as e:
        _handle_rpc_error(e)
        sys.exit(1)

    except KeyboardInterrupt:
        console.print("\n[yellow]  Scan interrupted by user.[/yellow]")
        sys.exit(0)

    # ── عرض النتائج ───────────────────────────────────────────────────────────
    if result:
        output.print_scan_results(result)

        # تصدير النتائج
        if result.is_success and not result.dry_run:
            if export_json:
                output.export_json(result, output_dir=output_dir)
            if export_csv:
                output.export_csv(result, output_dir=output_dir)
        elif (export_json or export_csv) and result.dry_run:
            console.print(
                "[dim]  التصدير غير متاح في وضع Dry-Run.[/dim]"
            )

        # exit code حسب النتيجة
        if result.status.name in ("FAILED", "BLOCKED"):
            sys.exit(1)


# ══════════════════════════════════════════════════════════════════════════════
# الأمر: multiscan
# ══════════════════════════════════════════════════════════════════════════════

@cli.command()
@click.argument("target")
@click.option(
    "--modules-list", "-m",
    multiple=True,
    help="modules للتشغيل (يمكن تكرار الخيار: -m mod1 -m mod2)",
)
@click.option("--preset", "-p",
    type=click.Choice(["portscan", "scada", "snmp", "full"], case_sensitive=False),
    default=None,
    help="مجموعة modules جاهزة",
)
@click.option("--ports",    default="1-1024", show_default=True, help="نطاق المنافذ")
@click.option("--threads",  default=5,        show_default=True, type=int)
@click.option("--timeout",  default=30,        show_default=True, type=int)
@click.option("--host",     default=MSF_HOST,  show_default=True)
@click.option("--port",     default=MSF_PORT,  show_default=True, type=int)
@click.option("--password", default="",        hide_input=True)
@click.option("--no-ssl",   is_flag=True)
@click.option("--export-json", is_flag=True,   help="تصدير كل النتائج إلى JSON")
@click.option("--export-csv",  is_flag=True,   help="تصدير كل النتائج إلى CSV")
@click.option("--output-dir",  default="reports", show_default=True)
def multiscan(
    target: str,
    modules_list: tuple,
    preset: Optional[str],
    ports: str,
    threads: int,
    timeout: int,
    host: str,
    port: int,
    password: str,
    no_ssl: bool,
    export_json: bool,
    export_csv: bool,
    output_dir: str,
) -> None:
    """
    تشغيل عدة modules على هدف واحد بالتسلسل.

    \b
    أمثلة:
      msf-ot multiscan 192.168.1.1 --preset scada
      msf-ot multiscan 192.168.1.1 --preset full
      msf-ot multiscan 192.168.1.1 -m auxiliary/scanner/portscan/tcp -m auxiliary/scanner/snmp/snmp_enum
    """
    ssl = MSF_SSL and not no_ssl

    # ── تحديد الـ modules ─────────────────────────────────────────────────────
    _PRESETS: dict[str, list[str]] = {
        "portscan": [
            "auxiliary/scanner/portscan/tcp",
            "auxiliary/scanner/portscan/udp",
            "auxiliary/scanner/discovery/arp_sweep",
        ],
        "scada": [
            "auxiliary/scanner/scada/modbusdetect",
            "auxiliary/scanner/scada/modbus_findunitid",
            "auxiliary/scanner/scada/dnp3_enumrouter",
            "auxiliary/scanner/scada/ethernetip_list_identity",
            "auxiliary/scanner/scada/bacnet_device_info",
        ],
        "snmp": [
            "auxiliary/scanner/snmp/snmp_enum",
            "auxiliary/scanner/snmp/snmp_enumusers",
        ],
        "full": [
            "auxiliary/scanner/portscan/tcp",
            "auxiliary/scanner/discovery/arp_sweep",
            "auxiliary/scanner/snmp/snmp_enum",
            "auxiliary/scanner/scada/modbusdetect",
            "auxiliary/scanner/scada/dnp3_enumrouter",
            "auxiliary/scanner/scada/ethernetip_list_identity",
        ],
    }

    if preset:
        selected_modules = _PRESETS[preset.lower()]
    elif modules_list:
        selected_modules = list(modules_list)
    else:
        console.print(
            "[red]  يجب تحديد --preset أو --modules-list[/red]\n"
            "  مثال: msf-ot multiscan 192.168.1.1 --preset scada\n"
            f"  Presets: [cyan]{' | '.join(_PRESETS.keys())}[/cyan]"
        )
        sys.exit(1)

    # ── عرض الإعدادات ─────────────────────────────────────────────────────────
    mode_badge = "[bold red]DRY-RUN[/bold red]" if OT_DRY_RUN else "[bold green]LIVE[/bold green]"
    console.print(
        f"\n[bold]Multi-Scan Configuration[/bold]\n"
        f"  Target  : [cyan]{target}[/cyan]\n"
        f"  Modules : [yellow]{len(selected_modules)}[/yellow]\n"
        f"  Preset  : [cyan]{preset or 'custom'}[/cyan]\n"
        f"  Mode    : {mode_badge}\n"
    )
    for i, m in enumerate(selected_modules, 1):
        console.print(f"  [dim]{i}.[/dim] [cyan]{m}[/cyan]")
    console.print()

    # ── الاتصال والمسح ────────────────────────────────────────────────────────
    results = []
    try:
        with _make_msf_client(host, port, password, ssl) as msf:
            scanner = OTScanner(msf)

            with output.create_multi_progress() as progress:
                task = progress.add_task(
                    f"Multi-Scan on {target}",
                    total=len(selected_modules),
                )

                for mod in selected_modules:
                    progress.update(
                        task,
                        description=f"[cyan]{mod.split('/')[-1]}[/cyan] on {target}",
                    )
                    result = scanner.scan(
                        module_path = mod,
                        target      = target,
                        ports       = ports,
                        threads     = threads,
                        timeout     = timeout,
                    )
                    results.append(result)
                    progress.advance(task)

                    if result.status.name == "BLOCKED":
                        console.print(
                            f"\n[red]  Target blocked — stopping multi-scan.[/red]"
                        )
                        break

    except MetasploitRPCError as e:
        _handle_rpc_error(e)
        sys.exit(1)

    except KeyboardInterrupt:
        console.print("\n[yellow]  Multi-scan interrupted by user.[/yellow]")

    # ── عرض النتائج ───────────────────────────────────────────────────────────
    if results:
        # عرض كل نتيجة
        for result in results:
            output.print_scan_results(result)

        # لوحة الملخص الشاملة
        output.print_summary_dashboard(results)

        # تصدير
        if not OT_DRY_RUN:
            for result in results:
                if result.is_success:
                    if export_json:
                        output.export_json(result, output_dir=output_dir)
                    if export_csv:
                        output.export_csv(result, output_dir=output_dir)


# ══════════════════════════════════════════════════════════════════════════════
# الأمر: config
# ══════════════════════════════════════════════════════════════════════════════

@cli.command("config")
@click.option("--show-ranges", is_flag=True, help="عرض نطاقات IP المحددة")
def show_config(show_ranges: bool) -> None:
    """عرض الإعدادات الحالية للأداة."""
    from rich import box
    from rich.table import Table

    summary = get_config_summary()

    table = Table(
        title="Current Configuration",
        box=box.ROUNDED,
        border_style="cyan",
        header_style="bold cyan",
        show_lines=False,
    )
    table.add_column("Setting",  style="dim",    min_width=25)
    table.add_column("Value",    style="yellow", min_width=20)
    table.add_column("Status",   justify="center")

    def _badge(ok: bool, ok_text: str = "OK", warn_text: str = "WARN") -> str:
        return f"[green]{ok_text}[/green]" if ok else f"[yellow]{warn_text}[/yellow]"

    table.add_row("MSF Host",         summary["msf_host"],          _badge(True))
    table.add_row("MSF Port",         str(summary["msf_port"]),     _badge(True))
    table.add_row("MSF SSL",          str(summary["msf_ssl"]),      _badge(summary["msf_ssl"]))
    table.add_row("Password Set",     str(summary["msf_password_set"]),
                  _badge(summary["msf_password_set"], "YES", "NO - Set MSF_PASSWORD"))
    table.add_row("Dry-Run Mode",     str(summary["ot_dry_run"]),
                  "[yellow]SAFE[/yellow]" if summary["ot_dry_run"] else "[bold red]LIVE[/bold red]")
    table.add_row("Rate Limit",       f"{summary['ot_rate_limit']} req/s",
                  _badge(summary["ot_rate_limit"] <= 10))
    table.add_row("Scan Timeout",     f"{summary['ot_scan_timeout']}s",  _badge(True))
    table.add_row("Max Threads",      str(summary["ot_max_threads"]),
                  _badge(summary["ot_max_threads"] <= 10))
    table.add_row("Allowed Modules",  str(summary["allowed_modules_count"]), _badge(True))
    table.add_row("OT Protocols",     str(summary["ot_protocols_count"]),    _badge(True))

    console.print(table)

    if show_ranges:
        from rich.panel import Panel
        bl = summary.get("blacklist_ranges", [])
        al = summary.get("allowed_ranges",   [])
        console.print(Panel(
            f"[red]Blacklisted:[/red] {', '.join(bl) or 'None'}\n"
            f"[green]Allowed:[/green]     {', '.join(al) or 'All (no restriction)'}",
            title="[bold]IP Ranges[/bold]",
            border_style="cyan",
        ))

    console.print()
    console.print(
        "[dim]  Edit .env to change settings. "
        "Run 'msf-ot status' to test the connection.[/dim]\n"
    )


# ══════════════════════════════════════════════════════════════════════════════
# Entry Point
# ══════════════════════════════════════════════════════════════════════════════

def main() -> None:
    cli(obj={})


if __name__ == "__main__":
    main()
