"""
scanner.py — تنفيذ الـ Scanner Modules بأمان كامل
===================================================
المسؤوليات:
  § 1  Data Models     — ServiceInfo / HostResult / ScanResult / ScanStatus
  § 2  ModuleParser    — تحليل module_path واستخراج النوع والاسم
  § 3  ResultsParser   — تحويل بيانات MSF DB إلى Data Models
  § 4  JobMonitor      — مراقبة الـ job مع progress callback
  § 5  OTScanner       — الـ class الرئيسي
       - scan()        — تشغيل module مع كل الحمايات
       - scan_multi()  — مسح عدة modules على نفس الهدف
       - dry_scan()    — محاكاة المسح بدون تنفيذ
       - get_allowed_modules() / search_modules()
  § 6  دوال مساعدة
"""

import logging
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable, Optional

from msf_ot.config import (
    ALLOWED_MODULES,
    ALLOWED_MODULES_SET,
    OT_DRY_RUN,
    OT_SCAN_TIMEOUT,
    OT_MAX_THREADS,
    OT_PORT_MAP,
)
from msf_ot.rpc_client import MsfClient, MetasploitRPCError, ModuleError
from msf_ot.safety import (
    run_safety_checks,
    OTSafetyError,
    SafetyCheckResult,
    audit_logger,
)

logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# § 1 — Data Models
# ══════════════════════════════════════════════════════════════════════════════

class ScanStatus(Enum):
    """حالة عملية المسح."""
    PENDING   = auto()   # لم تبدأ بعد
    RUNNING   = auto()   # جارية
    COMPLETED = auto()   # اكتملت بنجاح
    DRY_RUN   = auto()   # محاكاة فقط
    FAILED    = auto()   # فشلت
    BLOCKED   = auto()   # حُظرت بسبب OT safety
    TIMEOUT   = auto()   # انتهى الوقت


@dataclass
class ServiceInfo:
    """معلومات service مكتشف على host."""
    port     : int
    protocol : str          # tcp / udp
    state    : str          # open / closed / filtered
    name     : str  = ""    # http / ssh / modbus ...
    version  : str  = ""    # banner / version string
    is_ot    : bool = False  # هل هو بروتوكول OT؟
    ot_risk  : str  = ""    # critical / high / medium

    def __post_init__(self):
        """يُحدد تلقائياً إذا كان المنفذ بروتوكول OT."""
        proto = OT_PORT_MAP.get(self.port)
        if proto:
            self.is_ot   = True
            self.ot_risk = proto.risk_level
            if not self.name:
                self.name = proto.name


@dataclass
class HostResult:
    """نتائج host مكتشف."""
    ip        : str
    hostname  : str = ""
    os_name   : str = ""
    os_flavor : str = ""
    status    : str = "unknown"   # alive / down / unknown
    mac_addr  : str = ""
    services  : list[ServiceInfo] = field(default_factory=list)
    raw       : dict              = field(default_factory=dict)

    @property
    def open_ports(self) -> list[int]:
        """قائمة المنافذ المفتوحة."""
        return [s.port for s in self.services if s.state == "open"]

    @property
    def ot_services(self) -> list[ServiceInfo]:
        """قائمة الـ services التي هي بروتوكولات OT."""
        return [s for s in self.services if s.is_ot]

    @property
    def has_ot_services(self) -> bool:
        """هل يحتوي على بروتوكولات OT؟"""
        return len(self.ot_services) > 0

    @property
    def risk_level(self) -> str:
        """أعلى مستوى خطر للـ host بناءً على الـ services."""
        levels = {"critical": 3, "high": 2, "medium": 1, "low": 0}
        max_risk = "low"
        for svc in self.services:
            if svc.ot_risk and levels.get(svc.ot_risk, 0) > levels.get(max_risk, 0):
                max_risk = svc.ot_risk
        return max_risk


@dataclass
class ScanResult:
    """نتيجة عملية مسح كاملة."""
    module    : str
    target    : str
    status    : ScanStatus       = ScanStatus.PENDING
    hosts     : list[HostResult] = field(default_factory=list)
    warnings  : list[str]        = field(default_factory=list)
    duration  : float            = 0.0
    job_id    : str              = ""
    error     : Optional[str]    = None
    options   : dict             = field(default_factory=dict)
    ports     : str              = ""
    threads   : int              = 5
    timestamp : float            = field(default_factory=time.time)

    @property
    def is_success(self) -> bool:
        return self.status in (ScanStatus.COMPLETED, ScanStatus.DRY_RUN)

    @property
    def host_count(self) -> int:
        return len(self.hosts)

    @property
    def service_count(self) -> int:
        return sum(len(h.services) for h in self.hosts)

    @property
    def ot_host_count(self) -> int:
        return sum(1 for h in self.hosts if h.has_ot_services)

    @property
    def dry_run(self) -> bool:
        return self.status == ScanStatus.DRY_RUN

    def summary(self) -> dict:
        """يُعيد ملخص النتائج."""
        return {
            "module"     : self.module,
            "target"     : self.target,
            "status"     : self.status.name,
            "hosts"      : self.host_count,
            "services"   : self.service_count,
            "ot_hosts"   : self.ot_host_count,
            "duration_s" : round(self.duration, 2),
            "warnings"   : len(self.warnings),
            "error"      : self.error,
        }


# ══════════════════════════════════════════════════════════════════════════════
# § 2 — Module Path Parser
# ══════════════════════════════════════════════════════════════════════════════

class ModulePathError(ValueError):
    """صيغة module_path غير صحيحة."""


def parse_module_path(module_path: str) -> tuple[str, str]:
    """
    يحلّل module_path ويُعيد (module_type, module_name).

    مثال:
        'auxiliary/scanner/portscan/tcp'
        → ('auxiliary', 'scanner/portscan/tcp')

    Raises:
        ModulePathError إذا كانت الصيغة غير صحيحة.
    """
    if not module_path or not isinstance(module_path, str):
        raise ModulePathError("module_path فارغ أو غير صحيح.")

    parts = module_path.strip().split("/", 1)

    if len(parts) != 2 or not parts[0] or not parts[1]:
        raise ModulePathError(
            f"صيغة module_path غير صحيحة: '{module_path}'\n"
            f"الصيغة الصحيحة: 'auxiliary/scanner/category/name'"
        )

    return parts[0], parts[1]


# ══════════════════════════════════════════════════════════════════════════════
# § 3 — Results Parser
# ══════════════════════════════════════════════════════════════════════════════

class ResultsParser:
    """
    يحوّل بيانات Metasploit DB الخام إلى Data Models نظيفة.
    """

    @staticmethod
    def parse_host(raw: dict) -> HostResult:
        """يحوّل dict خام من MSF DB إلى HostResult."""
        return HostResult(
            ip        = raw.get("address", raw.get("host", "")),
            hostname  = raw.get("name", ""),
            os_name   = raw.get("os_name", ""),
            os_flavor = raw.get("os_flavor", ""),
            status    = raw.get("state", "unknown"),
            mac_addr  = raw.get("mac", ""),
            raw       = raw,
        )

    @staticmethod
    def parse_service(raw: dict) -> ServiceInfo:
        """يحوّل dict خام من MSF DB إلى ServiceInfo."""
        return ServiceInfo(
            port     = int(raw.get("port", 0)),
            protocol = raw.get("proto", "tcp"),
            state    = raw.get("state", "open"),
            name     = raw.get("name", ""),
            version  = raw.get("info", raw.get("version", "")),
        )

    @classmethod
    def build_hosts(
        cls,
        raw_hosts    : list[dict],
        raw_services : list[dict],
    ) -> list[HostResult]:
        """
        يبني قائمة HostResult مع ربط الـ services بكل host.

        Args:
            raw_hosts:    قائمة hosts من MSF DB
            raw_services: قائمة services من MSF DB
        """
        # فهرس services حسب IP
        services_by_ip: dict[str, list[ServiceInfo]] = {}
        for raw_svc in raw_services:
            ip = raw_svc.get("host", raw_svc.get("address", ""))
            if ip:
                svc = cls.parse_service(raw_svc)
                services_by_ip.setdefault(ip, []).append(svc)

        # بناء الـ hosts مع ربط الـ services
        hosts: list[HostResult] = []
        for raw_host in raw_hosts:
            host = cls.parse_host(raw_host)
            host.services = sorted(
                services_by_ip.get(host.ip, []),
                key=lambda s: s.port,
            )
            hosts.append(host)

        return hosts


# ══════════════════════════════════════════════════════════════════════════════
# § 4 — Job Monitor
# ══════════════════════════════════════════════════════════════════════════════

class JobMonitor:
    """
    يراقب job نشط ويُبلّغ عن التقدم عبر callback.
    """

    def __init__(
        self,
        msf_client    : MsfClient,
        job_id        : str,
        timeout       : int   = OT_SCAN_TIMEOUT,
        poll_interval : float = 1.0,
        on_tick       : Optional[Callable[[int, int], None]] = None,
    ):
        """
        Args:
            msf_client:    الـ MsfClient المتصل
            job_id:        معرّف الـ job
            timeout:       أقصى وقت انتظار بالثواني
            poll_interval: فترة الفحص بالثواني
            on_tick:       callback(elapsed_s, timeout_s) يُستدعى كل poll_interval
        """
        self.msf           = msf_client
        self.job_id        = job_id
        self.timeout       = timeout
        self.poll_interval = poll_interval
        self.on_tick       = on_tick

    def wait(self) -> ScanStatus:
        """
        ينتظر حتى ينتهي الـ job.

        Returns:
            ScanStatus.COMPLETED  إذا انتهى بنجاح
            ScanStatus.TIMEOUT    إذا انتهى الوقت
            ScanStatus.FAILED     إذا حدث خطأ
        """
        deadline = time.monotonic() + self.timeout
        elapsed  = 0

        logger.info(
            f"[JobMonitor] Waiting for job={self.job_id} "
            f"timeout={self.timeout}s interval={self.poll_interval}s"
        )

        while time.monotonic() < deadline:
            try:
                if not self.msf.is_job_running(self.job_id):
                    logger.info(
                        f"[JobMonitor] Job {self.job_id} completed in {elapsed:.0f}s"
                    )
                    return ScanStatus.COMPLETED

            except Exception as e:
                logger.warning(
                    f"[JobMonitor] Error polling job {self.job_id}: {e}"
                )
                return ScanStatus.FAILED

            # استدعاء الـ callback
            if self.on_tick:
                try:
                    self.on_tick(elapsed, self.timeout)
                except Exception:
                    pass

            time.sleep(self.poll_interval)
            elapsed += self.poll_interval

        logger.warning(
            f"[JobMonitor] Job {self.job_id} timed out after {self.timeout}s"
        )
        return ScanStatus.TIMEOUT


# ══════════════════════════════════════════════════════════════════════════════
# § 5 — OTScanner — الـ Class الرئيسي
# ══════════════════════════════════════════════════════════════════════════════

class OTScanner:
    """
    Scanner آمن لبيئات OT/ICS.

    يشغّل auxiliary/scanner modules فقط مع:
    ─────────────────────────────────────────
    • فحص أمان OT قبل كل عملية مسح
    • Dry-Run mode افتراضي
    • Job monitoring مع progress callback
    • جمع النتائج من MSF DB
    • دعم مسح عدة modules دفعة واحدة
    """

    def __init__(self, msf_client: MsfClient):
        self.msf    = msf_client
        self.parser = ResultsParser()

    # ─────────────────────────────────────────────────────────────────────────
    # scan() — العملية الرئيسية
    # ─────────────────────────────────────────────────────────────────────────

    def scan(
        self,
        module_path : str,
        target      : str,
        ports       : str  = "",
        threads     : int  = 5,
        options     : Optional[dict] = None,
        timeout     : int  = OT_SCAN_TIMEOUT,
        on_progress : Optional[Callable[[int, int], None]] = None,
    ) -> ScanResult:
        """
        يشغّل module مسح على الهدف مع كل طبقات الحماية.

        Args:
            module_path:  مثل 'auxiliary/scanner/portscan/tcp'
            target:       IP أو CIDR مثل '192.168.1.0/24'
            ports:        نطاق المنافذ مثل '1-1024' أو '80,443,502'
            threads:      عدد الـ threads (افتراضي 5 — منخفض لحماية OT)
            options:      خيارات إضافية {'KEY': 'VALUE'}
            timeout:      أقصى وقت انتظار بالثواني
            on_progress:  callback(elapsed_s, total_s) للـ progress bar

        Returns:
            ScanResult مع كل النتائج والتحذيرات
        """
        result = ScanResult(
            module  = module_path,
            target  = target,
            ports   = ports,
            threads = threads,
            options = options or {},
        )
        start_time = time.monotonic()

        # ── § A: فحوصات الأمان ────────────────────────────────────────────────
        safety = self._run_safety(result, module_path, target, ports, threads)
        if safety is None:
            result.duration = time.monotonic() - start_time
            return result

        result.warnings.extend(safety.warnings)

        # ── § B: Dry-Run Mode ─────────────────────────────────────────────────
        if OT_DRY_RUN:
            return self._make_dry_run(result, start_time, safety)

        # ── § C: تحليل module_path ────────────────────────────────────────────
        try:
            mod_type, mod_name = parse_module_path(module_path)
        except ModulePathError as e:
            result.status   = ScanStatus.FAILED
            result.error    = str(e)
            result.duration = time.monotonic() - start_time
            return result

        # ── § D: تشغيل الـ Module ─────────────────────────────────────────────
        job_id = self._execute(
            result, mod_type, mod_name, target, ports, threads, options
        )
        if job_id is None:
            result.duration = time.monotonic() - start_time
            return result

        result.job_id  = job_id
        result.status  = ScanStatus.RUNNING

        # ── § E: مراقبة الـ Job ───────────────────────────────────────────────
        monitor = JobMonitor(
            msf_client    = self.msf,
            job_id        = job_id,
            timeout       = timeout,
            poll_interval = 1.0,
            on_tick       = on_progress,
        )
        final_status  = monitor.wait()
        result.status = final_status

        # ── § F: جمع النتائج ──────────────────────────────────────────────────
        if final_status in (ScanStatus.COMPLETED, ScanStatus.TIMEOUT):
            result.hosts = self._collect_results()

        result.duration = time.monotonic() - start_time

        audit_logger.info(
            f"SCAN_DONE | module={module_path} | target={target} | "
            f"status={result.status.name} | hosts={result.host_count} | "
            f"duration={result.duration:.1f}s"
        )

        return result

    # ─────────────────────────────────────────────────────────────────────────
    # scan_multi() — مسح عدة modules
    # ─────────────────────────────────────────────────────────────────────────

    def scan_multi(
        self,
        modules : list[str],
        target  : str,
        ports   : str = "",
        threads : int = 5,
        options : Optional[dict] = None,
        timeout : int = OT_SCAN_TIMEOUT,
    ) -> list[ScanResult]:
        """
        يشغّل عدة modules على نفس الهدف بالتسلسل.

        Args:
            modules: قائمة module paths
            target:  الهدف المشترك

        Returns:
            قائمة ScanResult واحدة لكل module
        """
        results: list[ScanResult] = []

        logger.info(
            f"[OTScanner] scan_multi: {len(modules)} modules on {target}"
        )

        for i, module_path in enumerate(modules, 1):
            logger.info(
                f"[OTScanner] Running module {i}/{len(modules)}: {module_path}"
            )
            result = self.scan(
                module_path = module_path,
                target      = target,
                ports       = ports,
                threads     = threads,
                options     = options,
                timeout     = timeout,
            )
            results.append(result)

            # توقف إذا حُظر الهدف — لا فائدة من المتابعة
            if result.status == ScanStatus.BLOCKED:
                logger.warning(
                    f"[OTScanner] Target blocked — stopping scan_multi."
                )
                break

        return results

    # ─────────────────────────────────────────────────────────────────────────
    # dry_scan() — محاكاة بدون اتصال بـ MSF
    # ─────────────────────────────────────────────────────────────────────────

    def dry_scan(
        self,
        module_path : str,
        target      : str,
        ports       : str = "",
        threads     : int = 5,
        options     : Optional[dict] = None,
    ) -> ScanResult:
        """
        يُحاكي المسح بدون تنفيذ فعلي.
        يتجاوز OT_DRY_RUN ويُجبر وضع المحاكاة دائماً.
        مفيد للتحقق من الإعدادات والأمان قبل التشغيل الحقيقي.
        """
        result = ScanResult(
            module  = module_path,
            target  = target,
            ports   = ports,
            threads = threads,
            options = options or {},
        )
        start_time = time.monotonic()

        safety = self._run_safety(result, module_path, target, ports, threads)
        if safety is None:
            result.duration = time.monotonic() - start_time
            return result

        result.warnings.extend(safety.warnings)
        return self._make_dry_run(result, start_time, safety)

    # ─────────────────────────────────────────────────────────────────────────
    # دوال مساعدة خاصة
    # ─────────────────────────────────────────────────────────────────────────

    def _run_safety(
        self,
        result      : ScanResult,
        module_path : str,
        target      : str,
        ports       : str,
        threads     : int,
    ) -> Optional[SafetyCheckResult]:
        """
        يشغّل فحوصات الأمان.
        Returns: SafetyCheckResult إذا نجح، None إذا حُظر.
        """
        try:
            return run_safety_checks(
                module_path = module_path,
                target      = target,
                ports       = ports,
                threads     = threads,
            )
        except OTSafetyError as e:
            result.status = ScanStatus.BLOCKED
            result.error  = str(e)
            logger.warning(f"[OTScanner] Safety blocked: {e}")
            return None

    def _make_dry_run(
        self,
        result     : ScanResult,
        start_time : float,
        safety     : SafetyCheckResult,
    ) -> ScanResult:
        """يُعدّ نتيجة Dry-Run."""
        result.status   = ScanStatus.DRY_RUN
        result.duration = time.monotonic() - start_time

        logger.info(
            f"[OTScanner] DRY-RUN | module={result.module} | "
            f"target={result.target} | warnings={len(result.warnings)}"
        )
        audit_logger.info(
            f"DRY_RUN_SCAN | module={result.module} | target={result.target}"
        )
        return result

    def _execute(
        self,
        result   : ScanResult,
        mod_type : str,
        mod_name : str,
        target   : str,
        ports    : str,
        threads  : int,
        options  : Optional[dict],
    ) -> Optional[str]:
        """
        يُشغّل الـ module ويُعيد job_id.
        Returns: job_id كـ string، أو None عند الفشل.
        """
        # بناء خيارات الـ module
        module_options: dict = {
            "RHOSTS"  : target,
            "THREADS" : min(threads, OT_MAX_THREADS),
        }

        if ports:
            module_options["PORTS"] = ports

        # دمج الخيارات الإضافية — لا تُلغي RHOSTS/THREADS
        if options:
            for key, value in options.items():
                if key.upper() not in ("RHOSTS", "THREADS"):
                    module_options[key.upper()] = value

        try:
            job_id = self.msf.execute_module(mod_type, mod_name, module_options)
            logger.info(
                f"[OTScanner] Module started | "
                f"job_id={job_id} | {mod_type}/{mod_name} | target={target}"
            )
            return job_id

        except ModuleError as e:
            result.status = ScanStatus.FAILED
            result.error  = str(e)
            logger.error(f"[OTScanner] Module execution failed: {e}")
            return None

        except MetasploitRPCError as e:
            result.status = ScanStatus.FAILED
            result.error  = f"RPC Error: {e}"
            logger.error(f"[OTScanner] RPC error during execution: {e}")
            return None

    def _collect_results(self) -> list[HostResult]:
        """
        يجمع نتائج المسح من Metasploit DB.
        يُعيد قائمة فارغة إذا لم تكن DB مفعّلة.
        """
        try:
            raw_hosts    = self.msf.db_hosts()
            raw_services = self.msf.db_services()

            hosts = ResultsParser.build_hosts(raw_hosts, raw_services)

            logger.info(
                f"[OTScanner] Collected {len(hosts)} hosts, "
                f"{sum(len(h.services) for h in hosts)} services from DB"
            )
            return hosts

        except Exception as e:
            logger.warning(
                f"[OTScanner] Could not collect DB results "
                f"(DB may not be enabled): {e}"
            )
            return []

    # ─────────────────────────────────────────────────────────────────────────
    # § 6 — دوال عامة (Static / Class Methods)
    # ─────────────────────────────────────────────────────────────────────────

    @staticmethod
    def get_allowed_modules() -> list[str]:
        """يُعيد قائمة الـ modules المسموحة كاملة."""
        return list(ALLOWED_MODULES)

    @staticmethod
    def search_modules(keyword: str) -> list[str]:
        """
        يبحث في الـ modules المسموحة بكلمة مفتاحية.

        Args:
            keyword: كلمة البحث (غير حساسة لحالة الأحرف)
        """
        kw = keyword.lower().strip()
        return [m for m in ALLOWED_MODULES if kw in m.lower()]

    @staticmethod
    def get_modules_by_category(category: str) -> list[str]:
        """
        يُعيد الـ modules حسب الفئة.

        Args:
            category: مثل 'portscan' أو 'scada' أو 'snmp'
        """
        cat = category.lower().strip()
        return [m for m in ALLOWED_MODULES if f"/{cat}/" in m.lower()]

    @staticmethod
    def is_module_allowed(module_path: str) -> bool:
        """يتحقق إذا كان module_path في القائمة البيضاء."""
        return module_path.strip() in ALLOWED_MODULES_SET

    @staticmethod
    def get_module_categories() -> list[str]:
        """يُعيد قائمة فئات الـ modules المتاحة."""
        categories: set[str] = set()
        for mod in ALLOWED_MODULES:
            parts = mod.split("/")
            if len(parts) >= 3:
                categories.add(parts[2])
        return sorted(categories)
