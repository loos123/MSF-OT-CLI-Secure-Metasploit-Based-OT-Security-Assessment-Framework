"""
msf_ot — Metasploit OT Security CLI
Safe scanner-only integration for OT/ICS environments.

⚠️  WARNING: For isolated lab environments only.
    Never run against live OT systems without written authorization.
"""

__version__ = "1.0.0"
__author__ = "OT Security Team"
