"""
safety.py — طبقة الحماية الكاملة لأنظمة OT
=============================================
المسؤوليات:
  - Exploit blocker  : يمنع أي module غير scanner
  - IP Validator     : يتحقق من القوائم البيضاء والسوداء
  - Rate Limiter     : يحمي أجهزة OT من الـ overload
  - OT Port Warning  : يحذر عند مسح منافذ OT حساسة
  - Audit Logger     : يسجّل كل عملية في logs/audit.log
  - Dry-Run Guard    : يمنع التنفيذ الحقيقي في وضع المحاكاة
"""

import ipaddress
import logging
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from functools import wraps
from pathlib import Path
from typing import Callable, Optional

from msf_ot.config import (
    ALLOWED_MODULES_SET,
    BLOCKED_MODULE_KEYWORDS,
    BLOCKED_MODULE_PREFIXES,
    OT_BLACKLIST_RANGES,
    OT_ALLOWED_RANGES,
    OT_WARN_RANGES,
    OT_CRITICAL_PORTS,
    OT_PORT_MAP,
    OT_DRY_RUN,
    OT_RATE_LIMIT,
)


# ══════════════════════════════════════════════════════════════════════════════
# § 1 — Audit Logger
# ══════════════════════════════════════════════════════════════════════════════

def _setup_audit_logger() -> logging.Logger:
    """يُعدّ الـ audit logger مع rotation-safe handler."""
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)

    _logger = logging.getLogger("ot_audit")
    _logger.setLevel(logging.DEBUG)
    _logger.propagate = False  # لا يرسل للـ root logger

    # تجنب إضافة handlers مكررة
    if not _logger.handlers:
        fh = logging.FileHandler(log_dir / "audit.log", encoding="utf-8")
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        ))
        _logger.addHandler(fh)

    return _logger


audit_logger = _setup_audit_logger()


# ══════════════════════════════════════════════════════════════════════════════
# § 2 — Custom Exceptions
# ══════════════════════════════════════════════════════════════════════════════

class OTSafetyError(Exception):
    """Base: يُرفع عند انتهاك قواعد أمان OT."""


class BlockedModuleError(OTSafetyError):
    """يُرفع عند محاولة تشغيل module محظور."""


class BlockedIPError(OTSafetyError):
    """يُرفع عند محاولة مسح IP محظور."""


class ConfigError(OTSafetyError):
    """يُرفع عند خطأ في الإعدادات."""


# ══════════════════════════════════════════════════════════════════════════════
# § 3 — Rate Limiter (Thread-Safe)
# ══════════════════════════════════════════════════════════════════════════════

class RateLimiter:
    """
    Token-bucket rate limiter آمن للـ threads.
    يحمي أجهزة OT من الـ overload بتحديد عدد الطلبات/ثانية.
    """

    def __init__(self, max_calls: int = OT_RATE_LIMIT, window: float = 1.0):
        self.max_calls = max_calls
        self.window    = window
        self._calls: deque[float] = deque()
        self._lock  = threading.Lock()

    def wait(self) -> float:
        """
        ينتظر إذا تجاوزنا الحد المسموح.
        Returns: وقت الانتظار بالثواني.
        """
        with self._lock:
            now = time.monotonic()

            # احذف الطلبات خارج النافذة الزمنية
            while self._calls and now - self._calls[0] >= self.window:
                self._calls.popleft()

            waited = 0.0
            if len(self._calls) >= self.max_calls:
                # انتظر حتى تنتهي أقدم نافذة
                sleep_time = self.window - (now - self._calls[0])
                if sleep_time > 0:
                    waited = sleep_time

            self._calls.append(time.monotonic())

        if waited > 0:
            audit_logger.debug(f"RATE_LIMIT: sleeping {waited:.3f}s")
            time.sleep(waited)

        return waited

    @property
    def current_rate(self) -> int:
        """يُعيد عدد الطلبات في الثانية الأخيرة."""
        with self._lock:
            now = time.monotonic()
            return sum(1 for t in self._calls if now - t < self.window)

    def reset(self) -> None:
        """يُعيد تعيين العداد (للاختبارات)."""
        with self._lock:
            self._calls.clear()


# Singleton مشترك بين كل الـ threads
rate_limiter = RateLimiter()


# ══════════════════════════════════════════════════════════════════════════════
# § 4 — نتيجة فحص الأمان
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class SafetyCheckResult:
    """نتيجة فحص الأمان الشامل."""
    passed       : bool = True
    warnings     : list[str] = field(default_factory=list)
    blocked_reason: Optional[str] = None
    ot_ports_found: list[str] = field(default_factory=list)  # منافذ OT في الهدف

    def add_warning(self, msg: str) -> None:
        self.warnings.append(msg)

    def block(self, reason: str) -> None:
        self.passed = False
        self.blocked_reason = reason


# ══════════════════════════════════════════════════════════════════════════════
# § 5 — Module Validator
# ══════════════════════════════════════════════════════════════════════════════

def validate_module(module_path: str) -> None:
    """
    يتحقق أن الـ module مسموح به عبر 3 طبقات:
      1. فحص البادئات المحظورة (exploit/, post/, ...)
      2. فحص الكلمات المحظورة (dos, overflow, ...)
      3. فحص القائمة البيضاء

    Raises: BlockedModuleError عند أي انتهاك.
    """
    if not module_path or not isinstance(module_path, str):
        raise BlockedModuleError("❌ اسم الـ module فارغ أو غير صحيح.")

    module_clean = module_path.strip()
    module_lower = module_clean.lower()

    # ── طبقة 1: البادئات المحظورة ─────────────────────────────────────────────
    for prefix in BLOCKED_MODULE_PREFIXES:
        if module_lower.startswith(prefix):
            audit_logger.warning(
                f"BLOCKED_MODULE | reason=blocked_prefix | prefix={prefix} | module={module_clean}"
            )
            raise BlockedModuleError(
                f"❌ Module محظور: '{module_clean}'\n"
                f"   السبب: يبدأ بـ '{prefix}'\n"
                f"   المسموح: auxiliary/scanner/* فقط"
            )

    # ── طبقة 2: الكلمات المحظورة ──────────────────────────────────────────────
    for keyword in BLOCKED_MODULE_KEYWORDS:
        if keyword in module_lower:
            audit_logger.warning(
                f"BLOCKED_MODULE | reason=blocked_keyword | keyword={keyword} | module={module_clean}"
            )
            raise BlockedModuleError(
                f"❌ Module محظور: '{module_clean}'\n"
                f"   السبب: يحتوي على كلمة محظورة '{keyword}'\n"
                f"   هذا النوع من الـ modules قد يضر بأجهزة OT."
            )

    # ── طبقة 3: القائمة البيضاء ───────────────────────────────────────────────
    if module_clean not in ALLOWED_MODULES_SET:
        audit_logger.warning(
            f"BLOCKED_MODULE | reason=not_in_whitelist | module={module_clean}"
        )
        raise BlockedModuleError(
            f"❌ Module غير مسموح: '{module_clean}'\n"
            f"   ليس في القائمة البيضاء.\n"
            f"   شغّل: msf-ot modules  لعرض الـ modules المسموحة."
        )

    audit_logger.info(f"MODULE_ALLOWED | module={module_clean}")


# ══════════════════════════════════════════════════════════════════════════════
# § 6 — IP / Target Validator
# ══════════════════════════════════════════════════════════════════════════════

def validate_target(target: str) -> SafetyCheckResult:
    """
    يتحقق من الهدف عبر 4 طبقات:
      1. صحة صيغة IP/CIDR
      2. القائمة السوداء (OT_BLACKLIST_RANGES)
      3. القائمة البيضاء (OT_ALLOWED_RANGES) — إذا محددة
      4. تحذير نطاقات OT المعروفة

    Returns: SafetyCheckResult مع التحذيرات.
    Raises:  BlockedIPError عند الحظر.
    """
    result = SafetyCheckResult()

    if not target or not isinstance(target, str):
        raise BlockedIPError("❌ الهدف فارغ أو غير صحيح.")

    target_clean = target.strip()

    # ── طبقة 1: صحة الصيغة ────────────────────────────────────────────────────
    try:
        network = ipaddress.ip_network(target_clean, strict=False)
    except ValueError:
        raise BlockedIPError(
            f"❌ '{target_clean}' ليس IP أو CIDR صحيحاً.\n"
            f"   أمثلة صحيحة: 192.168.1.1 | 192.168.1.0/24"
        )

    # ── طبقة 2: القائمة السوداء ───────────────────────────────────────────────
    for blocked_cidr in OT_BLACKLIST_RANGES:
        try:
            blocked_net = ipaddress.ip_network(blocked_cidr, strict=False)
            if network.overlaps(blocked_net):
                audit_logger.warning(
                    f"BLOCKED_IP | reason=blacklist | cidr={blocked_cidr} | target={target_clean}"
                )
                raise BlockedIPError(
                    f"❌ الهدف '{target_clean}' محظور!\n"
                    f"   يتداخل مع نطاق OT المحمي: {blocked_cidr}\n"
                    f"   هذا النطاق قد يحتوي على PLC / SCADA / DCS.\n"
                    f"   عدّل OT_BLACKLIST_RANGES في .env إذا كنت متأكداً."
                )
        except ValueError:
            audit_logger.debug(f"Invalid blacklist CIDR skipped: {blocked_cidr}")
            continue

    # ── طبقة 3: القائمة البيضاء (اختيارية) ───────────────────────────────────
    if OT_ALLOWED_RANGES:
        is_allowed = False
        for allowed_cidr in OT_ALLOWED_RANGES:
            try:
                allowed_net = ipaddress.ip_network(allowed_cidr, strict=False)
                if network.overlaps(allowed_net):
                    is_allowed = True
                    break
            except ValueError:
                continue

        if not is_allowed:
            audit_logger.warning(
                f"BLOCKED_IP | reason=not_in_allowed | target={target_clean}"
            )
            raise BlockedIPError(
                f"❌ الهدف '{target_clean}' خارج النطاقات المسموحة.\n"
                f"   النطاقات المسموحة: {', '.join(OT_ALLOWED_RANGES)}\n"
                f"   عدّل OT_ALLOWED_RANGES في .env لإضافة نطاقات جديدة."
            )

    # ── طبقة 4: تحذير نطاقات OT المعروفة ────────────────────────────────────
    for warn_cidr in OT_WARN_RANGES:
        try:
            warn_net = ipaddress.ip_network(warn_cidr, strict=False)
            if network.overlaps(warn_net):
                msg = (
                    f"⚠️  الهدف '{target_clean}' في نطاق OT معروف ({warn_cidr}).\n"
                    f"   تأكد أنك في بيئة معزولة."
                )
                result.add_warning(msg)
                audit_logger.warning(
                    f"OT_RANGE_WARNING | cidr={warn_cidr} | target={target_clean}"
                )
                break
        except ValueError:
            continue

    audit_logger.info(f"TARGET_ALLOWED | target={target_clean}")
    return result


# ══════════════════════════════════════════════════════════════════════════════
# § 7 — OT Port Warning
# ══════════════════════════════════════════════════════════════════════════════

def check_ot_ports(ports_str: str) -> list[str]:
    """
    يتحقق إذا كانت المنافذ المطلوبة تشمل بروتوكولات OT حساسة.
    Returns: قائمة تحذيرات للمنافذ الحرجة.
    """
    warnings: list[str] = []

    if not ports_str:
        return warnings

    # تحليل نطاقات المنافذ مثل "1-1024" أو "80,443,502"
    port_numbers: set[int] = set()
    for part in ports_str.replace(" ", "").split(","):
        if "-" in part:
            try:
                start, end = part.split("-", 1)
                port_numbers.update(range(int(start), int(end) + 1))
            except ValueError:
                pass
        else:
            try:
                port_numbers.add(int(part))
            except ValueError:
                pass

    # تحقق من المنافذ الحرجة
    found_critical = port_numbers & OT_CRITICAL_PORTS
    for port in sorted(found_critical):
        proto = OT_PORT_MAP.get(port)
        if proto:
            warnings.append(
                f"⚠️  منفذ حرج: {port}/tcp — {proto.name} ({proto.description})"
            )
            audit_logger.warning(
                f"OT_CRITICAL_PORT | port={port} | protocol={proto.name}"
            )

    return warnings


# ══════════════════════════════════════════════════════════════════════════════
# § 8 — Dry-Run Decorator
# ══════════════════════════════════════════════════════════════════════════════

def dry_run_guard(func: Callable) -> Callable:
    """
    Decorator: يمنع التنفيذ الحقيقي في وضع Dry-Run.
    يُعيد dict يوضح ما كان سيحدث.
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        if OT_DRY_RUN:
            audit_logger.info(
                f"DRY_RUN | function={func.__name__} | "
                f"args={args!r} | kwargs={kwargs!r}"
            )
            return {
                "dry_run"  : True,
                "function" : func.__name__,
                "args"     : repr(args),
                "kwargs"   : repr(kwargs),
                "message"  : "لم يُنفَّذ — وضع Dry-Run مفعّل (OT_DRY_RUN=true)",
            }
        return func(*args, **kwargs)
    return wrapper


# ══════════════════════════════════════════════════════════════════════════════
# § 9 — الفحص الشامل (نقطة الدخول الرئيسية)
# ══════════════════════════════════════════════════════════════════════════════

def run_safety_checks(
    module_path : str,
    target      : str,
    ports       : str = "",
    threads     : int = 5,
) -> SafetyCheckResult:
    """
    يشغّل جميع فحوصات الأمان بالترتيب:
      1. validate_module  — فحص الـ module
      2. validate_target  — فحص الـ IP
      3. check_ot_ports   — تحذير المنافذ الحرجة
      4. rate_limiter     — تحديد معدل الطلبات
      5. threads check    — التحقق من عدد الـ threads

    Returns: SafetyCheckResult مع التحذيرات.
    Raises:  OTSafetyError عند أي انتهاك.
    """
    # ── 1. فحص الـ Module ─────────────────────────────────────────────────────
    validate_module(module_path)

    # ── 2. فحص الـ Target ────────────────────────────────────────────────────
    check_result = validate_target(target)

    # ── 3. تحذير المنافذ الحرجة ──────────────────────────────────────────────
    if ports:
        port_warnings = check_ot_ports(ports)
        check_result.ot_ports_found = port_warnings
        for w in port_warnings:
            check_result.add_warning(w)

    # ── 4. فحص عدد الـ Threads ───────────────────────────────────────────────
    from msf_ot.config import OT_MAX_THREADS
    if threads > OT_MAX_THREADS:
        check_result.add_warning(
            f"⚠️  threads={threads} يتجاوز الحد الموصى به ({OT_MAX_THREADS}) لبيئات OT."
        )
        audit_logger.warning(f"HIGH_THREADS | threads={threads} | max={OT_MAX_THREADS}")

    # ── 5. Rate Limiter ───────────────────────────────────────────────────────
    rate_limiter.wait()

    # ── تسجيل الموافقة ────────────────────────────────────────────────────────
    audit_logger.info(
        f"SCAN_APPROVED | module={module_path} | target={target} | "
        f"ports={ports or 'default'} | threads={threads} | "
        f"warnings={len(check_result.warnings)}"
    )

    return check_result


# ══════════════════════════════════════════════════════════════════════════════
# § 10 — دوال مساعدة
# ══════════════════════════════════════════════════════════════════════════════

def is_module_allowed(module_path: str) -> bool:
    """يتحقق بصمت إذا كان الـ module مسموحاً (بدون رفع استثناء)."""
    try:
        validate_module(module_path)
        return True
    except BlockedModuleError:
        return False


def is_target_allowed(target: str) -> bool:
    """يتحقق بصمت إذا كان الهدف مسموحاً (بدون رفع استثناء)."""
    try:
        validate_target(target)
        return True
    except (BlockedIPError, OTSafetyError):
        return False


def get_audit_log_path() -> Path:
    """يُعيد مسار ملف الـ audit log."""
    return Path("logs") / "audit.log"
