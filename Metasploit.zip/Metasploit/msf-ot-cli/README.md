# 🛡️ Metasploit OT Security CLI

أداة CLI آمنة للتكامل مع Metasploit لإجراء اختبارات أمنية على بيئات OT/ICS.

> ⚠️ **تحذير:** للاستخدام في بيئات الاختبار المعزولة فقط.  
> لا تستخدم على أنظمة OT حية (PLC, SCADA, DCS) بدون تصريح كتابي رسمي.

---

## المتطلبات

- Python 3.9+
- Metasploit Framework 6+
- Linux / Kali / Parrot OS
- شبكة معزولة (test lab)

---

## التثبيت

```bash
# 1. إنشاء بيئة افتراضية
python3 -m venv venv
source venv/bin/activate

# 2. تثبيت المكتبات
pip install -r requirements.txt

# 3. تثبيت الأداة
pip install -e .

# 4. نسخ ملف الإعدادات
cp .env.example .env
# عدّل .env بكلمة المرور والإعدادات المناسبة
```

---

## تشغيل msfrpcd

```bash
# تشغيل Metasploit RPC daemon
msfrpcd -P yourpassword -a 127.0.0.1 -n -f

# التحقق من التشغيل
netstat -tlnp | grep 55553
```

---

## الاستخدام

### فحص حالة الاتصال
```bash
msf-ot status
```

### عرض الـ Modules المسموحة
```bash
msf-ot modules
msf-ot modules --filter snmp      # فلترة بكلمة مفتاحية
msf-ot modules --filter scada     # modules خاصة بـ OT
```

### تشغيل مسح
```bash
# مسح المنافذ (Dry-Run افتراضي)
msf-ot scan 192.168.1.1

# مسح نطاق كامل
msf-ot scan 192.168.1.0/24 -m auxiliary/scanner/portscan/tcp -p 1-1024

# مسح SNMP (شائع في OT)
msf-ot scan 192.168.1.1 -m auxiliary/scanner/snmp/snmp_enum

# مسح Modbus (بروتوكول OT)
msf-ot scan 192.168.1.100 -m auxiliary/scanner/scada/modbusdetect

# تصدير النتائج
msf-ot scan 192.168.1.0/24 --export-json --export-csv

# خيارات إضافية
msf-ot scan 192.168.1.1 -o TIMEOUT=10 -o VERBOSE=true
```

---

## هيكل المشروع

```
msf-ot-cli/
├── msf_ot/
│   ├── __init__.py     # معلومات الحزمة
│   ├── cli.py          # واجهة الأوامر (Click)
│   ├── rpc_client.py   # الاتصال بـ Metasploit RPC
│   ├── scanner.py      # تنفيذ الـ modules
│   ├── output.py       # عرض النتائج (Rich)
│   ├── safety.py       # حماية OT
│   └── config.py       # الإعدادات
├── .env.example
├── requirements.txt
├── setup.py
└── README.md
```

---

## إعدادات .env

| المتغير | الوصف | الافتراضي |
|---------|-------|-----------|
| `MSF_HOST` | عنوان msfrpcd | `127.0.0.1` |
| `MSF_PORT` | منفذ msfrpcd | `55553` |
| `MSF_PASSWORD` | كلمة مرور RPC | — |
| `MSF_SSL` | تفعيل SSL | `true` |
| `OT_DRY_RUN` | وضع المحاكاة | `true` |
| `OT_RATE_LIMIT` | حد الطلبات/ثانية | `5` |
| `OT_SCAN_TIMEOUT` | مهلة المسح (ثانية) | `30` |
| `OT_BLACKLIST_RANGES` | نطاقات IP محظورة | — |
| `OT_ALLOWED_RANGES` | نطاقات IP مسموحة | — |

---

## قواعد الأمان

1. **Scanner Only** — exploit/payload/post modules محظورة تماماً
2. **Rate Limiting** — حد أقصى 5 طلبات/ثانية لحماية أجهزة OT
3. **IP Blacklist** — نطاقات OT الحساسة محظورة تلقائياً
4. **Dry-Run افتراضي** — لا يُنفَّذ أي مسح حقيقي إلا بعد تعطيل `OT_DRY_RUN`
5. **Audit Log** — كل عملية مسجّلة في `logs/audit.log`
