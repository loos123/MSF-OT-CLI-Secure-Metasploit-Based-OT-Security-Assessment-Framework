from setuptools import setup, find_packages

setup(
    name="msf-ot-cli",
    version="1.0.0",
    description="Metasploit OT Security CLI — Safe Scanner for OT/ICS Environments",
    author="OT Security Team",
    python_requires=">=3.9",
    packages=find_packages(),
    install_requires=[
        "pymetasploit3==1.0.3",
        "rich==13.7.1",
        "click==8.1.7",
        "python-dotenv==1.0.1",
        "ipaddress==1.0.23",
    ],
    entry_points={
        "console_scripts": [
            "msf-ot=msf_ot.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: POSIX :: Linux",
        "Topic :: Security",
        "Environment :: Console",
    ],
)
