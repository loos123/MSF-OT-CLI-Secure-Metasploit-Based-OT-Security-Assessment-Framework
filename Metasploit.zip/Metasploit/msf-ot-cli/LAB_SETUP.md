# 🧪 Lab Setup Guide — Metasploit OT Security CLI

دليل إعداد بيئة الاختبار المعزولة لتشغيل الأداة على أجهزة OT وهمية.

> ⚠️ **تحذير:** هذا الدليل مخصص لبيئات الاختبار المعزولة فقط.  
> لا تُطبّق هذه الخطوات على شبكات OT حية.

---

## المتطلبات

| المكوّن | الإصدار | الغرض |
|---------|---------|-------|
| GNS3 أو EVE-NG | 2.3+ | محاكاة الشبكة |
| Kali Linux VM | 2023+ | تشغيل الأداة |
| Metasploit Framework | 6.3+ | RPC backend |
| Python | 3.9+ | تشغيل الأداة |
| PostgreSQL | 14+ | حفظ نتائج المسح |

---

## هيكل الشبكة الوهمية

```
┌─────────────────────────────────────────────────────────┐
│                   OT Lab Network                        │
│                  192.168.1.0/24                         │
│                                                         │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐             │
│  │  PLC-01  │  │  HMI-01  │  │  RTU-01  │             │
│  │10.1.1.10 │  │10.1.1.20 │  │10.1.1.30 │             │
│  │Modbus:502│  │S7:102    │  │DNP3:20000│             │
│  └──────────┘  └──────────┘  └──────────┘             │
│                                                         │
│  ┌──────────┐  ┌──────────────────────┐               │
│  │  EWS-01  │  │    Historian-01      │               │
│  │10.1.1.40 │  │    10.1.1.50         │               │
│  │SSH:22    │  │    HTTP:80 SNMP:161  │               │
│  └──────────┘  └──────────────────────┘               │
│                                                         │
│  ┌──────────────────────────────────────┐              │
│  │         Kali Linux (Attacker)        │              │
│  │         192.168.1.100                │              │
│  │         msf-ot-cli + msfrpcd         │              │
│  └──────────────────────────────────────┘              │
└─────────────────────────────────────────────────────────┘
```

---

## الخطوة 1: إعداد GNS3

```bash
# تثبيت GNS3
sudo apt install gns3-gui gns3-server

# إضافة صور الأجهزة الوهمية
# - Cisco IOSv للـ switches
# - Linux Alpine للـ PLCs الوهمية
# - Windows Server 2019 للـ HMI
```

### إعداد الشبكة في GNS3:
1. أنشئ مشروع جديد: `OT-Security-Lab`
2. أضف Switch واحد
3. أضف 5 Linux VMs (PLC, HMI, RTU, EWS, Historian)
4. أضف Kali Linux VM
5. وصّل كل الأجهزة بالـ Switch

---

## الخطوة 2: محاكاة أجهزة OT

### PLC وهمي (Modbus TCP):
```bash
# على VM الـ PLC (192.168.1.10)
pip install pymodbus

# تشغيل Modbus server وهمي
python3 -c "
from pymodbus.server import StartTcpServer
from pymodbus.datastore import ModbusSlaveContext, ModbusServerContext
from pymodbus.datastore import ModbusSequentialDataBlock

store = ModbusSlaveContext(
    di=ModbusSequentialDataBlock(0, [17]*100),
    co=ModbusSequentialDataBlock(0, [17]*100),
    hr=ModbusSequentialDataBlock(0, [17]*100),
    ir=ModbusSequentialDataBlock(0, [17]*100),
)
context = ModbusServerContext(slaves=store, single=True)
StartTcpServer(context, address=('0.0.0.0', 502))
"
```

### RTU وهمي (DNP3):
```bash
# على VM الـ RTU (192.168.1.30)
# تشغيل netcat على منفذ DNP3
nc -l -p 20000 &
```

---

## الخطوة 3: إعداد Metasploit

```bash
# على Kali Linux (192.168.1.100)

# 1. تشغيل PostgreSQL
sudo systemctl start postgresql
sudo -u postgres createuser msf -P
sudo -u postgres createdb msf_db -O msf

# 2. إعداد MSF database
msfdb init

# 3. تشغيل msfrpcd
msfrpcd -P yourpassword -a 127.0.0.1 -n -f

# 4. التحقق من التشغيل
netstat -tlnp | grep 55553
```

---

## الخطوة 4: إعداد الأداة

```bash
# 1. استنساخ المشروع
cd /opt
git clone <repo> msf-ot-cli
cd msf-ot-cli

# 2. إنشاء بيئة افتراضية
python3 -m venv venv
source venv/bin/activate

# 3. تثبيت المكتبات
pip install -r requirements.txt
pip install -e .

# 4. إعداد .env للـ Lab
cat > .env << 'EOF'
MSF_HOST=127.0.0.1
MSF_PORT=55553
MSF_PASSWORD=yourpassword
MSF_SSL=true

# Lab Network
OT_DRY_RUN=false
OT_RATE_LIMIT=3
OT_SCAN_TIMEOUT=60
OT_MAX_THREADS=5

# حماية الشبكة الحقيقية
OT_BLACKLIST_RANGES=10.0.0.0/8,172.16.0.0/12
OT_ALLOWED_RANGES=192.168.1.0/24
EOF
```

---

## الخطوة 5: تشغيل الاختبارات

### اختبار الاتصال:
```bash
msf-ot status
```

### مسح الشبكة الوهمية:
```bash
# مسح المنافذ
msf-ot scan 192.168.1.0/24 -p 1-65535

# مسح Modbus على PLC
msf-ot scan 192.168.1.10 -m auxiliary/scanner/scada/modbusdetect

# مسح DNP3 على RTU
msf-ot scan 192.168.1.30 -m auxiliary/scanner/scada/dnp3_enumrouter

# مسح SNMP على Historian
msf-ot scan 192.168.1.50 -m auxiliary/scanner/snmp/snmp_enum

# مسح شامل بـ preset
msf-ot multiscan 192.168.1.0/24 --preset full --export-json --export-csv
```

### التحقق من OT Safety Blocks:
```bash
# يجب أن يُحظر
msf-ot scan 10.0.0.1  # blacklisted
msf-ot scan 192.168.1.10 -m exploit/windows/smb/ms17_010  # exploit blocked

# يجب أن يمر
msf-ot scan 192.168.1.10 -m auxiliary/scanner/scada/modbusdetect
```

---

## الخطوة 6: التحقق من النتائج

```bash
# فحص audit log
tail -f logs/audit.log

# فحص ملفات التصدير
ls -la reports/
cat reports/scan_*.json | python3 -m json.tool

# عرض الإعدادات
msf-ot config --show-ranges
```

---

## نتائج متوقعة

| الجهاز | IP | OT Protocols | Risk |
|--------|-----|-------------|------|
| PLC-01 | 192.168.1.10 | Modbus:502, EtherNet/IP:44818 | CRITICAL |
| HMI-01 | 192.168.1.20 | S7comm:102 | CRITICAL |
| RTU-01 | 192.168.1.30 | DNP3:20000, IEC-104:2404 | CRITICAL |
| EWS-01 | 192.168.1.40 | SSH:22, SMB:445 | LOW |
| Historian | 192.168.1.50 | SNMP:161 | MEDIUM |

---

## قواعد الأمان في Lab

1. **عزل الشبكة** — لا اتصال بالإنترنت أثناء الاختبار
2. **Dry-Run أولاً** — شغّل بـ `OT_DRY_RUN=true` للتحقق قبل التنفيذ
3. **Rate Limit منخفض** — `OT_RATE_LIMIT=3` لحماية الأجهزة الوهمية
4. **Threads منخفض** — `OT_MAX_THREADS=5` لتجنب الـ overload
5. **Audit Log** — راجع `logs/audit.log` بعد كل جلسة

---

## استكشاف الأخطاء

| المشكلة | الحل |
|---------|------|
| `Connection refused` | تأكد أن `msfrpcd` يعمل |
| `Authentication failed` | تحقق من `MSF_PASSWORD` في `.env` |
| `Module blocked` | استخدم `msf-ot modules` لعرض المسموح |
| `IP blocked` | تحقق من `OT_BLACKLIST_RANGES` في `.env` |
| `No hosts found` | تأكد أن PostgreSQL يعمل وـ DB مُعدّة |
