"""
test_scanner.py — اختبارات وحدة scanner.py
"""

import os
import time
import pytest
from unittest.mock import MagicMock, patch

os.environ.update({
    "MSF_PASSWORD"        : "testpassword123",
    "OT_DRY_RUN"          : "true",
    "OT_RATE_LIMIT"       : "100",
    "OT_BLACKLIST_RANGES" : "192.168.100.0/24",
    "OT_ALLOWED_RANGES"   : "192.168.1.0/24",
    "OT_WARN_RANGES"      : "192.168.0.0/16",
    "OT_MAX_THREADS"      : "10",
    "OT_SCAN_TIMEOUT"     : "30",
})

from msf_ot.scanner import (
    ScanStatus, ScanResult, HostResult, ServiceInfo,
    ResultsParser, JobMonitor, OTScanner,
    parse_module_path, ModulePathError,
)
from msf_ot.rpc_client import MsfClient


def make_mock_msf(jobs=None, hosts=None, services=None):
    msf = MagicMock(spec=MsfClient)
    msf.execute_module.return_value = "42"
    msf.is_job_running.return_value = False
    msf.db_hosts.return_value = hosts or []
    msf.db_services.return_value = services or []
    msf.get_jobs.return_value = jobs or {}
    return msf


class TestScanStatus:
    def test_all_statuses_exist(self):
        for name in ("PENDING","RUNNING","COMPLETED","DRY_RUN","FAILED","BLOCKED","TIMEOUT"):
            assert hasattr(ScanStatus, name)

    def test_is_success_completed(self):
        r = ScanResult(module="m", target="t", status=ScanStatus.COMPLETED)
        assert r.is_success is True

    def test_is_success_dry_run(self):
        r = ScanResult(module="m", target="t", status=ScanStatus.DRY_RUN)
        assert r.is_success is True

    def test_is_success_false_for_failed(self):
        r = ScanResult(module="m", target="t", status=ScanStatus.FAILED)
        assert r.is_success is False

    def test_is_success_false_for_blocked(self):
        r = ScanResult(module="m", target="t", status=ScanStatus.BLOCKED)
        assert r.is_success is False


class TestServiceInfo:
    def test_basic_service(self):
        svc = ServiceInfo(port=80, protocol="tcp", state="open", name="http")
        assert svc.port == 80
        assert svc.is_ot is False

    def test_modbus_port_auto_detected(self):
        svc = ServiceInfo(port=502, protocol="tcp", state="open")
        assert svc.is_ot is True
        assert svc.ot_risk == "critical"
        assert svc.name == "Modbus"

    def test_s7_port_auto_detected(self):
        svc = ServiceInfo(port=102, protocol="tcp", state="open")
        assert svc.is_ot is True

    def test_dnp3_port_auto_detected(self):
        svc = ServiceInfo(port=20000, protocol="tcp", state="open")
        assert svc.is_ot is True
        assert svc.ot_risk == "critical"

    def test_normal_port_not_ot(self):
        svc = ServiceInfo(port=8080, protocol="tcp", state="open")
        assert svc.is_ot is False
        assert svc.ot_risk == ""

    def test_custom_name_preserved(self):
        svc = ServiceInfo(port=502, protocol="tcp", state="open", name="custom")
        assert svc.name == "custom"


class TestHostResult:
    def _make_host(self):
        return HostResult(
            ip="192.168.1.1",
            services=[
                ServiceInfo(port=80,    protocol="tcp", state="open",   name="http"),
                ServiceInfo(port=502,   protocol="tcp", state="open"),
                ServiceInfo(port=443,   protocol="tcp", state="closed", name="https"),
                ServiceInfo(port=20000, protocol="tcp", state="open"),
            ]
        )

    def test_open_ports(self):
        host = self._make_host()
        assert 80 in host.open_ports
        assert 502 in host.open_ports
        assert 443 not in host.open_ports

    def test_ot_services(self):
        host = self._make_host()
        ot = host.ot_services
        assert len(ot) == 2
        ports = [s.port for s in ot]
        assert 502 in ports
        assert 20000 in ports

    def test_has_ot_services_true(self):
        host = self._make_host()
        assert host.has_ot_services is True

    def test_has_ot_services_false(self):
        host = HostResult(ip="10.0.0.1", services=[
            ServiceInfo(port=80, protocol="tcp", state="open", name="http")
        ])
        assert host.has_ot_services is False

    def test_risk_level_critical(self):
        host = self._make_host()
        assert host.risk_level == "critical"

    def test_risk_level_low_no_ot(self):
        host = HostResult(ip="10.0.0.1", services=[
            ServiceInfo(port=80, protocol="tcp", state="open", name="http")
        ])
        assert host.risk_level == "low"


class TestScanResult:
    def test_host_count(self):
        r = ScanResult(module="m", target="t")
        r.hosts = [HostResult(ip="1.1.1.1"), HostResult(ip="1.1.1.2")]
        assert r.host_count == 2

    def test_service_count(self):
        r = ScanResult(module="m", target="t")
        h1 = HostResult(ip="1.1.1.1", services=[
            ServiceInfo(port=80, protocol="tcp", state="open")
        ])
        h2 = HostResult(ip="1.1.1.2", services=[
            ServiceInfo(port=502, protocol="tcp", state="open"),
            ServiceInfo(port=443, protocol="tcp", state="open"),
        ])
        r.hosts = [h1, h2]
        assert r.service_count == 3

    def test_ot_host_count(self):
        r = ScanResult(module="m", target="t")
        r.hosts = [
            HostResult(ip="1.1.1.1", services=[ServiceInfo(port=502, protocol="tcp", state="open")]),
            HostResult(ip="1.1.1.2", services=[ServiceInfo(port=80,  protocol="tcp", state="open", name="http")]),
        ]
        assert r.ot_host_count == 1

    def test_dry_run_property(self):
        r = ScanResult(module="m", target="t", status=ScanStatus.DRY_RUN)
        assert r.dry_run is True

    def test_summary_keys(self):
        r = ScanResult(module="auxiliary/scanner/portscan/tcp", target="192.168.1.1")
        s = r.summary()
        for key in ("module","target","status","hosts","services","ot_hosts","duration_s","warnings","error"):
            assert key in s


class TestParseModulePath:
    def test_valid_path(self):
        t, n = parse_module_path("auxiliary/scanner/portscan/tcp")
        assert t == "auxiliary"
        assert n == "scanner/portscan/tcp"

    def test_valid_scada_path(self):
        t, n = parse_module_path("auxiliary/scanner/scada/modbusdetect")
        assert t == "auxiliary"
        assert n == "scanner/scada/modbusdetect"

    def test_empty_raises(self):
        with pytest.raises(ModulePathError):
            parse_module_path("")

    def test_none_raises(self):
        with pytest.raises(ModulePathError):
            parse_module_path(None)

    def test_no_slash_raises(self):
        with pytest.raises(ModulePathError):
            parse_module_path("auxiliary")

    def test_only_slash_raises(self):
        with pytest.raises(ModulePathError):
            parse_module_path("/")


class TestResultsParser:
    def test_parse_host_basic(self):
        raw = {"address": "192.168.1.1", "name": "plc-01", "os_name": "Linux", "state": "alive"}
        host = ResultsParser.parse_host(raw)
        assert host.ip == "192.168.1.1"
        assert host.hostname == "plc-01"
        assert host.os_name == "Linux"
        assert host.status == "alive"

    def test_parse_host_fallback_key(self):
        raw = {"host": "10.0.0.1"}
        host = ResultsParser.parse_host(raw)
        assert host.ip == "10.0.0.1"

    def test_parse_service_basic(self):
        raw = {"port": "80", "proto": "tcp", "state": "open", "name": "http", "info": "Apache 2.4"}
        svc = ResultsParser.parse_service(raw)
        assert svc.port == 80
        assert svc.protocol == "tcp"
        assert svc.state == "open"
        assert svc.version == "Apache 2.4"

    def test_parse_service_modbus(self):
        raw = {"port": "502", "proto": "tcp", "state": "open"}
        svc = ResultsParser.parse_service(raw)
        assert svc.port == 502
        assert svc.is_ot is True

    def test_build_hosts_links_services(self):
        raw_hosts = [
            {"address": "192.168.1.1", "state": "alive"},
            {"address": "192.168.1.2", "state": "alive"},
        ]
        raw_services = [
            {"host": "192.168.1.1", "port": "80",  "proto": "tcp", "state": "open"},
            {"host": "192.168.1.1", "port": "502", "proto": "tcp", "state": "open"},
            {"host": "192.168.1.2", "port": "443", "proto": "tcp", "state": "open"},
        ]
        hosts = ResultsParser.build_hosts(raw_hosts, raw_services)
        assert len(hosts) == 2
        h1 = next(h for h in hosts if h.ip == "192.168.1.1")
        h2 = next(h for h in hosts if h.ip == "192.168.1.2")
        assert len(h1.services) == 2
        assert len(h2.services) == 1

    def test_build_hosts_sorted_by_port(self):
        raw_hosts = [{"address": "192.168.1.1", "state": "alive"}]
        raw_services = [
            {"host": "192.168.1.1", "port": "443", "proto": "tcp", "state": "open"},
            {"host": "192.168.1.1", "port": "80",  "proto": "tcp", "state": "open"},
            {"host": "192.168.1.1", "port": "22",  "proto": "tcp", "state": "open"},
        ]
        hosts = ResultsParser.build_hosts(raw_hosts, raw_services)
        ports = [s.port for s in hosts[0].services]
        assert ports == sorted(ports)

    def test_build_hosts_no_services(self):
        raw_hosts = [{"address": "192.168.1.1", "state": "alive"}]
        hosts = ResultsParser.build_hosts(raw_hosts, [])
        assert len(hosts) == 1
        assert len(hosts[0].services) == 0

    def test_build_hosts_empty(self):
        hosts = ResultsParser.build_hosts([], [])
        assert hosts == []


class TestJobMonitor:
    def test_job_completes_immediately(self):
        msf = make_mock_msf()
        msf.is_job_running.return_value = False
        monitor = JobMonitor(msf, "42", timeout=5, poll_interval=0.1)
        status = monitor.wait()
        assert status == ScanStatus.COMPLETED

    def test_job_completes_after_delay(self):
        msf = make_mock_msf()
        call_count = {"n": 0}
        def side_effect(job_id):
            call_count["n"] += 1
            return call_count["n"] < 3
        msf.is_job_running.side_effect = side_effect
        monitor = JobMonitor(msf, "42", timeout=10, poll_interval=0.05)
        status = monitor.wait()
        assert status == ScanStatus.COMPLETED

    def test_job_timeout(self):
        msf = make_mock_msf()
        msf.is_job_running.return_value = True
        monitor = JobMonitor(msf, "42", timeout=1, poll_interval=0.2)
        status = monitor.wait()
        assert status == ScanStatus.TIMEOUT

    def test_job_poll_error_returns_failed(self):
        msf = make_mock_msf()
        msf.is_job_running.side_effect = Exception("RPC error")
        monitor = JobMonitor(msf, "42", timeout=5, poll_interval=0.1)
        status = monitor.wait()
        assert status == ScanStatus.FAILED

    def test_on_tick_callback_called(self):
        msf = make_mock_msf()
        call_count = {"n": 0}
        def side_effect(job_id):
            call_count["n"] += 1
            return call_count["n"] < 3
        msf.is_job_running.side_effect = side_effect
        ticks = []
        def on_tick(elapsed, total):
            ticks.append(elapsed)
        monitor = JobMonitor(msf, "42", timeout=10, poll_interval=0.05, on_tick=on_tick)
        monitor.wait()
        assert len(ticks) >= 1


class TestOTScannerDryRun:
    def setup_method(self):
        self.msf = make_mock_msf()
        self.scanner = OTScanner(self.msf)

    def test_scan_returns_dry_run_status(self):
        result = self.scanner.scan(
            module_path="auxiliary/scanner/portscan/tcp",
            target="192.168.1.1",
        )
        assert result.status == ScanStatus.DRY_RUN
        assert result.dry_run is True

    def test_scan_dry_run_no_msf_calls(self):
        self.scanner.scan(
            module_path="auxiliary/scanner/portscan/tcp",
            target="192.168.1.1",
        )
        self.msf.execute_module.assert_not_called()

    def test_scan_blocked_module(self):
        result = self.scanner.scan(
            module_path="exploit/windows/smb/ms17_010",
            target="192.168.1.1",
        )
        assert result.status == ScanStatus.BLOCKED
        assert result.error is not None

    def test_scan_blocked_ip(self):
        result = self.scanner.scan(
            module_path="auxiliary/scanner/portscan/tcp",
            target="192.168.100.1",
        )
        assert result.status == ScanStatus.BLOCKED

    def test_scan_result_has_module_and_target(self):
        result = self.scanner.scan(
            module_path="auxiliary/scanner/portscan/tcp",
            target="192.168.1.1",
        )
        assert result.module == "auxiliary/scanner/portscan/tcp"
        assert result.target == "192.168.1.1"

    def test_scan_result_has_duration(self):
        result = self.scanner.scan(
            module_path="auxiliary/scanner/portscan/tcp",
            target="192.168.1.1",
        )
        assert result.duration >= 0

    def test_scan_ot_port_warning_added(self):
        result = self.scanner.scan(
            module_path="auxiliary/scanner/portscan/tcp",
            target="192.168.1.1",
            ports="502",
        )
        assert len(result.warnings) > 0

    def test_dry_scan_always_dry_run(self):
        result = self.scanner.dry_scan(
            module_path="auxiliary/scanner/portscan/tcp",
            target="192.168.1.1",
        )
        assert result.status == ScanStatus.DRY_RUN

    def test_scan_multi_dry_run(self):
        modules = [
            "auxiliary/scanner/portscan/tcp",
            "auxiliary/scanner/snmp/snmp_enum",
        ]
        results = self.scanner.scan_multi(modules, "192.168.1.1")
        assert len(results) == 2
        for r in results:
            assert r.status == ScanStatus.DRY_RUN

    def test_scan_multi_stops_on_blocked(self):
        modules = [
            "exploit/windows/smb/ms17_010",
            "auxiliary/scanner/portscan/tcp",
        ]
        results = self.scanner.scan_multi(modules, "192.168.1.1")
        assert len(results) == 1
        assert results[0].status == ScanStatus.BLOCKED


class TestOTScannerLiveMode:
    def setup_method(self):
        self.msf = make_mock_msf()
        self.scanner = OTScanner(self.msf)

    def test_scan_live_calls_execute_module(self):
        with patch("msf_ot.scanner.OT_DRY_RUN", False):
            self.msf.is_job_running.return_value = False
            result = self.scanner.scan(
                module_path="auxiliary/scanner/portscan/tcp",
                target="192.168.1.1",
                ports="80,443",
                threads=5,
            )
        self.msf.execute_module.assert_called_once()

    def test_scan_live_sets_rhosts(self):
        with patch("msf_ot.scanner.OT_DRY_RUN", False):
            self.msf.is_job_running.return_value = False
            self.scanner.scan(
                module_path="auxiliary/scanner/portscan/tcp",
                target="192.168.1.1",
                ports="80",
            )
        call_args = self.msf.execute_module.call_args
        options = call_args[0][2]
        assert options["RHOSTS"] == "192.168.1.1"

    def test_scan_live_sets_ports(self):
        with patch("msf_ot.scanner.OT_DRY_RUN", False):
            self.msf.is_job_running.return_value = False
            self.scanner.scan(
                module_path="auxiliary/scanner/portscan/tcp",
                target="192.168.1.1",
                ports="1-1024",
            )
        call_args = self.msf.execute_module.call_args
        options = call_args[0][2]
        assert options["PORTS"] == "1-1024"

    def test_scan_live_threads_capped_at_max(self):
        with patch("msf_ot.scanner.OT_DRY_RUN", False):
            self.msf.is_job_running.return_value = False
            self.scanner.scan(
                module_path="auxiliary/scanner/portscan/tcp",
                target="192.168.1.1",
                threads=999,
            )
        call_args = self.msf.execute_module.call_args
        options = call_args[0][2]
        assert options["THREADS"] <= 10

    def test_scan_live_completed_status(self):
        with patch("msf_ot.scanner.OT_DRY_RUN", False):
            self.msf.is_job_running.return_value = False
            result = self.scanner.scan(
                module_path="auxiliary/scanner/portscan/tcp",
                target="192.168.1.1",
            )
        assert result.status == ScanStatus.COMPLETED

    def test_scan_live_collects_hosts(self):
        raw_hosts = [{"address": "192.168.1.1", "state": "alive"}]
        raw_services = [{"host": "192.168.1.1", "port": "80", "proto": "tcp", "state": "open"}]
        self.msf.db_hosts.return_value = raw_hosts
        self.msf.db_services.return_value = raw_services
        with patch("msf_ot.scanner.OT_DRY_RUN", False):
            self.msf.is_job_running.return_value = False
            result = self.scanner.scan(
                module_path="auxiliary/scanner/portscan/tcp",
                target="192.168.1.1",
            )
        assert result.host_count == 1
        assert result.service_count == 1

    def test_scan_live_module_error_returns_failed(self):
        from msf_ot.rpc_client import ModuleError
        self.msf.execute_module.side_effect = ModuleError("Module not found")
        with patch("msf_ot.scanner.OT_DRY_RUN", False):
            result = self.scanner.scan(
                module_path="auxiliary/scanner/portscan/tcp",
                target="192.168.1.1",
            )
        assert result.status == ScanStatus.FAILED
        assert result.error is not None

    def test_scan_live_timeout_still_collects(self):
        self.msf.is_job_running.return_value = True
        raw_hosts = [{"address": "192.168.1.1", "state": "alive"}]
        self.msf.db_hosts.return_value = raw_hosts
        with patch("msf_ot.scanner.OT_DRY_RUN", False):
            result = self.scanner.scan(
                module_path="auxiliary/scanner/portscan/tcp",
                target="192.168.1.1",
                timeout=1,
            )
        assert result.status == ScanStatus.TIMEOUT
        assert result.host_count == 1

    def test_scan_live_extra_options_passed(self):
        with patch("msf_ot.scanner.OT_DRY_RUN", False):
            self.msf.is_job_running.return_value = False
            self.scanner.scan(
                module_path="auxiliary/scanner/portscan/tcp",
                target="192.168.1.1",
                options={"TIMEOUT": "10", "VERBOSE": "true"},
            )
        call_args = self.msf.execute_module.call_args
        options = call_args[0][2]
        assert options.get("TIMEOUT") == "10"
        assert options.get("VERBOSE") == "true"

    def test_scan_live_rhosts_not_overridden_by_options(self):
        with patch("msf_ot.scanner.OT_DRY_RUN", False):
            self.msf.is_job_running.return_value = False
            self.scanner.scan(
                module_path="auxiliary/scanner/portscan/tcp",
                target="192.168.1.1",
                options={"RHOSTS": "10.0.0.1"},
            )
        call_args = self.msf.execute_module.call_args
        options = call_args[0][2]
        assert options["RHOSTS"] == "192.168.1.1"


class TestOTScannerStaticMethods:
    def test_get_allowed_modules_not_empty(self):
        modules = OTScanner.get_allowed_modules()
        assert len(modules) > 0

    def test_get_allowed_modules_returns_list(self):
        assert isinstance(OTScanner.get_allowed_modules(), list)

    def test_search_modules_found(self):
        results = OTScanner.search_modules("portscan")
        assert len(results) > 0
        assert all("portscan" in m for m in results)

    def test_search_modules_scada(self):
        results = OTScanner.search_modules("scada")
        assert len(results) > 0

    def test_search_modules_not_found(self):
        results = OTScanner.search_modules("xyznotexist")
        assert results == []

    def test_search_modules_case_insensitive(self):
        lower = OTScanner.search_modules("modbus")
        upper = OTScanner.search_modules("MODBUS")
        assert lower == upper

    def test_get_modules_by_category_portscan(self):
        results = OTScanner.get_modules_by_category("portscan")
        assert len(results) > 0
        assert all("portscan" in m for m in results)

    def test_get_modules_by_category_scada(self):
        results = OTScanner.get_modules_by_category("scada")
        assert len(results) > 0

    def test_is_module_allowed_true(self):
        assert OTScanner.is_module_allowed("auxiliary/scanner/portscan/tcp") is True

    def test_is_module_allowed_false(self):
        assert OTScanner.is_module_allowed("exploit/windows/smb/ms17_010") is False

    def test_get_module_categories_not_empty(self):
        cats = OTScanner.get_module_categories()
        assert len(cats) > 0
        assert "portscan" in cats
        assert "scada" in cats

    def test_get_module_categories_sorted(self):
        cats = OTScanner.get_module_categories()
        assert cats == sorted(cats)
