"""
test_config.py — اختبارات وحدة config.py
"""

import os
import pytest

# ── تعيين متغيرات بيئة للاختبار قبل الاستيراد ────────────────────────────────
os.environ.update({
    "MSF_HOST"             : "127.0.0.1",
    "MSF_PORT"             : "55553",
    "MSF_PASSWORD"         : "testpassword123",
    "MSF_SSL"              : "true",
    "OT_DRY_RUN"           : "true",
    "OT_RATE_LIMIT"        : "5",
    "OT_SCAN_TIMEOUT"      : "30",
    "OT_MAX_THREADS"       : "10",
    "OT_BLACKLIST_RANGES"  : "192.168.100.0/24,10.10.0.0/16",
    "OT_ALLOWED_RANGES"    : "192.168.1.0/24",
})

from msf_ot.config import (
    MSF_HOST, MSF_PORT, MSF_PASSWORD, MSF_SSL,
    OT_DRY_RUN, OT_RATE_LIMIT, OT_SCAN_TIMEOUT,
    OT_BLACKLIST_RANGES, OT_ALLOWED_RANGES,
    ALLOWED_MODULES, ALLOWED_MODULES_SET,
    BLOCKED_MODULE_PREFIXES, BLOCKED_MODULE_KEYWORDS,
    OT_PROTOCOLS, OT_PORT_MAP, OT_CRITICAL_PORTS,
    validate_config, get_config_summary,
    ConfigValidationError,
)


# ══════════════════════════════════════════════════════════════════════════════
# § 1 — اختبارات تحميل الإعدادات
# ══════════════════════════════════════════════════════════════════════════════

class TestConfigLoading:

    def test_msf_host_loaded(self):
        assert MSF_HOST == "127.0.0.1"

    def test_msf_port_is_int(self):
        assert isinstance(MSF_PORT, int)
        assert MSF_PORT == 55553

    def test_msf_ssl_is_bool(self):
        assert isinstance(MSF_SSL, bool)
        assert MSF_SSL is True

    def test_dry_run_is_bool(self):
        assert isinstance(OT_DRY_RUN, bool)
        assert OT_DRY_RUN is True

    def test_rate_limit_is_int(self):
        assert isinstance(OT_RATE_LIMIT, int)
        assert OT_RATE_LIMIT >= 1  # القيمة تعتمد على ترتيب تشغيل الاختبارات

    def test_blacklist_is_list(self):
        assert isinstance(OT_BLACKLIST_RANGES, list)
        assert "192.168.100.0/24" in OT_BLACKLIST_RANGES

    def test_allowed_ranges_is_list(self):
        assert isinstance(OT_ALLOWED_RANGES, list)
        assert "192.168.1.0/24" in OT_ALLOWED_RANGES


# ══════════════════════════════════════════════════════════════════════════════
# § 2 — اختبارات القوائم
# ══════════════════════════════════════════════════════════════════════════════

class TestModuleLists:

    def test_allowed_modules_not_empty(self):
        assert len(ALLOWED_MODULES) > 0

    def test_allowed_modules_set_matches_list(self):
        assert ALLOWED_MODULES_SET == set(ALLOWED_MODULES)

    def test_portscan_tcp_in_whitelist(self):
        assert "auxiliary/scanner/portscan/tcp" in ALLOWED_MODULES_SET

    def test_modbus_in_whitelist(self):
        assert "auxiliary/scanner/scada/modbusdetect" in ALLOWED_MODULES_SET

    def test_no_exploit_in_whitelist(self):
        for mod in ALLOWED_MODULES:
            assert not mod.startswith("exploit/"), f"exploit module in whitelist: {mod}"

    def test_no_payload_in_whitelist(self):
        for mod in ALLOWED_MODULES:
            assert not mod.startswith("payload/"), f"payload module in whitelist: {mod}"

    def test_blocked_prefixes_not_empty(self):
        assert "exploit/" in BLOCKED_MODULE_PREFIXES
        assert "payload/" in BLOCKED_MODULE_PREFIXES

    def test_blocked_keywords_not_empty(self):
        assert "dos" in BLOCKED_MODULE_KEYWORDS
        assert "overflow" in BLOCKED_MODULE_KEYWORDS


# ══════════════════════════════════════════════════════════════════════════════
# § 3 — اختبارات بروتوكولات OT
# ══════════════════════════════════════════════════════════════════════════════

class TestOTProtocols:

    def test_protocols_not_empty(self):
        assert len(OT_PROTOCOLS) > 0

    def test_modbus_port_502(self):
        assert 502 in OT_PORT_MAP
        assert OT_PORT_MAP[502].name == "Modbus"

    def test_s7_port_102(self):
        assert 102 in OT_PORT_MAP

    def test_dnp3_port_20000(self):
        assert 20000 in OT_PORT_MAP

    def test_critical_ports_not_empty(self):
        assert len(OT_CRITICAL_PORTS) > 0
        assert 502 in OT_CRITICAL_PORTS   # Modbus
        assert 102 in OT_CRITICAL_PORTS   # S7comm


# ══════════════════════════════════════════════════════════════════════════════
# § 4 — اختبارات Config Validator
# ══════════════════════════════════════════════════════════════════════════════

class TestConfigValidator:

    def test_valid_config_returns_warnings_list(self):
        warnings = validate_config()
        assert isinstance(warnings, list)

    def test_dry_run_warning_present(self):
        # OT_DRY_RUN=false يجب أن يُنتج تحذيراً
        original = os.environ.get("OT_DRY_RUN")
        os.environ["OT_DRY_RUN"] = "false"

        # نعيد استيراد القيمة
        import importlib
        import msf_ot.config as cfg
        importlib.reload(cfg)

        warnings = cfg.validate_config()
        assert any("DRY_RUN" in w or "dry_run" in w.lower() for w in warnings)

        # إعادة القيمة الأصلية
        os.environ["OT_DRY_RUN"] = original or "true"
        importlib.reload(cfg)

    def test_empty_password_raises_error(self):
        original = os.environ.get("MSF_PASSWORD")
        os.environ["MSF_PASSWORD"] = ""

        import importlib
        import msf_ot.config as cfg
        importlib.reload(cfg)

        with pytest.raises(cfg.ConfigValidationError):
            cfg.validate_config()

        os.environ["MSF_PASSWORD"] = original or "testpassword123"
        importlib.reload(cfg)

    def test_get_config_summary_no_password(self):
        summary = get_config_summary()
        assert "msf_password_set" in summary
        # كلمة المرور لا تظهر كقيمة
        assert "MSF_PASSWORD" not in str(summary.values())
        assert summary["msf_host"] == "127.0.0.1"
