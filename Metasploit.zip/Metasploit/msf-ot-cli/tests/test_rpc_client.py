"""
test_rpc_client.py — اختبارات وحدة rpc_client.py
==================================================
يستخدم unittest.mock لمحاكاة MsfRpcClient
بدون الحاجة لـ msfrpcd حقيقي.
"""

import os
import time
import threading
import pytest
from unittest.mock import MagicMock, patch, PropertyMock

os.environ.update({
    "MSF_HOST"     : "127.0.0.1",
    "MSF_PORT"     : "55553",
    "MSF_PASSWORD" : "testpassword123",
    "MSF_SSL"      : "true",
    "OT_DRY_RUN"   : "true",
})

from msf_ot.rpc_client import (
    MsfClient,
    ConnState,
    ConnectionInfo,
    MetasploitRPCError,
    ConnectionError,
    AuthenticationError,
    ModuleError,
    JobError,
    DatabaseError,
)


# ══════════════════════════════════════════════════════════════════════════════
# Fixtures — Mock MsfRpcClient
# ══════════════════════════════════════════════════════════════════════════════

def make_mock_rpc(
    version_data : dict  = None,
    jobs         : dict  = None,
    sessions     : dict  = None,
    db_status    : dict  = None,
    hosts        : dict  = None,
    services     : dict  = None,
    vulns        : dict  = None,
):
    """يُنشئ MsfRpcClient mock مع بيانات افتراضية."""
    mock = MagicMock()

    # core.version()
    mock.core.version.return_value = version_data or {
        "version": "6.3.0",
        "ruby"   : "3.1.0",
        "api"    : "1.0",
    }

    # jobs.list
    mock.jobs.list = jobs or {}

    # sessions.list
    mock.sessions.list = sessions or {}

    # db.status()
    mock.db.status.return_value = db_status or {"db": "connected"}

    # db.hosts()
    mock.db.hosts.return_value = hosts or {"hosts": []}

    # db.services()
    mock.db.services.return_value = services or {"services": []}

    # db.vulns()
    mock.db.vulns.return_value = vulns or {"vulns": []}

    # logout
    mock.logout.return_value = None

    return mock


@pytest.fixture
def mock_rpc():
    """Fixture: MsfRpcClient mock جاهز."""
    return make_mock_rpc()


@pytest.fixture
def connected_client(mock_rpc):
    """Fixture: MsfClient متصل مع mock."""
    with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc):
        client = MsfClient(
            host="127.0.0.1",
            port=55553,
            password="testpassword123",
            ssl=False,
        )
        client.connect()
        yield client


# ══════════════════════════════════════════════════════════════════════════════
# § 1 — اختبارات ConnectionInfo
# ══════════════════════════════════════════════════════════════════════════════

class TestConnectionInfo:

    def test_initial_state_disconnected(self):
        info = ConnectionInfo()
        assert info.state == ConnState.DISCONNECTED
        assert info.is_connected is False

    def test_uptime_zero_when_disconnected(self):
        info = ConnectionInfo()
        assert info.uptime == 0.0

    def test_uptime_positive_when_connected(self):
        info = ConnectionInfo()
        info.state = ConnState.CONNECTED
        info.connected_at = time.monotonic() - 5.0
        assert info.uptime >= 5.0

    def test_is_connected_true_only_when_connected(self):
        info = ConnectionInfo()
        for state in ConnState:
            info.state = state
            if state == ConnState.CONNECTED:
                assert info.is_connected is True
            else:
                assert info.is_connected is False


# ══════════════════════════════════════════════════════════════════════════════
# § 2 — اختبارات connect()
# ══════════════════════════════════════════════════════════════════════════════

class TestConnect:

    def test_successful_connection(self, mock_rpc):
        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc):
            client = MsfClient(password="testpassword123", ssl=False)
            result = client.connect()

            assert result is client
            assert client.info.is_connected is True
            assert client.info.state == ConnState.CONNECTED
            assert client.info.msf_version == "6.3.0"

    def test_connect_returns_self(self, mock_rpc):
        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc):
            client = MsfClient(password="testpassword123", ssl=False)
            assert client.connect() is client

    def test_connect_sets_version_info(self, mock_rpc):
        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc):
            client = MsfClient(password="testpassword123", ssl=False)
            client.connect()
            assert client.info.msf_version == "6.3.0"
            assert client.info.msf_ruby    == "3.1.0"
            assert client.info.msf_api     == "1.0"

    def test_already_connected_skips_reconnect(self, mock_rpc):
        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc) as mock_cls:
            client = MsfClient(password="testpassword123", ssl=False)
            client.connect()
            client.connect()  # ثانية — يجب ألا يُنشئ client جديد
            assert mock_cls.call_count == 1

    def test_connection_failure_raises_connection_error(self):
        with patch(
            "msf_ot.rpc_client.MsfRpcClient",
            side_effect=Exception("Connection refused")
        ):
            client = MsfClient(
                password="testpassword123",
                ssl=False,
                max_retries=2,
                retry_delay=0.01,
            )
            with pytest.raises(ConnectionError) as exc:
                client.connect()
            assert "msfrpcd" in str(exc.value)

    def test_auth_failure_raises_authentication_error(self):
        with patch(
            "msf_ot.rpc_client.MsfRpcClient",
            side_effect=Exception("Login failed: bad password")
        ):
            client = MsfClient(
                password="wrongpassword",
                ssl=False,
                max_retries=3,
                retry_delay=0.01,
            )
            with pytest.raises(AuthenticationError) as exc:
                client.connect()
            assert "مصادقة" in str(exc.value) or "auth" in str(exc.value).lower()

    def test_retry_count_respected(self):
        call_count = {"n": 0}

        def failing_init(*args, **kwargs):
            call_count["n"] += 1
            raise Exception("Connection refused")

        with patch("msf_ot.rpc_client.MsfRpcClient", side_effect=failing_init):
            client = MsfClient(
                password="testpassword123",
                ssl=False,
                max_retries=3,
                retry_delay=0.01,
            )
            with pytest.raises(ConnectionError):
                client.connect()

        assert call_count["n"] == 3

    def test_state_is_failed_after_all_retries(self):
        with patch(
            "msf_ot.rpc_client.MsfRpcClient",
            side_effect=Exception("refused")
        ):
            client = MsfClient(
                password="testpassword123",
                ssl=False,
                max_retries=2,
                retry_delay=0.01,
            )
            with pytest.raises(ConnectionError):
                client.connect()
        assert client.info.state == ConnState.FAILED


# ══════════════════════════════════════════════════════════════════════════════
# § 3 — اختبارات disconnect()
# ══════════════════════════════════════════════════════════════════════════════

class TestDisconnect:

    def test_disconnect_clears_client(self, connected_client):
        connected_client.disconnect()
        assert connected_client._client is None
        assert connected_client.info.state == ConnState.DISCONNECTED

    def test_disconnect_calls_logout(self, mock_rpc, connected_client):
        connected_client.disconnect()
        mock_rpc.logout.assert_called_once()

    def test_disconnect_when_not_connected_is_safe(self):
        client = MsfClient(password="testpassword123", ssl=False)
        client.disconnect()  # يجب ألا يرفع استثناء

    def test_disconnect_handles_logout_error(self, mock_rpc):
        mock_rpc.logout.side_effect = Exception("Logout error")
        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc):
            client = MsfClient(password="testpassword123", ssl=False)
            client.connect()
            client.disconnect()  # يجب ألا يرفع استثناء
        assert client._client is None


# ══════════════════════════════════════════════════════════════════════════════
# § 4 — اختبارات Context Manager
# ══════════════════════════════════════════════════════════════════════════════

class TestContextManager:

    def test_with_statement_connects_and_disconnects(self, mock_rpc):
        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc):
            with MsfClient(password="testpassword123", ssl=False) as msf:
                assert msf.info.is_connected is True
            # بعد الخروج من الـ with
            assert msf.info.state == ConnState.DISCONNECTED

    def test_with_statement_disconnects_on_exception(self, mock_rpc):
        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc):
            client_ref = None
            try:
                with MsfClient(password="testpassword123", ssl=False) as msf:
                    client_ref = msf
                    raise ValueError("Test exception")
            except ValueError:
                pass
            assert client_ref._client is None

    def test_with_statement_returns_msf_client(self, mock_rpc):
        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc):
            with MsfClient(password="testpassword123", ssl=False) as msf:
                assert isinstance(msf, MsfClient)


# ══════════════════════════════════════════════════════════════════════════════
# § 5 — اختبارات ping() و health_check()
# ══════════════════════════════════════════════════════════════════════════════

class TestHealthCheck:

    def test_ping_returns_true_when_connected(self, connected_client):
        assert connected_client.ping() is True

    def test_ping_returns_false_when_version_fails(self, mock_rpc):
        """يتحقق أن ping يُعيد False عند فشل core.version بعد الاتصال."""
        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc):
            client = MsfClient(password="testpassword123", ssl=False)
            client.connect()
            assert client.info.is_connected is True

            # الآن نجعل version يفشل لمحاكاة انقطاع الاتصال
            mock_rpc.core.version.side_effect = Exception("timeout")
            # نمنع _ensure_connected من إعادة الاتصال بتعطيل connect
            with patch.object(client, "_ensure_connected", return_value=None):
                result = client.ping()
        assert result is False

    def test_health_check_returns_dict(self, connected_client):
        result = connected_client.health_check()
        assert isinstance(result, dict)

    def test_health_check_connected_true(self, connected_client):
        result = connected_client.health_check()
        assert result["connected"] is True

    def test_health_check_has_version(self, connected_client):
        result = connected_client.health_check()
        assert result["msf_version"] == "6.3.0"

    def test_health_check_has_uptime(self, connected_client):
        result = connected_client.health_check()
        assert result["uptime_s"] >= 0

    def test_health_check_db_connected(self, connected_client):
        result = connected_client.health_check()
        assert result["db_connected"] is True

    def test_health_check_error_when_disconnected(self):
        client = MsfClient(password="testpassword123", ssl=False, max_retries=1, retry_delay=0.01)
        with patch("msf_ot.rpc_client.MsfRpcClient", side_effect=Exception("refused")):
            result = client.health_check()
        assert result["connected"] is False
        assert result["error"] is not None


# ══════════════════════════════════════════════════════════════════════════════
# § 6 — اختبارات Module API
# ══════════════════════════════════════════════════════════════════════════════

class TestModuleAPI:

    def test_get_version(self, connected_client):
        ver = connected_client.get_version()
        assert ver["version"] == "6.3.0"

    def test_list_auxiliary_modules(self, mock_rpc, connected_client):
        mock_rpc.modules.auxiliary = ["scanner/portscan/tcp", "scanner/smb/smb_version"]
        modules = connected_client.list_auxiliary_modules()
        assert isinstance(modules, list)
        assert "scanner/portscan/tcp" in modules

    def test_load_module_success(self, mock_rpc, connected_client):
        mock_module = MagicMock()
        mock_module.name = "TCP Port Scanner"
        mock_rpc.modules.use.return_value = mock_module

        mod = connected_client.load_module("auxiliary", "scanner/portscan/tcp")
        assert mod is mock_module
        mock_rpc.modules.use.assert_called_with("auxiliary", "scanner/portscan/tcp")

    def test_load_module_failure_raises_module_error(self, mock_rpc, connected_client):
        mock_rpc.modules.use.side_effect = Exception("Module not found")
        with pytest.raises(ModuleError) as exc:
            connected_client.load_module("auxiliary", "scanner/unknown/module")
        assert "scanner/unknown/module" in str(exc.value)

    def test_execute_module_returns_job_id(self, mock_rpc, connected_client):
        mock_module = MagicMock()
        mock_module.execute.return_value = {"job_id": "42"}
        mock_rpc.modules.use.return_value = mock_module

        job_id = connected_client.execute_module(
            "auxiliary",
            "scanner/portscan/tcp",
            {"RHOSTS": "192.168.1.1", "PORTS": "80"},
        )
        assert job_id == "42"

    def test_execute_module_sets_options(self, mock_rpc, connected_client):
        mock_module = MagicMock()
        mock_module.execute.return_value = {"job_id": "1"}
        mock_rpc.modules.use.return_value = mock_module

        connected_client.execute_module(
            "auxiliary",
            "scanner/portscan/tcp",
            {"RHOSTS": "192.168.1.1", "THREADS": "5"},
        )
        # تحقق أن الخيارات ضُبطت
        mock_module.__setitem__.assert_any_call("RHOSTS", "192.168.1.1")
        mock_module.__setitem__.assert_any_call("THREADS", "5")

    def test_module_info_returns_dict(self, mock_rpc, connected_client):
        mock_module = MagicMock()
        mock_module.name        = "TCP Port Scanner"
        mock_module.description = "Scans TCP ports"
        mock_module.options     = {"RHOSTS": {}, "PORTS": {}}
        mock_module.required    = ["RHOSTS"]
        mock_rpc.modules.use.return_value = mock_module

        info = connected_client.module_info("auxiliary", "scanner/portscan/tcp")
        assert info["name"] == "TCP Port Scanner"
        assert "RHOSTS" in info["options"]


# ══════════════════════════════════════════════════════════════════════════════
# § 7 — اختبارات Job API
# ══════════════════════════════════════════════════════════════════════════════

class TestJobAPI:

    def test_get_jobs_empty(self, connected_client):
        jobs = connected_client.get_jobs()
        assert isinstance(jobs, dict)
        assert len(jobs) == 0

    def test_get_jobs_with_active_jobs(self, mock_rpc):
        mock_rpc.jobs.list = {"1": {"name": "TCP Scanner"}, "2": {"name": "SMB Scanner"}}
        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc):
            client = MsfClient(password="testpassword123", ssl=False)
            client.connect()
            jobs = client.get_jobs()
        assert len(jobs) == 2
        assert "1" in jobs

    def test_is_job_running_true(self, mock_rpc):
        mock_rpc.jobs.list = {"42": {"name": "Scanner"}}
        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc):
            client = MsfClient(password="testpassword123", ssl=False)
            client.connect()
            assert client.is_job_running("42") is True

    def test_is_job_running_false(self, connected_client):
        assert connected_client.is_job_running("999") is False

    def test_wait_for_job_completes(self, mock_rpc):
        """Job ينتهي بعد المحاولة الثانية."""
        call_count = {"n": 0}
        original_list = {"42": {"name": "Scanner"}}

        def dynamic_list():
            call_count["n"] += 1
            if call_count["n"] >= 2:
                return {}  # Job انتهى
            return original_list

        mock_rpc.jobs.list = property(lambda self: dynamic_list())
        type(mock_rpc.jobs).list = PropertyMock(side_effect=dynamic_list)

        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc):
            client = MsfClient(password="testpassword123", ssl=False)
            client.connect()
            result = client.wait_for_job("42", timeout=5, interval=0.1)
        assert result is True

    def test_wait_for_job_timeout(self, mock_rpc):
        """Job لا ينتهي — يجب أن يُعيد False."""
        mock_rpc.jobs.list = {"42": {"name": "Scanner"}}
        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc):
            client = MsfClient(password="testpassword123", ssl=False)
            client.connect()
            result = client.wait_for_job("42", timeout=1, interval=0.2)
        assert result is False

    def test_stop_job(self, mock_rpc, connected_client):
        result = connected_client.stop_job("42")
        assert result is True
        mock_rpc.jobs.stop.assert_called_with("42")

    def test_stop_all_jobs(self, mock_rpc):
        mock_rpc.jobs.list = {"1": {}, "2": {}, "3": {}}
        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc):
            client = MsfClient(password="testpassword123", ssl=False)
            client.connect()
            stopped = client.stop_all_jobs()
        assert stopped == 3


# ══════════════════════════════════════════════════════════════════════════════
# § 8 — اختبارات Database API
# ══════════════════════════════════════════════════════════════════════════════

class TestDatabaseAPI:

    def test_db_status_connected(self, connected_client):
        status = connected_client.db_status()
        assert status["db"] == "connected"

    def test_db_hosts_empty(self, connected_client):
        hosts = connected_client.db_hosts()
        assert isinstance(hosts, list)

    def test_db_hosts_with_data(self, mock_rpc):
        mock_rpc.db.hosts.return_value = {
            "hosts": [
                {"address": "192.168.1.1", "name": "plc-01", "os_name": "Linux"},
                {"address": "192.168.1.2", "name": "hmi-01", "os_name": "Windows"},
            ]
        }
        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc):
            client = MsfClient(password="testpassword123", ssl=False)
            client.connect()
            hosts = client.db_hosts()
        assert len(hosts) == 2
        assert hosts[0]["address"] == "192.168.1.1"

    def test_db_services_empty(self, connected_client):
        services = connected_client.db_services()
        assert isinstance(services, list)

    def test_db_services_with_host_filter(self, mock_rpc, connected_client):
        connected_client.db_services(host_ip="192.168.1.1")
        mock_rpc.db.services.assert_called_with({"hosts": ["192.168.1.1"]})

    def test_db_vulns_empty(self, connected_client):
        vulns = connected_client.db_vulns()
        assert isinstance(vulns, list)

    def test_db_status_error_raises_database_error(self, mock_rpc, connected_client):
        mock_rpc.db.status.side_effect = Exception("DB not connected")
        with pytest.raises(DatabaseError):
            connected_client.db_status()


# ══════════════════════════════════════════════════════════════════════════════
# § 9 — اختبارات Auto-Reconnect
# ══════════════════════════════════════════════════════════════════════════════

class TestAutoReconnect:

    def test_raw_property_triggers_reconnect(self, mock_rpc):
        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc):
            client = MsfClient(password="testpassword123", ssl=False)
            client.connect()

            # نقطع الاتصال يدوياً
            client._client = None
            client._info.state = ConnState.DISCONNECTED

            # الوصول لـ raw يجب أن يُعيد الاتصال
            _ = client.raw
            assert client.info.is_connected is True

    def test_ensure_connected_reconnects(self, mock_rpc):
        with patch("msf_ot.rpc_client.MsfRpcClient", return_value=mock_rpc) as mock_cls:
            client = MsfClient(password="testpassword123", ssl=False)
            client.connect()

            # نقطع الاتصال
            client._client = None
            client._info.state = ConnState.DISCONNECTED

            client._ensure_connected()
            assert mock_cls.call_count == 2  # اتصال أول + إعادة اتصال


# ══════════════════════════════════════════════════════════════════════════════
# § 10 — اختبارات __repr__ و __str__
# ══════════════════════════════════════════════════════════════════════════════

class TestRepresentation:

    def test_repr_disconnected(self):
        client = MsfClient(host="127.0.0.1", port=55553, password="test", ssl=False)
        r = repr(client)
        assert "127.0.0.1" in r
        assert "55553" in r
        assert "DISCONNECTED" in r

    def test_repr_connected(self, connected_client):
        r = repr(connected_client)
        assert "CONNECTED" in r

    def test_str_disconnected(self):
        client = MsfClient(host="127.0.0.1", port=55553, password="test", ssl=False)
        s = str(client)
        assert "DISCONNECTED" in s

    def test_str_connected(self, connected_client):
        s = str(connected_client)
        assert "6.3.0" in s
        assert "127.0.0.1" in s
