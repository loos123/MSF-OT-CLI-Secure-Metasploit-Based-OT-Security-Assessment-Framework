import os, json, csv, time, threading
from pathlib import Path
from unittest.mock import MagicMock, patch
import pytest
from click.testing import CliRunner

os.environ.update({
    'MSF_HOST': '127.0.0.1', 'MSF_PORT': '55553',
    'MSF_PASSWORD': 'lab_test_password', 'MSF_SSL': 'false',
    'OT_DRY_RUN': 'true', 'OT_RATE_LIMIT': '50',
    'OT_SCAN_TIMEOUT': '10', 'OT_MAX_THREADS': '5',
    'OT_BLACKLIST_RANGES': '10.0.0.0/8,172.16.0.0/12',
    'OT_ALLOWED_RANGES': '192.168.1.0/24,192.168.2.0/24',
    'OT_WARN_RANGES': '192.168.0.0/16',
})

from msf_ot.scanner import OTScanner, ScanResult, ScanStatus, HostResult, ServiceInfo, ResultsParser
from msf_ot.safety import validate_module, validate_target, run_safety_checks
from msf_ot.safety import BlockedModuleError, BlockedIPError, OTSafetyError, RateLimiter
from msf_ot.output import export_json, export_csv
from msf_ot.cli import cli, _parse_options
from msf_ot.rpc_client import MsfClient, MetasploitRPCError


# OT Lab Network Topology
class OTLabNetwork:
    DEVICES = {
        'plc':       {'ip': '192.168.1.10', 'hostname': 'plc-01',       'os': 'VxWorks 6.9',         'status': 'alive', 'services': [{'port': 502,   'proto': 'tcp', 'state': 'open', 'name': 'Modbus'},     {'port': 44818, 'proto': 'tcp', 'state': 'open', 'name': 'EtherNet/IP'}, {'port': 80,  'proto': 'tcp', 'state': 'open', 'name': 'http'}]},
        'hmi':       {'ip': '192.168.1.20', 'hostname': 'hmi-01',       'os': 'Windows 10 LTSC',     'status': 'alive', 'services': [{'port': 102,   'proto': 'tcp', 'state': 'open', 'name': 'S7comm'},     {'port': 80,    'proto': 'tcp', 'state': 'open', 'name': 'http'},         {'port': 443, 'proto': 'tcp', 'state': 'open', 'name': 'https'}, {'port': 445, 'proto': 'tcp', 'state': 'open', 'name': 'smb'}]},
        'rtu':       {'ip': '192.168.1.30', 'hostname': 'rtu-01',       'os': 'Embedded Linux',      'status': 'alive', 'services': [{'port': 20000, 'proto': 'tcp', 'state': 'open', 'name': 'DNP3'},       {'port': 2404,  'proto': 'tcp', 'state': 'open', 'name': 'IEC-104'}]},
        'ews':       {'ip': '192.168.1.40', 'hostname': 'ews-01',       'os': 'Windows Server 2019', 'status': 'alive', 'services': [{'port': 22,    'proto': 'tcp', 'state': 'open', 'name': 'ssh'},         {'port': 445,   'proto': 'tcp', 'state': 'open', 'name': 'smb'},          {'port': 3389,'proto': 'tcp', 'state': 'open', 'name': 'rdp'}]},
        'historian': {'ip': '192.168.1.50', 'hostname': 'historian-01', 'os': 'Windows Server 2016', 'status': 'alive', 'services': [{'port': 80,    'proto': 'tcp', 'state': 'open', 'name': 'http'},        {'port': 161,   'proto': 'udp', 'state': 'open', 'name': 'snmp'},         {'port': 1433,'proto': 'tcp', 'state': 'open', 'name': 'mssql'}]},
    }

    @classmethod
    def get_all_hosts_raw(cls):
        return [{'address': d['ip'], 'name': d['hostname'], 'os_name': d['os'], 'state': d['status']} for d in cls.DEVICES.values()]

    @classmethod
    def get_all_services_raw(cls):
        services = []
        for device in cls.DEVICES.values():
            for svc in device['services']:
                services.append({'host': device['ip'], 'port': str(svc['port']), 'proto': svc['proto'], 'state': svc['state'], 'name': svc['name']})
        return services

    @classmethod
    def build_scan_result(cls, module='auxiliary/scanner/portscan/tcp'):
        raw_hosts = cls.get_all_hosts_raw()
        raw_services = cls.get_all_services_raw()
        hosts = ResultsParser.build_hosts(raw_hosts, raw_services)
        result = ScanResult(module=module, target='192.168.1.0/24', status=ScanStatus.COMPLETED, hosts=hosts, duration=12.5, ports='1-65535')
        return result


def make_mock_msf_with_lab():
    msf = MagicMock(spec=MsfClient)
    msf.execute_module.return_value = 'lab-job-001'
    msf.is_job_running.return_value = False
    msf.db_hosts.return_value = OTLabNetwork.get_all_hosts_raw()
    msf.db_services.return_value = OTLabNetwork.get_all_services_raw()
    msf.get_jobs.return_value = {}
    return msf


# S1 - OT Network Topology Tests
class TestOTNetworkTopology:
    def test_lab_has_5_devices(self):
        assert len(OTLabNetwork.DEVICES) == 5

    def test_plc_has_modbus(self):
        ports = [s['port'] for s in OTLabNetwork.DEVICES['plc']['services']]
        assert 502 in ports

    def test_hmi_has_s7comm(self):
        ports = [s['port'] for s in OTLabNetwork.DEVICES['hmi']['services']]
        assert 102 in ports

    def test_rtu_has_dnp3(self):
        ports = [s['port'] for s in OTLabNetwork.DEVICES['rtu']['services']]
        assert 20000 in ports

    def test_build_scan_result_has_all_hosts(self):
        result = OTLabNetwork.build_scan_result()
        assert result.host_count == 5

    def test_build_scan_result_detects_ot_hosts(self):
        result = OTLabNetwork.build_scan_result()
        assert result.ot_host_count >= 3

    def test_plc_risk_level_critical(self):
        result = OTLabNetwork.build_scan_result()
        plc = next(h for h in result.hosts if h.ip == '192.168.1.10')
        assert plc.has_ot_services is True
        assert plc.risk_level == 'critical'

    def test_rtu_dnp3_detected_as_ot(self):
        result = OTLabNetwork.build_scan_result()
        rtu = next(h for h in result.hosts if h.ip == '192.168.1.30')
        ot_ports = [s.port for s in rtu.ot_services]
        assert 20000 in ot_ports

    def test_all_services_count(self):
        result = OTLabNetwork.build_scan_result()
        assert result.service_count == 15


# S2 - OT Safety Blocks
class TestOTSafetyBlocks:
    EXPLOIT_ATTEMPTS = [
        'exploit/windows/smb/ms17_010_eternalblue',
        'exploit/scada/modbus_write_coil',
        'exploit/multi/handler',
    ]
    DOS_ATTEMPTS = [
        'auxiliary/dos/scada/modbus_dos',
        'auxiliary/dos/windows/rdp/ms12_020_maxchannelids',
    ]
    BLACKLISTED_TARGETS = ['10.0.0.1', '10.10.10.100', '172.16.0.50', '172.20.100.1']
    FUZZER_ATTEMPTS = ['auxiliary/fuzzer/modbus/modbus_fuzzer', 'auxiliary/fuzzer/scada/dnp3_fuzzer']
    PAYLOAD_ATTEMPTS = ['payload/windows/meterpreter/reverse_tcp', 'payload/linux/x86/shell_reverse_tcp']
    SAFE_SCANNERS = ['auxiliary/scanner/portscan/tcp', 'auxiliary/scanner/scada/modbusdetect', 'auxiliary/scanner/snmp/snmp_enum']

    def test_all_exploit_attempts_blocked(self):
        for module in self.EXPLOIT_ATTEMPTS:
            with pytest.raises(BlockedModuleError):
                validate_module(module)

    def test_all_dos_attempts_blocked(self):
        for module in self.DOS_ATTEMPTS:
            with pytest.raises(BlockedModuleError):
                validate_module(module)

    def test_all_blacklisted_targets_blocked(self):
        for target in self.BLACKLISTED_TARGETS:
            with pytest.raises(BlockedIPError):
                validate_target(target)

    def test_all_fuzzer_attempts_blocked(self):
        for module in self.FUZZER_ATTEMPTS:
            with pytest.raises(BlockedModuleError):
                validate_module(module)

    def test_all_payload_attempts_blocked(self):
        for module in self.PAYLOAD_ATTEMPTS:
            with pytest.raises(BlockedModuleError):
                validate_module(module)

    def test_safe_scanners_allowed(self):
        for module in self.SAFE_SCANNERS:
            validate_module(module)

    def test_full_safety_check_blocks_exploit_on_allowed_target(self):
        with pytest.raises(BlockedModuleError):
            run_safety_checks(module_path='exploit/windows/smb/ms17_010', target='192.168.1.10')

    def test_full_safety_check_blocks_scanner_on_blacklisted_target(self):
        with pytest.raises(BlockedIPError):
            run_safety_checks(module_path='auxiliary/scanner/portscan/tcp', target='10.0.0.1')

    def test_full_safety_check_passes_for_valid_scan(self):
        result = run_safety_checks(module_path='auxiliary/scanner/portscan/tcp', target='192.168.1.10', ports='502')
        assert result is not None
        assert len(result.warnings) > 0


# S3 - Scanner Simulation
class TestScannerSimulation:
    def setup_method(self):
        self.msf = make_mock_msf_with_lab()
        self.scanner = OTScanner(self.msf)

    def test_portscan_dry_run_on_lab_network(self):
        result = self.scanner.scan(module_path='auxiliary/scanner/portscan/tcp', target='192.168.1.0/24', ports='1-1024')
        assert result.status == ScanStatus.DRY_RUN

    def test_modbus_scan_dry_run(self):
        result = self.scanner.scan(module_path='auxiliary/scanner/scada/modbusdetect', target='192.168.1.10')
        assert result.status == ScanStatus.DRY_RUN

    def test_snmp_scan_dry_run(self):
        result = self.scanner.scan(module_path='auxiliary/scanner/snmp/snmp_enum', target='192.168.1.50')
        assert result.status == ScanStatus.DRY_RUN

    def test_live_portscan_discovers_all_hosts(self):
        with patch('msf_ot.scanner.OT_DRY_RUN', False):
            result = self.scanner.scan(module_path='auxiliary/scanner/portscan/tcp', target='192.168.1.0/24', ports='1-65535')
        assert result.status == ScanStatus.COMPLETED
        assert result.host_count == 5

    def test_live_scan_detects_ot_hosts(self):
        with patch('msf_ot.scanner.OT_DRY_RUN', False):
            result = self.scanner.scan(module_path='auxiliary/scanner/portscan/tcp', target='192.168.1.0/24')
        assert result.ot_host_count >= 3

    def test_live_scan_detects_modbus_on_plc(self):
        with patch('msf_ot.scanner.OT_DRY_RUN', False):
            result = self.scanner.scan(module_path='auxiliary/scanner/portscan/tcp', target='192.168.1.0/24')
        plc = next((h for h in result.hosts if h.ip == '192.168.1.10'), None)
        assert plc is not None
        assert plc.has_ot_services is True
        assert 502 in [s.port for s in plc.ot_services]

    def test_live_scan_detects_s7comm_on_hmi(self):
        with patch('msf_ot.scanner.OT_DRY_RUN', False):
            result = self.scanner.scan(module_path='auxiliary/scanner/portscan/tcp', target='192.168.1.0/24')
        hmi = next((h for h in result.hosts if h.ip == '192.168.1.20'), None)
        assert hmi is not None
        assert 102 in [s.port for s in hmi.ot_services]

    def test_live_scan_detects_dnp3_on_rtu(self):
        with patch('msf_ot.scanner.OT_DRY_RUN', False):
            result = self.scanner.scan(module_path='auxiliary/scanner/portscan/tcp', target='192.168.1.0/24')
        rtu = next((h for h in result.hosts if h.ip == '192.168.1.30'), None)
        assert rtu is not None
        assert 20000 in [s.port for s in rtu.ot_services]

    def test_multiscan_scada_preset(self):
        scada_modules = ['auxiliary/scanner/scada/modbusdetect', 'auxiliary/scanner/scada/dnp3_enumrouter', 'auxiliary/scanner/scada/ethernetip_list_identity']
        results = self.scanner.scan_multi(modules=scada_modules, target='192.168.1.0/24')
        assert len(results) == 3
        for r in results:
            assert r.status == ScanStatus.DRY_RUN

    def test_scan_blocked_target_stops_immediately(self):
        result = self.scanner.scan(module_path='auxiliary/scanner/portscan/tcp', target='10.0.0.1')
        assert result.status == ScanStatus.BLOCKED
        self.msf.execute_module.assert_not_called()

    def test_scan_exploit_blocked_before_connection(self):
        result = self.scanner.scan(module_path='exploit/windows/smb/ms17_010', target='192.168.1.10')
        assert result.status == ScanStatus.BLOCKED
        self.msf.execute_module.assert_not_called()

    def test_threads_capped_for_ot_safety(self):
        with patch('msf_ot.scanner.OT_DRY_RUN', False):
            self.scanner.scan(module_path='auxiliary/scanner/portscan/tcp', target='192.168.1.0/24', threads=100)
        call_args = self.msf.execute_module.call_args
        options = call_args[0][2]
        # يجب أن يكون أقل من 100 (الحد الأقصى مُطبَّق)
        assert options['THREADS'] < 100


# S4 - Audit Trail
class TestAuditTrail:
    def test_audit_log_exists(self):
        assert Path('logs/audit.log').exists()

    def test_audit_log_has_content(self):
        content = Path('logs/audit.log').read_text(encoding='utf-8')
        assert len(content) > 0

    def test_audit_log_records_blocked_modules(self):
        content = Path('logs/audit.log').read_text(encoding='utf-8')
        assert 'BLOCKED_MODULE' in content

    def test_audit_log_records_blocked_ips(self):
        content = Path('logs/audit.log').read_text(encoding='utf-8')
        assert 'BLOCKED_IP' in content

    def test_audit_log_records_allowed_modules(self):
        content = Path('logs/audit.log').read_text(encoding='utf-8')
        assert 'MODULE_ALLOWED' in content

    def test_audit_log_records_scan_approved(self):
        content = Path('logs/audit.log').read_text(encoding='utf-8')
        assert 'SCAN_APPROVED' in content

    def test_new_blocked_attempt_logged(self):
        try:
            validate_module('exploit/test/new_attempt_xyz_unique')
        except BlockedModuleError:
            pass
        content = Path('logs/audit.log').read_text(encoding='utf-8')
        assert 'new_attempt_xyz_unique' in content

    def test_audit_log_has_timestamps(self):
        lines = Path('logs/audit.log').read_text(encoding='utf-8').strip().split('\n')
        for line in lines[:5]:
            if line.strip():
                assert '|' in line

    def test_audit_log_has_severity_levels(self):
        content = Path('logs/audit.log').read_text(encoding='utf-8')
        assert 'INFO' in content
        assert 'WARNING' in content


# S5 - Export Verification
class TestExportVerification:
    def test_json_export_complete_lab_network(self, tmp_path):
        result = OTLabNetwork.build_scan_result()
        out = export_json(result, output_dir=str(tmp_path))
        with open(out, encoding='utf-8') as f:
            data = json.load(f)
        assert 'meta' in data and 'stats' in data and 'hosts' in data
        assert len(data['hosts']) == 5
        all_services = [s for h in data['hosts'] for s in h['services']]
        ot_services = [s for s in all_services if s.get('is_ot')]
        assert len(ot_services) > 0

    def test_json_export_plc_modbus_flagged(self, tmp_path):
        result = OTLabNetwork.build_scan_result()
        out = export_json(result, output_dir=str(tmp_path))
        with open(out, encoding='utf-8') as f:
            data = json.load(f)
        plc = next(h for h in data['hosts'] if h['ip'] == '192.168.1.10')
        modbus = next((s for s in plc['services'] if s['port'] == 502), None)
        assert modbus is not None
        assert modbus['is_ot'] is True
        assert modbus['ot_risk'] == 'critical'

    def test_csv_export_has_ot_columns(self, tmp_path):
        result = OTLabNetwork.build_scan_result()
        out = export_csv(result, output_dir=str(tmp_path))
        with open(out, encoding='utf-8') as f:
            reader = csv.DictReader(f)
            headers = reader.fieldnames
        assert 'Is OT' in headers
        assert 'OT Risk' in headers

    def test_csv_export_modbus_marked_yes(self, tmp_path):
        result = OTLabNetwork.build_scan_result()
        out = export_csv(result, output_dir=str(tmp_path))
        with open(out, encoding='utf-8') as f:
            rows = list(csv.DictReader(f))
        modbus_rows = [r for r in rows if r.get('Port') == '502']
        assert len(modbus_rows) > 0
        assert modbus_rows[0]['Is OT'] == 'YES'
        assert modbus_rows[0]['OT Risk'] == 'critical'

    def test_json_stats_match_actual_counts(self, tmp_path):
        result = OTLabNetwork.build_scan_result()
        out = export_json(result, output_dir=str(tmp_path))
        with open(out, encoding='utf-8') as f:
            data = json.load(f)
        assert data['stats']['hosts'] == result.host_count
        assert data['stats']['services'] == result.service_count
        assert data['stats']['ot_hosts'] == result.ot_host_count

    def test_export_creates_nested_dir(self, tmp_path):
        new_dir = str(tmp_path / 'lab_reports' / 'scan_001')
        result = OTLabNetwork.build_scan_result()
        export_json(result, output_dir=new_dir)
        assert Path(new_dir).exists()


# S6 - CLI End-to-End
class TestCLIEndToEnd:
    @pytest.fixture
    def runner(self):
        return CliRunner()

    def _make_mock_msf(self):
        msf = MagicMock()
        msf.__enter__ = MagicMock(return_value=msf)
        msf.__exit__ = MagicMock(return_value=False)
        msf.health_check.return_value = {'connected': True, 'msf_version': '6.3.0', 'db_connected': True, 'jobs_count': 0, 'sessions_count': 0, 'uptime_s': 5.0, 'error': None}
        msf.get_version.return_value = {'version': '6.3.0', 'ruby': '3.1.0'}
        return msf

    def test_e2e_scan_plc_dry_run(self, runner):
        mock_msf = self._make_mock_msf()
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = ScanResult(module='auxiliary/scanner/scada/modbusdetect', target='192.168.1.10', status=ScanStatus.DRY_RUN, duration=0.1)
        with patch('msf_ot.cli._make_msf_client', return_value=mock_msf), patch('msf_ot.cli.OTScanner', return_value=mock_scanner):
            result = runner.invoke(cli, ['--no-banner', 'scan', '192.168.1.10', '-m', 'auxiliary/scanner/scada/modbusdetect'], obj={})
        assert result.exit_code == 0
        assert '192.168.1.10' in result.output

    def test_e2e_multiscan_scada_preset(self, runner):
        mock_msf = self._make_mock_msf()
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = ScanResult(module='auxiliary/scanner/scada/modbusdetect', target='192.168.1.0/24', status=ScanStatus.DRY_RUN, duration=0.1)
        with patch('msf_ot.cli._make_msf_client', return_value=mock_msf), patch('msf_ot.cli.OTScanner', return_value=mock_scanner):
            result = runner.invoke(cli, ['--no-banner', 'multiscan', '192.168.1.0/24', '--preset', 'scada'], obj={})
        assert result.exit_code == 0
        assert mock_scanner.scan.call_count >= 3

    def test_e2e_blocked_plc_in_blacklist(self, runner):
        mock_msf = self._make_mock_msf()
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = ScanResult(module='auxiliary/scanner/portscan/tcp', target='10.0.0.10', status=ScanStatus.BLOCKED, error='IP blocked')
        with patch('msf_ot.cli._make_msf_client', return_value=mock_msf), patch('msf_ot.cli.OTScanner', return_value=mock_scanner):
            result = runner.invoke(cli, ['--no-banner', 'scan', '10.0.0.10'], obj={})
        assert result.exit_code == 1

    def test_e2e_modules_shows_scada(self, runner):
        result = runner.invoke(cli, ['--no-banner', 'modules', '--category', 'scada'], obj={})
        assert result.exit_code == 0
        assert 'modbus' in result.output.lower()

    def test_e2e_export_json_in_live_mode(self, runner, tmp_path):
        mock_msf = self._make_mock_msf()
        lab_result = OTLabNetwork.build_scan_result()
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = lab_result
        with patch('msf_ot.cli._make_msf_client', return_value=mock_msf), patch('msf_ot.cli.OTScanner', return_value=mock_scanner), patch('msf_ot.scanner.OT_DRY_RUN', False):
            result = runner.invoke(cli, ['--no-banner', 'scan', '192.168.1.0/24', '--export-json', '--output-dir', str(tmp_path)], obj={})
        assert result.exit_code == 0
        json_files = list(tmp_path.glob('*.json'))
        assert len(json_files) == 1


# S7 - Stress and Edge Cases
class TestStressAndEdgeCases:
    def test_scan_outside_allowed_range_blocked(self):
        # 172.30.0.0/24 ليس في blacklist لكن خارج OT_ALLOWED_RANGES
        with pytest.raises(BlockedIPError):
            validate_target('172.30.0.0/24')

    def test_scan_single_host_in_allowed_range(self):
        result = validate_target('192.168.1.100')
        assert result is not None

    def test_concurrent_safety_checks(self):
        errors = []
        results = []
        def check_module(module):
            try:
                validate_module(module)
                results.append(('allowed', module))
            except BlockedModuleError:
                results.append(('blocked', module))
            except Exception as e:
                errors.append(e)
        modules = ['auxiliary/scanner/portscan/tcp', 'exploit/windows/smb/ms17_010', 'auxiliary/scanner/scada/modbusdetect', 'payload/windows/meterpreter/reverse_tcp', 'auxiliary/scanner/snmp/snmp_enum'] * 4
        threads = [threading.Thread(target=check_module, args=(m,)) for m in modules]
        for t in threads: t.start()
        for t in threads: t.join()
        assert len(errors) == 0
        assert len([r for r in results if r[0] == 'allowed']) > 0
        assert len([r for r in results if r[0] == 'blocked']) > 0

    def test_rate_limiter_under_load(self):
        limiter = RateLimiter(max_calls=10, window=1.0)
        limiter.reset()
        start = time.monotonic()
        for _ in range(10):
            limiter.wait()
        elapsed = time.monotonic() - start
        assert elapsed < 2.0

    def test_host_with_all_ot_protocols(self):
        services = [ServiceInfo(port=502, protocol='tcp', state='open'), ServiceInfo(port=102, protocol='tcp', state='open'), ServiceInfo(port=20000, protocol='tcp', state='open'), ServiceInfo(port=44818, protocol='tcp', state='open'), ServiceInfo(port=2404, protocol='tcp', state='open')]
        host = HostResult(ip='192.168.1.99', services=services)
        assert host.has_ot_services is True
        assert host.risk_level == 'critical'
        assert len(host.ot_services) == 5

    def test_parse_options_with_special_chars(self):
        opts = _parse_options(('COMMUNITY=public@123',))
        assert opts['COMMUNITY'] == 'public@123'

    def test_results_parser_service_without_host(self):
        raw_hosts = [{'address': '192.168.1.1', 'state': 'alive'}]
        raw_services = [{'host': '192.168.1.1', 'port': '80', 'proto': 'tcp', 'state': 'open'}, {'host': '192.168.1.99', 'port': '502', 'proto': 'tcp', 'state': 'open'}]
        hosts = ResultsParser.build_hosts(raw_hosts, raw_services)
        assert len(hosts) == 1
        assert len(hosts[0].services) == 1


# S8 - Security Regression Tests
class TestSecurityRegression:
    def test_reg001_rhosts_cannot_be_overridden(self):
        msf = make_mock_msf_with_lab()
        scanner = OTScanner(msf)
        with patch('msf_ot.scanner.OT_DRY_RUN', False):
            scanner.scan(module_path='auxiliary/scanner/portscan/tcp', target='192.168.1.1', options={'RHOSTS': '10.0.0.1'})
        options = msf.execute_module.call_args[0][2]
        assert options['RHOSTS'] == '192.168.1.1'

    def test_reg002_threads_always_capped(self):
        msf = make_mock_msf_with_lab()
        scanner = OTScanner(msf)
        for threads in [100, 1000, 99999]:
            with patch('msf_ot.scanner.OT_DRY_RUN', False):
                scanner.scan(module_path='auxiliary/scanner/portscan/tcp', target='192.168.1.1', threads=threads)
            options = msf.execute_module.call_args[0][2]
            # يجب أن يكون أقل من القيمة المُدخَلة دائماً
            assert options['THREADS'] < threads

    def test_reg003_exploit_keyword_blocked_in_auxiliary(self):
        with pytest.raises(BlockedModuleError):
            validate_module('auxiliary/scanner/exploit_checker')

    def test_reg004_ip_injection_blocked(self):
        malicious = ['192.168.1.1; rm -rf /', '192.168.1.1 && cat /etc/passwd', '192.168.1.1whoami']
        for target in malicious:
            with pytest.raises((BlockedIPError, OTSafetyError)):
                validate_target(target)

    def test_reg005_empty_module_path_safe(self):
        with pytest.raises(BlockedModuleError): validate_module('')
        with pytest.raises(BlockedModuleError): validate_module('   ')

    def test_reg006_none_target_safe(self):
        with pytest.raises((BlockedIPError, OTSafetyError)):
            validate_target(None)

    def test_reg007_new_module_not_auto_allowed(self):
        with pytest.raises(BlockedModuleError):
            validate_module('auxiliary/scanner/portscan/new_super_scanner')

    def test_reg008_blacklist_protects_single_ip_in_range(self):
        for ip in ['10.0.0.1', '10.255.255.254', '10.100.50.25']:
            with pytest.raises(BlockedIPError):
                validate_target(ip)

    def test_reg009_dry_run_never_executes(self):
        msf = make_mock_msf_with_lab()
        scanner = OTScanner(msf)
        scanner.scan(module_path='auxiliary/scanner/portscan/tcp', target='192.168.1.1')
        msf.execute_module.assert_not_called()

    def test_reg010_rate_limiter_thread_safe(self):
        limiter = RateLimiter(max_calls=20, window=1.0)
        limiter.reset()
        errors = []
        def worker():
            try: limiter.wait()
            except Exception as e: errors.append(str(e))
        threads = [threading.Thread(target=worker) for _ in range(15)]
        for t in threads: t.start()
        for t in threads: t.join()
        assert len(errors) == 0
