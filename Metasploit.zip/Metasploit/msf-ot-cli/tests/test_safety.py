"""
test_safety.py — اختبارات وحدة safety.py
"""

import os
import time
import threading
import pytest

os.environ.update({
    "MSF_PASSWORD"        : "testpassword123",
    "OT_DRY_RUN"          : "true",
    "OT_RATE_LIMIT"       : "5",
    "OT_BLACKLIST_RANGES" : "192.168.100.0/24,10.10.0.0/16",
    "OT_ALLOWED_RANGES"   : "192.168.1.0/24",
    "OT_WARN_RANGES"      : "192.168.0.0/16",
    "OT_MAX_THREADS"      : "10",
})

from msf_ot.safety import (
    validate_module,
    validate_target,
    check_ot_ports,
    run_safety_checks,
    is_module_allowed,
    is_target_allowed,
    RateLimiter,
    BlockedModuleError,
    BlockedIPError,
    OTSafetyError,
    SafetyCheckResult,
    dry_run_guard,
    rate_limiter,
)


# ══════════════════════════════════════════════════════════════════════════════
# § 1 — اختبارات validate_module
# ══════════════════════════════════════════════════════════════════════════════

class TestValidateModule:

    # ── modules مسموحة ────────────────────────────────────────────────────────
    def test_allowed_portscan_tcp(self):
        validate_module("auxiliary/scanner/portscan/tcp")  # يجب ألا يرفع

    def test_allowed_modbus(self):
        validate_module("auxiliary/scanner/scada/modbusdetect")

    def test_allowed_snmp(self):
        validate_module("auxiliary/scanner/snmp/snmp_enum")

    def test_allowed_smb_version(self):
        validate_module("auxiliary/scanner/smb/smb_version")

    # ── modules محظورة بالبادئة ───────────────────────────────────────────────
    def test_blocked_exploit_prefix(self):
        with pytest.raises(BlockedModuleError) as exc:
            validate_module("exploit/windows/smb/ms17_010_eternalblue")
        assert "exploit/" in str(exc.value)

    def test_blocked_payload_prefix(self):
        with pytest.raises(BlockedModuleError):
            validate_module("payload/windows/meterpreter/reverse_tcp")

    def test_blocked_post_prefix(self):
        with pytest.raises(BlockedModuleError):
            validate_module("post/multi/recon/local_exploit_suggester")

    def test_blocked_encoder_prefix(self):
        with pytest.raises(BlockedModuleError):
            validate_module("encoder/x86/shikata_ga_nai")

    def test_blocked_evasion_prefix(self):
        with pytest.raises(BlockedModuleError):
            validate_module("evasion/windows/windows_defender_exe")

    # ── modules محظورة بالكلمات المفتاحية ────────────────────────────────────
    def test_blocked_keyword_dos(self):
        with pytest.raises(BlockedModuleError) as exc:
            validate_module("auxiliary/dos/windows/rdp/ms12_020_maxchannelids")
        assert "dos" in str(exc.value).lower()

    def test_blocked_keyword_overflow(self):
        with pytest.raises(BlockedModuleError):
            validate_module("auxiliary/scanner/overflow_test")

    def test_blocked_keyword_fuzzer(self):
        with pytest.raises(BlockedModuleError):
            validate_module("auxiliary/fuzzer/modbus/modbus_fuzzer")

    # ── modules غير موجودة في الـ whitelist ──────────────────────────────────
    def test_blocked_unknown_auxiliary(self):
        with pytest.raises(BlockedModuleError) as exc:
            validate_module("auxiliary/scanner/http/unknown_scanner")
        assert "whitelist" in str(exc.value).lower() or "مسموح" in str(exc.value)

    # ── حالات حافة ────────────────────────────────────────────────────────────
    def test_empty_module_raises(self):
        with pytest.raises(BlockedModuleError):
            validate_module("")

    def test_none_module_raises(self):
        with pytest.raises(BlockedModuleError):
            validate_module(None)  # type: ignore

    def test_whitespace_module_raises(self):
        with pytest.raises(BlockedModuleError):
            validate_module("   ")

    # ── دالة is_module_allowed ────────────────────────────────────────────────
    def test_is_allowed_returns_true(self):
        assert is_module_allowed("auxiliary/scanner/portscan/tcp") is True

    def test_is_allowed_returns_false_for_exploit(self):
        assert is_module_allowed("exploit/windows/smb/ms17_010") is False

    def test_is_allowed_returns_false_for_unknown(self):
        assert is_module_allowed("auxiliary/scanner/unknown/module") is False


# ══════════════════════════════════════════════════════════════════════════════
# § 2 — اختبارات validate_target
# ══════════════════════════════════════════════════════════════════════════════

class TestValidateTarget:

    # ── أهداف مسموحة ──────────────────────────────────────────────────────────
    def test_allowed_ip_in_range(self):
        result = validate_target("192.168.1.50")
        assert isinstance(result, SafetyCheckResult)
        assert result.passed is True

    def test_allowed_cidr_in_range(self):
        result = validate_target("192.168.1.0/24")
        assert result.passed is True

    # ── أهداف محظورة (blacklist) ──────────────────────────────────────────────
    def test_blocked_blacklist_ip(self):
        with pytest.raises(BlockedIPError) as exc:
            validate_target("192.168.100.50")
        assert "محظور" in str(exc.value) or "blacklist" in str(exc.value).lower()

    def test_blocked_blacklist_cidr(self):
        with pytest.raises(BlockedIPError):
            validate_target("192.168.100.0/24")

    def test_blocked_overlapping_cidr(self):
        with pytest.raises(BlockedIPError):
            validate_target("10.10.0.5")

    # ── أهداف خارج القائمة البيضاء ────────────────────────────────────────────
    def test_blocked_outside_allowed_range(self):
        with pytest.raises(BlockedIPError) as exc:
            validate_target("172.20.0.1")
        assert "مسموح" in str(exc.value) or "allowed" in str(exc.value).lower()

    # ── صيغة IP غير صحيحة ────────────────────────────────────────────────────
    def test_invalid_ip_format(self):
        with pytest.raises((BlockedIPError, OTSafetyError)):
            validate_target("not.an.ip.address")

    def test_invalid_cidr_format(self):
        with pytest.raises((BlockedIPError, OTSafetyError)):
            validate_target("192.168.1.0/99")

    def test_empty_target_raises(self):
        with pytest.raises((BlockedIPError, OTSafetyError)):
            validate_target("")

    # ── تحذيرات نطاقات OT ────────────────────────────────────────────────────
    def test_ot_range_warning_added(self):
        # 192.168.1.1 في OT_WARN_RANGES (192.168.0.0/16)
        result = validate_target("192.168.1.1")
        # يجب أن يكون هناك تحذير
        assert len(result.warnings) > 0

    # ── دالة is_target_allowed ────────────────────────────────────────────────
    def test_is_target_allowed_true(self):
        assert is_target_allowed("192.168.1.1") is True

    def test_is_target_allowed_false_blacklist(self):
        assert is_target_allowed("192.168.100.1") is False

    def test_is_target_allowed_false_outside(self):
        assert is_target_allowed("172.20.0.1") is False


# ══════════════════════════════════════════════════════════════════════════════
# § 3 — اختبارات check_ot_ports
# ══════════════════════════════════════════════════════════════════════════════

class TestCheckOTPorts:

    def test_modbus_port_502_detected(self):
        warnings = check_ot_ports("502")
        assert len(warnings) > 0
        assert any("502" in w or "Modbus" in w for w in warnings)

    def test_s7_port_102_detected(self):
        warnings = check_ot_ports("102")
        assert len(warnings) > 0

    def test_dnp3_port_20000_detected(self):
        warnings = check_ot_ports("20000")
        assert len(warnings) > 0

    def test_range_includes_critical_port(self):
        # نطاق 1-1024 يشمل 102 (S7comm)
        warnings = check_ot_ports("1-1024")
        assert len(warnings) > 0

    def test_safe_ports_no_warning(self):
        # منافذ عادية لا تحتوي على OT
        warnings = check_ot_ports("8080,8443,3000")
        assert len(warnings) == 0

    def test_empty_ports_no_warning(self):
        warnings = check_ot_ports("")
        assert warnings == []

    def test_comma_separated_ports(self):
        warnings = check_ot_ports("80,443,502,8080")
        assert any("502" in w or "Modbus" in w for w in warnings)


# ══════════════════════════════════════════════════════════════════════════════
# § 4 — اختبارات RateLimiter
# ══════════════════════════════════════════════════════════════════════════════

class TestRateLimiter:

    def test_basic_calls_within_limit(self):
        limiter = RateLimiter(max_calls=10, window=1.0)
        for _ in range(5):
            limiter.wait()  # يجب ألا ينتظر

    def test_rate_limit_enforced(self):
        limiter = RateLimiter(max_calls=3, window=1.0)
        start = time.monotonic()
        for _ in range(4):  # الرابع يجب أن ينتظر
            limiter.wait()
        elapsed = time.monotonic() - start
        assert elapsed >= 0.5  # انتظر على الأقل نصف ثانية

    def test_current_rate_tracking(self):
        limiter = RateLimiter(max_calls=10, window=1.0)
        limiter.reset()
        limiter.wait()
        limiter.wait()
        assert limiter.current_rate >= 2

    def test_reset_clears_calls(self):
        limiter = RateLimiter(max_calls=3, window=1.0)
        for _ in range(3):
            limiter.wait()
        limiter.reset()
        assert limiter.current_rate == 0

    def test_thread_safety(self):
        """يتحقق أن الـ RateLimiter آمن في بيئة multi-thread."""
        limiter = RateLimiter(max_calls=20, window=1.0)
        errors = []

        def worker():
            try:
                limiter.wait()
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=worker) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0


# ══════════════════════════════════════════════════════════════════════════════
# § 5 — اختبارات dry_run_guard
# ══════════════════════════════════════════════════════════════════════════════

class TestDryRunGuard:

    def test_dry_run_prevents_execution(self):
        """في وضع DRY_RUN=true يجب أن تُعيد dict بدون تنفيذ."""
        call_count = {"n": 0}

        @dry_run_guard
        def fake_scan(target):
            call_count["n"] += 1
            return "REAL_RESULT"

        result = fake_scan("192.168.1.1")

        # الدالة لم تُنفَّذ
        assert call_count["n"] == 0
        # النتيجة هي dict يوضح الـ dry-run
        assert isinstance(result, dict)
        assert result.get("dry_run") is True

    def test_dry_run_result_contains_function_name(self):
        @dry_run_guard
        def my_function():
            pass

        result = my_function()
        assert result["function"] == "my_function"


# ══════════════════════════════════════════════════════════════════════════════
# § 6 — اختبارات run_safety_checks (الفحص الشامل)
# ══════════════════════════════════════════════════════════════════════════════

class TestRunSafetyChecks:

    def test_valid_scan_passes(self):
        result = run_safety_checks(
            module_path="auxiliary/scanner/portscan/tcp",
            target="192.168.1.1",
            ports="80,443",
            threads=5,
        )
        assert isinstance(result, SafetyCheckResult)

    def test_blocked_module_raises(self):
        with pytest.raises(BlockedModuleError):
            run_safety_checks(
                module_path="exploit/windows/smb/ms17_010",
                target="192.168.1.1",
            )

    def test_blocked_ip_raises(self):
        with pytest.raises(BlockedIPError):
            run_safety_checks(
                module_path="auxiliary/scanner/portscan/tcp",
                target="192.168.100.1",
            )

    def test_ot_port_warning_in_result(self):
        result = run_safety_checks(
            module_path="auxiliary/scanner/portscan/tcp",
            target="192.168.1.1",
            ports="502",
        )
        assert len(result.ot_ports_found) > 0

    def test_high_threads_warning(self):
        result = run_safety_checks(
            module_path="auxiliary/scanner/portscan/tcp",
            target="192.168.1.1",
            threads=50,  # أعلى من OT_MAX_THREADS=10
        )
        assert any("thread" in w.lower() for w in result.warnings)
