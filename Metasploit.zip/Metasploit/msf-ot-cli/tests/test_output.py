"""
test_output.py - اختبارات وحدة output.py
"""

import os
import json
import csv
import tempfile
import pytest
from pathlib import Path
from io import StringIO
from unittest.mock import patch

os.environ.update({
    "MSF_PASSWORD"        : "testpassword123",
    "OT_DRY_RUN"          : "true",
    "OT_RATE_LIMIT"       : "100",
    "OT_BLACKLIST_RANGES" : "192.168.100.0/24",
    "OT_ALLOWED_RANGES"   : "192.168.1.0/24",
    "OT_MAX_THREADS"      : "10",
})

from rich.text import Text
from rich.console import Console

from msf_ot.scanner import (
    ScanResult, ScanStatus, HostResult, ServiceInfo,
)
from msf_ot.output import (
    colorize_port, colorize_status, colorize_risk, colorize_scan_status,
    print_scan_results, print_hosts_table, print_services_table,
    print_warnings, print_modules_list, print_summary_dashboard,
    export_json, export_csv,
    create_progress, create_multi_progress,
    _CRITICAL_PORTS, _HIGH_PORTS,
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def make_host(ip="192.168.1.1", with_ot=False, with_services=True):
    services = []
    if with_services:
        services.append(ServiceInfo(port=80,  protocol="tcp", state="open",  name="http"))
        services.append(ServiceInfo(port=443, protocol="tcp", state="open",  name="https"))
    if with_ot:
        services.append(ServiceInfo(port=502, protocol="tcp", state="open"))
    return HostResult(
        ip=ip, hostname=f"host-{ip.split('.')[-1]}",
        os_name="Linux", status="alive", services=services,
    )


def make_result(status=ScanStatus.COMPLETED, hosts=None, error=None, warnings=None):
    r = ScanResult(
        module="auxiliary/scanner/portscan/tcp",
        target="192.168.1.0/24",
        status=status,
        duration=2.5,
        ports="1-1024",
        threads=5,
    )
    r.hosts    = hosts    or []
    r.error    = error
    r.warnings = warnings or []
    return r


def render_to_string(func, *args, **kwargs) -> str:
    """يُشغّل دالة Rich ويُعيد الناتج كـ string."""
    buf = StringIO()
    test_console = Console(file=buf, no_color=True, width=120)
    with patch("msf_ot.output.console", test_console):
        func(*args, **kwargs)
    return buf.getvalue()


# ══════════════════════════════════════════════════════════════════════════════
# S2 - Colorizers
# ══════════════════════════════════════════════════════════════════════════════

class TestColorizePort:
    def test_returns_text_object(self):
        assert isinstance(colorize_port(80), Text)

    def test_critical_port_502(self):
        t = colorize_port(502)
        assert "502" in t.plain
        assert 502 in _CRITICAL_PORTS

    def test_critical_port_102(self):
        assert 102 in _CRITICAL_PORTS

    def test_high_port_80(self):
        t = colorize_port(80)
        assert "80" in t.plain
        assert 80 in _HIGH_PORTS

    def test_normal_port_8080(self):
        t = colorize_port(8080)
        assert "8080" in t.plain
        assert 8080 not in _CRITICAL_PORTS
        assert 8080 not in _HIGH_PORTS

    def test_all_critical_ports_return_text(self):
        for port in _CRITICAL_PORTS:
            t = colorize_port(port)
            assert str(port) in t.plain


class TestColorizeStatus:
    def test_alive_returns_text(self):
        t = colorize_status("alive")
        assert isinstance(t, Text)
        assert "alive" in t.plain

    def test_open_status(self):
        t = colorize_status("open")
        assert "open" in t.plain

    def test_down_status(self):
        t = colorize_status("down")
        assert "down" in t.plain

    def test_closed_status(self):
        t = colorize_status("closed")
        assert "closed" in t.plain

    def test_unknown_status(self):
        t = colorize_status("unknown")
        assert "unknown" in t.plain

    def test_case_insensitive(self):
        # كلا الحالتين يجب أن يُعيدا Text — السلوك الداخلي يعتمد على lowercase
        t1 = colorize_status("ALIVE")
        t2 = colorize_status("alive")
        # كلاهما يُعيد Text object — الألوان متطابقة حتى لو النص مختلف
        assert isinstance(t1, Text)
        assert isinstance(t2, Text)


class TestColorizeRisk:
    def test_critical_risk(self):
        t = colorize_risk("critical")
        assert "CRITICAL" in t.plain

    def test_high_risk(self):
        t = colorize_risk("high")
        assert "HIGH" in t.plain

    def test_medium_risk(self):
        t = colorize_risk("medium")
        assert "MEDIUM" in t.plain

    def test_low_risk(self):
        t = colorize_risk("low")
        assert "LOW" in t.plain

    def test_empty_risk(self):
        t = colorize_risk("")
        assert isinstance(t, Text)

    def test_returns_text_object(self):
        assert isinstance(colorize_risk("critical"), Text)


class TestColorizeScanStatus:
    def test_completed(self):
        t = colorize_scan_status(ScanStatus.COMPLETED)
        assert "COMPLETED" in t.plain

    def test_dry_run(self):
        t = colorize_scan_status(ScanStatus.DRY_RUN)
        assert "DRY" in t.plain

    def test_failed(self):
        t = colorize_scan_status(ScanStatus.FAILED)
        assert "FAILED" in t.plain

    def test_blocked(self):
        t = colorize_scan_status(ScanStatus.BLOCKED)
        assert "BLOCKED" in t.plain

    def test_timeout(self):
        t = colorize_scan_status(ScanStatus.TIMEOUT)
        assert "TIMEOUT" in t.plain

    def test_all_statuses_return_text(self):
        for status in ScanStatus:
            t = colorize_scan_status(status)
            assert isinstance(t, Text)


# ══════════════════════════════════════════════════════════════════════════════
# S4 - print_scan_results
# ══════════════════════════════════════════════════════════════════════════════

class TestPrintScanResults:
    def test_dry_run_output_contains_dry_run(self):
        result = make_result(status=ScanStatus.DRY_RUN)
        out = render_to_string(print_scan_results, result)
        assert "DRY" in out.upper() or "dry" in out.lower()

    def test_blocked_output_contains_blocked(self):
        result = make_result(status=ScanStatus.BLOCKED, error="IP محظور")
        out = render_to_string(print_scan_results, result)
        assert "محظور" in out or "Blocked" in out or "blocked" in out.lower()

    def test_failed_output_contains_error(self):
        result = make_result(status=ScanStatus.FAILED, error="Connection refused")
        out = render_to_string(print_scan_results, result)
        assert "Connection refused" in out

    def test_completed_output_contains_module(self):
        result = make_result(status=ScanStatus.COMPLETED)
        out = render_to_string(print_scan_results, result)
        assert "portscan" in out or "tcp" in out

    def test_completed_with_hosts_shows_ip(self):
        result = make_result(
            status=ScanStatus.COMPLETED,
            hosts=[make_host("192.168.1.50")],
        )
        out = render_to_string(print_scan_results, result)
        assert "192.168.1.50" in out

    def test_warnings_shown_when_present(self):
        result = make_result(
            status=ScanStatus.DRY_RUN,
            warnings=["Warning: OT port 502 detected"],
        )
        out = render_to_string(print_scan_results, result)
        assert "502" in out or "Warning" in out

    def test_no_hosts_message_when_empty(self):
        result = make_result(status=ScanStatus.COMPLETED, hosts=[])
        out = render_to_string(print_scan_results, result)
        assert "No hosts" in out or "discovered" in out.lower()

    def test_timeout_note_shown(self):
        result = make_result(status=ScanStatus.TIMEOUT)
        out = render_to_string(print_scan_results, result)
        assert "Timeout" in out or "timeout" in out.lower()


# ══════════════════════════════════════════════════════════════════════════════
# S5 - print_hosts_table
# ══════════════════════════════════════════════════════════════════════════════

class TestPrintHostsTable:
    def test_shows_ip(self):
        hosts = [make_host("10.0.0.1")]
        out = render_to_string(print_hosts_table, hosts)
        assert "10.0.0.1" in out

    def test_shows_hostname(self):
        hosts = [make_host("10.0.0.1")]
        out = render_to_string(print_hosts_table, hosts)
        assert "host-1" in out

    def test_shows_os(self):
        hosts = [make_host("10.0.0.1")]
        out = render_to_string(print_hosts_table, hosts)
        assert "Linux" in out

    def test_ot_badge_shown_for_ot_host(self):
        hosts = [make_host("10.0.0.1", with_ot=True)]
        out = render_to_string(print_hosts_table, hosts)
        assert "OT" in out

    def test_multiple_hosts_all_shown(self):
        hosts = [make_host(f"10.0.0.{i}") for i in range(1, 4)]
        out = render_to_string(print_hosts_table, hosts)
        for i in range(1, 4):
            assert f"10.0.0.{i}" in out

    def test_risk_level_shown(self):
        hosts = [make_host("10.0.0.1", with_ot=True)]
        out = render_to_string(print_hosts_table, hosts)
        assert "CRITICAL" in out or "critical" in out.lower()


# ══════════════════════════════════════════════════════════════════════════════
# S6 - print_services_table
# ══════════════════════════════════════════════════════════════════════════════

class TestPrintServicesTable:
    def test_shows_port(self):
        host = make_host("10.0.0.1", with_services=True)
        out = render_to_string(print_services_table, host)
        assert "80" in out

    def test_shows_service_name(self):
        host = make_host("10.0.0.1", with_services=True)
        out = render_to_string(print_services_table, host)
        assert "http" in out

    def test_ot_protocol_shown(self):
        host = make_host("10.0.0.1", with_ot=True)
        out = render_to_string(print_services_table, host)
        assert "502" in out

    def test_ot_risk_column_shown(self):
        host = make_host("10.0.0.1", with_ot=True)
        out = render_to_string(print_services_table, host)
        assert "OT Risk" in out or "CRITICAL" in out

    def test_ot_count_in_title(self):
        host = make_host("10.0.0.1", with_ot=True)
        out = render_to_string(print_services_table, host)
        assert "OT Protocol" in out or "1 OT" in out


# ══════════════════════════════════════════════════════════════════════════════
# S7 - print_warnings
# ══════════════════════════════════════════════════════════════════════════════

class TestPrintWarnings:
    def test_shows_warning_text(self):
        out = render_to_string(print_warnings, ["Warning: port 502 is Modbus"])
        assert "502" in out

    def test_shows_count(self):
        out = render_to_string(print_warnings, ["w1", "w2", "w3"])
        assert "3" in out

    def test_empty_list_no_output(self):
        out = render_to_string(print_warnings, [])
        assert out.strip() == ""

    def test_multiple_warnings_all_shown(self):
        warnings = ["Warning A", "Warning B", "Warning C"]
        out = render_to_string(print_warnings, warnings)
        for w in warnings:
            assert w in out


# ══════════════════════════════════════════════════════════════════════════════
# S8 - print_summary_dashboard
# ══════════════════════════════════════════════════════════════════════════════

class TestPrintSummaryDashboard:
    def test_empty_list_no_output(self):
        out = render_to_string(print_summary_dashboard, [])
        assert out.strip() == ""

    def test_shows_module_name(self):
        results = [make_result(status=ScanStatus.DRY_RUN)]
        out = render_to_string(print_summary_dashboard, results)
        assert "tcp" in out

    def test_shows_total_hosts(self):
        r = make_result(status=ScanStatus.COMPLETED, hosts=[make_host()])
        out = render_to_string(print_summary_dashboard, [r])
        assert "1" in out

    def test_shows_dry_run_count(self):
        results = [
            make_result(status=ScanStatus.DRY_RUN),
            make_result(status=ScanStatus.DRY_RUN),
        ]
        out = render_to_string(print_summary_dashboard, results)
        assert "2" in out

    def test_shows_dashboard_title(self):
        results = [make_result(status=ScanStatus.DRY_RUN)]
        out = render_to_string(print_summary_dashboard, results)
        assert "Dashboard" in out or "Summary" in out


# ══════════════════════════════════════════════════════════════════════════════
# S9 - print_modules_list
# ══════════════════════════════════════════════════════════════════════════════

class TestPrintModulesList:
    def test_shows_module_name(self):
        modules = ["auxiliary/scanner/portscan/tcp", "auxiliary/scanner/snmp/snmp_enum"]
        out = render_to_string(print_modules_list, modules)
        assert "portscan" in out
        assert "snmp" in out

    def test_shows_category(self):
        modules = ["auxiliary/scanner/portscan/tcp"]
        out = render_to_string(print_modules_list, modules)
        assert "portscan" in out

    def test_ot_badge_for_scada(self):
        modules = ["auxiliary/scanner/scada/modbusdetect"]
        out = render_to_string(print_modules_list, modules)
        assert "OT" in out

    def test_shows_total_count(self):
        modules = ["auxiliary/scanner/portscan/tcp"] * 5
        out = render_to_string(print_modules_list, modules)
        assert "5" in out

    def test_filter_str_shown(self):
        modules = ["auxiliary/scanner/portscan/tcp"]
        out = render_to_string(print_modules_list, modules, filter_str="portscan")
        assert "portscan" in out

    def test_numbering_starts_at_1(self):
        modules = ["auxiliary/scanner/portscan/tcp"]
        out = render_to_string(print_modules_list, modules)
        assert "1" in out


# ══════════════════════════════════════════════════════════════════════════════
# S10 - export_json
# ══════════════════════════════════════════════════════════════════════════════

class TestExportJSON:
    def test_creates_file(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED, hosts=[make_host()])
        out_file = export_json(result, output_dir=str(tmp_path))
        assert Path(out_file).exists()

    def test_valid_json(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED, hosts=[make_host()])
        out_file = export_json(result, output_dir=str(tmp_path))
        with open(out_file, encoding="utf-8") as f:
            data = json.load(f)
        assert isinstance(data, dict)

    def test_has_meta_section(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED)
        out_file = export_json(result, output_dir=str(tmp_path))
        with open(out_file, encoding="utf-8") as f:
            data = json.load(f)
        assert "meta" in data

    def test_has_hosts_section(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED, hosts=[make_host()])
        out_file = export_json(result, output_dir=str(tmp_path))
        with open(out_file, encoding="utf-8") as f:
            data = json.load(f)
        assert "hosts" in data
        assert len(data["hosts"]) == 1

    def test_host_ip_in_json(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED, hosts=[make_host("10.0.0.5")])
        out_file = export_json(result, output_dir=str(tmp_path))
        with open(out_file, encoding="utf-8") as f:
            data = json.load(f)
        assert data["hosts"][0]["ip"] == "10.0.0.5"

    def test_services_in_json(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED, hosts=[make_host(with_services=True)])
        out_file = export_json(result, output_dir=str(tmp_path))
        with open(out_file, encoding="utf-8") as f:
            data = json.load(f)
        assert len(data["hosts"][0]["services"]) > 0

    def test_ot_flags_in_services(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED, hosts=[make_host(with_ot=True)])
        out_file = export_json(result, output_dir=str(tmp_path))
        with open(out_file, encoding="utf-8") as f:
            data = json.load(f)
        services = data["hosts"][0]["services"]
        ot_services = [s for s in services if s.get("is_ot")]
        assert len(ot_services) > 0

    def test_custom_filename(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED)
        custom = str(tmp_path / "custom_report.json")
        out_file = export_json(result, filename=custom)
        assert out_file == custom
        assert Path(custom).exists()

    def test_meta_has_module(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED)
        out_file = export_json(result, output_dir=str(tmp_path))
        with open(out_file, encoding="utf-8") as f:
            data = json.load(f)
        assert data["meta"]["module"] == "auxiliary/scanner/portscan/tcp"

    def test_meta_has_status(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED)
        out_file = export_json(result, output_dir=str(tmp_path))
        with open(out_file, encoding="utf-8") as f:
            data = json.load(f)
        assert data["meta"]["status"] == "COMPLETED"

    def test_has_stats_section(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED)
        out_file = export_json(result, output_dir=str(tmp_path))
        with open(out_file, encoding="utf-8") as f:
            data = json.load(f)
        assert "stats" in data

    def test_creates_output_dir(self, tmp_path):
        new_dir = str(tmp_path / "new_reports")
        result = make_result(status=ScanStatus.COMPLETED)
        export_json(result, output_dir=new_dir)
        assert Path(new_dir).exists()


# ══════════════════════════════════════════════════════════════════════════════
# S11 - export_csv
# ══════════════════════════════════════════════════════════════════════════════

class TestExportCSV:
    def test_creates_file(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED, hosts=[make_host()])
        out_file = export_csv(result, output_dir=str(tmp_path))
        assert Path(out_file).exists()

    def test_has_header_row(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED, hosts=[make_host()])
        out_file = export_csv(result, output_dir=str(tmp_path))
        with open(out_file, encoding="utf-8") as f:
            reader = csv.reader(f)
            header = next(reader)
        assert "IP" in header
        assert "Port" in header

    def test_has_is_ot_column(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED, hosts=[make_host()])
        out_file = export_csv(result, output_dir=str(tmp_path))
        with open(out_file, encoding="utf-8") as f:
            reader = csv.reader(f)
            header = next(reader)
        assert "Is OT" in header

    def test_has_ot_risk_column(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED, hosts=[make_host()])
        out_file = export_csv(result, output_dir=str(tmp_path))
        with open(out_file, encoding="utf-8") as f:
            reader = csv.reader(f)
            header = next(reader)
        assert "OT Risk" in header

    def test_host_ip_in_rows(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED, hosts=[make_host("10.5.5.5")])
        out_file = export_csv(result, output_dir=str(tmp_path))
        content = Path(out_file).read_text(encoding="utf-8")
        assert "10.5.5.5" in content

    def test_ot_service_marked_yes(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED, hosts=[make_host(with_ot=True)])
        out_file = export_csv(result, output_dir=str(tmp_path))
        content = Path(out_file).read_text(encoding="utf-8")
        assert "YES" in content

    def test_normal_service_marked_no(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED, hosts=[make_host(with_services=True, with_ot=False)])
        out_file = export_csv(result, output_dir=str(tmp_path))
        content = Path(out_file).read_text(encoding="utf-8")
        assert "NO" in content

    def test_host_without_services_has_row(self, tmp_path):
        host = HostResult(ip="10.0.0.1", status="alive")
        result = make_result(status=ScanStatus.COMPLETED, hosts=[host])
        out_file = export_csv(result, output_dir=str(tmp_path))
        with open(out_file, encoding="utf-8") as f:
            rows = list(csv.reader(f))
        assert len(rows) == 2  # header + 1 row

    def test_custom_filename(self, tmp_path):
        result = make_result(status=ScanStatus.COMPLETED)
        custom = str(tmp_path / "custom.csv")
        out_file = export_csv(result, filename=custom)
        assert out_file == custom

    def test_multiple_services_multiple_rows(self, tmp_path):
        host = make_host(with_services=True, with_ot=True)
        result = make_result(status=ScanStatus.COMPLETED, hosts=[host])
        out_file = export_csv(result, output_dir=str(tmp_path))
        with open(out_file, encoding="utf-8") as f:
            rows = list(csv.reader(f))
        assert len(rows) > 2  # header + multiple service rows


# ══════════════════════════════════════════════════════════════════════════════
# S12 - Progress Bars
# ══════════════════════════════════════════════════════════════════════════════

class TestProgressBars:
    def test_create_progress_returns_progress(self):
        from rich.progress import Progress
        p = create_progress()
        assert isinstance(p, Progress)

    def test_create_progress_with_eta(self):
        from rich.progress import Progress
        p = create_progress(show_eta=True)
        assert isinstance(p, Progress)

    def test_create_progress_without_eta(self):
        from rich.progress import Progress
        p = create_progress(show_eta=False)
        assert isinstance(p, Progress)

    def test_create_multi_progress_returns_progress(self):
        from rich.progress import Progress
        p = create_multi_progress()
        assert isinstance(p, Progress)

    def test_progress_usable_as_context_manager(self):
        p = create_progress()
        with p:
            task = p.add_task("Testing...", total=10)
            p.update(task, advance=5)
