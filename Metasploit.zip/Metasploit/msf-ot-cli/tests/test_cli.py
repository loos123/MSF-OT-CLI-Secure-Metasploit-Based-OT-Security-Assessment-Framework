"""
test_cli.py - اختبارات وحدة cli.py
=====================================
يستخدم Click CliRunner لاختبار كل الأوامر بدون msfrpcd حقيقي.
"""

import os
import pytest
from unittest.mock import MagicMock, patch

os.environ.update({
    "MSF_PASSWORD"        : "testpassword123",
    "OT_DRY_RUN"          : "true",
    "OT_RATE_LIMIT"       : "100",
    "OT_BLACKLIST_RANGES" : "192.168.100.0/24",
    "OT_ALLOWED_RANGES"   : "192.168.1.0/24",
    "OT_MAX_THREADS"      : "10",
    "OT_SCAN_TIMEOUT"     : "30",
})

from click.testing import CliRunner
from msf_ot.cli import cli, _parse_options, _make_msf_client, _handle_rpc_error
from msf_ot.scanner import ScanResult, ScanStatus
from msf_ot.rpc_client import MetasploitRPCError, AuthenticationError


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def runner():
    return CliRunner()


def make_mock_msf():
    """يُنشئ MsfClient mock جاهز."""
    msf = MagicMock()
    msf.__enter__ = MagicMock(return_value=msf)
    msf.__exit__  = MagicMock(return_value=False)
    msf.health_check.return_value = {
        "connected": True, "msf_version": "6.3.0",
        "db_connected": True, "jobs_count": 0, "sessions_count": 0,
        "uptime_s": 10.0, "error": None,
    }
    msf.get_version.return_value = {"version": "6.3.0", "ruby": "3.1.0", "api": "1.0"}
    msf.get_jobs.return_value    = {}
    msf.get_sessions.return_value = {}
    return msf


def make_dry_run_result(module="auxiliary/scanner/portscan/tcp", target="192.168.1.1"):
    r = ScanResult(module=module, target=target, status=ScanStatus.DRY_RUN)
    r.duration = 0.1
    return r


def make_completed_result(module="auxiliary/scanner/portscan/tcp", target="192.168.1.1"):
    r = ScanResult(module=module, target=target, status=ScanStatus.COMPLETED)
    r.duration = 2.5
    return r


def make_blocked_result(module="exploit/windows/smb/ms17_010", target="192.168.1.1"):
    r = ScanResult(module=module, target=target, status=ScanStatus.BLOCKED)
    r.error = "Module محظور"
    return r


# ══════════════════════════════════════════════════════════════════════════════
# دوال مساعدة
# ══════════════════════════════════════════════════════════════════════════════

class TestParseOptions:
    def test_valid_key_value(self):
        result = _parse_options(("TIMEOUT=10", "VERBOSE=true"))
        assert result["TIMEOUT"] == "10"
        assert result["VERBOSE"] == "true"

    def test_key_uppercased(self):
        result = _parse_options(("timeout=10",))
        assert "TIMEOUT" in result

    def test_value_stripped(self):
        result = _parse_options(("KEY = value ",))
        assert result["KEY"] == "value"

    def test_empty_tuple(self):
        result = _parse_options(())
        assert result == {}

    def test_invalid_option_ignored(self):
        result = _parse_options(("INVALID_NO_EQUALS",))
        assert "INVALID_NO_EQUALS" not in result

    def test_multiple_equals_in_value(self):
        result = _parse_options(("KEY=val=ue",))
        assert result["KEY"] == "val=ue"


class TestMakeMsfClient:
    def test_returns_msf_client(self):
        from msf_ot.rpc_client import MsfClient
        client = _make_msf_client("127.0.0.1", 55553, "pass", False)
        assert isinstance(client, MsfClient)

    def test_uses_config_password_when_empty(self):
        from msf_ot.rpc_client import MsfClient
        client = _make_msf_client("127.0.0.1", 55553, "", False)
        assert isinstance(client, MsfClient)
        assert client.password == "testpassword123"


# ══════════════════════════════════════════════════════════════════════════════
# الأمر: --help
# ══════════════════════════════════════════════════════════════════════════════

class TestCLIHelp:
    def test_main_help(self, runner):
        result = runner.invoke(cli, ["--help"], obj={})
        assert result.exit_code == 0
        assert "scan" in result.output.lower() or "OT" in result.output

    def test_scan_help(self, runner):
        result = runner.invoke(cli, ["scan", "--help"], obj={})
        assert result.exit_code == 0
        assert "TARGET" in result.output or "target" in result.output.lower()

    def test_modules_help(self, runner):
        result = runner.invoke(cli, ["modules", "--help"], obj={})
        assert result.exit_code == 0

    def test_status_help(self, runner):
        result = runner.invoke(cli, ["status", "--help"], obj={})
        assert result.exit_code == 0

    def test_multiscan_help(self, runner):
        result = runner.invoke(cli, ["multiscan", "--help"], obj={})
        assert result.exit_code == 0

    def test_config_help(self, runner):
        result = runner.invoke(cli, ["config", "--help"], obj={})
        assert result.exit_code == 0

    def test_version_flag(self, runner):
        result = runner.invoke(cli, ["--version"], obj={})
        assert result.exit_code == 0
        assert "1.0.0" in result.output


# ══════════════════════════════════════════════════════════════════════════════
# الأمر: modules
# ══════════════════════════════════════════════════════════════════════════════

class TestModulesCommand:
    def test_shows_all_modules(self, runner):
        result = runner.invoke(cli, ["--no-banner", "modules"], obj={})
        assert result.exit_code == 0
        assert "portscan" in result.output

    def test_filter_by_keyword(self, runner):
        result = runner.invoke(cli, ["--no-banner", "modules", "--filter", "scada"], obj={})
        assert result.exit_code == 0
        assert "scada" in result.output

    def test_filter_no_results(self, runner):
        result = runner.invoke(cli, ["--no-banner", "modules", "--filter", "xyznotexist"], obj={})
        assert result.exit_code == 0
        assert "لا توجد" in result.output or "no" in result.output.lower()

    def test_category_filter(self, runner):
        result = runner.invoke(cli, ["--no-banner", "modules", "--category", "portscan"], obj={})
        assert result.exit_code == 0
        assert "portscan" in result.output

    def test_category_not_found(self, runner):
        result = runner.invoke(cli, ["--no-banner", "modules", "--category", "nonexistent"], obj={})
        assert result.exit_code == 0
        assert "لا توجد" in result.output or "الفئات" in result.output

    def test_ot_only_flag(self, runner):
        result = runner.invoke(cli, ["--no-banner", "modules", "--ot-only"], obj={})
        assert result.exit_code == 0
        assert "scada" in result.output or "snmp" in result.output

    def test_shows_categories(self, runner):
        result = runner.invoke(cli, ["--no-banner", "modules"], obj={})
        assert result.exit_code == 0
        assert "Categories" in result.output or "portscan" in result.output


# ══════════════════════════════════════════════════════════════════════════════
# الأمر: config
# ══════════════════════════════════════════════════════════════════════════════

class TestConfigCommand:
    def test_shows_config_table(self, runner):
        result = runner.invoke(cli, ["--no-banner", "config"], obj={})
        assert result.exit_code == 0
        assert "MSF Host" in result.output or "127.0.0.1" in result.output

    def test_shows_dry_run_status(self, runner):
        result = runner.invoke(cli, ["--no-banner", "config"], obj={})
        assert result.exit_code == 0
        assert "Dry" in result.output or "DRY" in result.output or "True" in result.output

    def test_shows_password_set(self, runner):
        result = runner.invoke(cli, ["--no-banner", "config"], obj={})
        assert result.exit_code == 0
        assert "Password" in result.output or "YES" in result.output

    def test_show_ranges_flag(self, runner):
        result = runner.invoke(cli, ["--no-banner", "config", "--show-ranges"], obj={})
        assert result.exit_code == 0
        assert "Blacklisted" in result.output or "Allowed" in result.output

    def test_shows_allowed_modules_count(self, runner):
        result = runner.invoke(cli, ["--no-banner", "config"], obj={})
        assert result.exit_code == 0
        assert "Allowed Modules" in result.output or "modules" in result.output.lower()


# ══════════════════════════════════════════════════════════════════════════════
# الأمر: status
# ══════════════════════════════════════════════════════════════════════════════

class TestStatusCommand:
    def test_status_success(self, runner):
        mock_msf = make_mock_msf()
        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf):
            result = runner.invoke(cli, ["--no-banner", "status"], obj={})
        assert result.exit_code == 0
        assert "6.3.0" in result.output or "Connected" in result.output

    def test_status_rpc_error(self, runner):
        mock_msf = MagicMock()
        mock_msf.__enter__ = MagicMock(side_effect=MetasploitRPCError("Connection refused"))
        mock_msf.__exit__  = MagicMock(return_value=False)
        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf):
            result = runner.invoke(cli, ["--no-banner", "status"], obj={})
        assert result.exit_code == 1

    def test_status_auth_error(self, runner):
        mock_msf = MagicMock()
        mock_msf.__enter__ = MagicMock(side_effect=AuthenticationError("Bad password"))
        mock_msf.__exit__  = MagicMock(return_value=False)
        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf):
            result = runner.invoke(cli, ["--no-banner", "status"], obj={})
        assert result.exit_code == 1

    def test_status_shows_db_tip_when_not_connected(self, runner):
        mock_msf = make_mock_msf()
        mock_msf.health_check.return_value["db_connected"] = False
        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf):
            result = runner.invoke(cli, ["--no-banner", "status"], obj={})
        assert result.exit_code == 0
        assert "PostgreSQL" in result.output or "database" in result.output.lower() or "Tip" in result.output


# ══════════════════════════════════════════════════════════════════════════════
# الأمر: scan
# ══════════════════════════════════════════════════════════════════════════════

class TestScanCommand:
    def test_scan_dry_run_success(self, runner):
        mock_msf = make_mock_msf()
        dry_result = make_dry_run_result()
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = dry_result

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf), \
             patch("msf_ot.cli.OTScanner", return_value=mock_scanner):
            result = runner.invoke(
                cli,
                ["--no-banner", "scan", "192.168.1.1"],
                obj={},
            )
        assert result.exit_code == 0

    def test_scan_shows_configuration(self, runner):
        mock_msf = make_mock_msf()
        dry_result = make_dry_run_result()
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = dry_result

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf), \
             patch("msf_ot.cli.OTScanner", return_value=mock_scanner):
            result = runner.invoke(
                cli,
                ["--no-banner", "scan", "192.168.1.1"],
                obj={},
            )
        assert "192.168.1.1" in result.output
        assert "Scan Configuration" in result.output or "Target" in result.output

    def test_scan_with_module_option(self, runner):
        mock_msf = make_mock_msf()
        dry_result = make_dry_run_result(module="auxiliary/scanner/snmp/snmp_enum")
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = dry_result

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf), \
             patch("msf_ot.cli.OTScanner", return_value=mock_scanner):
            result = runner.invoke(
                cli,
                ["--no-banner", "scan", "192.168.1.1",
                 "-m", "auxiliary/scanner/snmp/snmp_enum"],
                obj={},
            )
        assert result.exit_code == 0
        # تحقق أن الـ module الصحيح استُخدم
        call_kwargs = mock_scanner.scan.call_args
        assert call_kwargs[1]["module_path"] == "auxiliary/scanner/snmp/snmp_enum"

    def test_scan_with_ports_option(self, runner):
        mock_msf = make_mock_msf()
        dry_result = make_dry_run_result()
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = dry_result

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf), \
             patch("msf_ot.cli.OTScanner", return_value=mock_scanner):
            result = runner.invoke(
                cli,
                ["--no-banner", "scan", "192.168.1.1", "-p", "80,443,502"],
                obj={},
            )
        assert result.exit_code == 0
        call_kwargs = mock_scanner.scan.call_args
        assert call_kwargs[1]["ports"] == "80,443,502"

    def test_scan_with_threads_option(self, runner):
        mock_msf = make_mock_msf()
        dry_result = make_dry_run_result()
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = dry_result

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf), \
             patch("msf_ot.cli.OTScanner", return_value=mock_scanner):
            result = runner.invoke(
                cli,
                ["--no-banner", "scan", "192.168.1.1", "-t", "3"],
                obj={},
            )
        assert result.exit_code == 0
        call_kwargs = mock_scanner.scan.call_args
        assert call_kwargs[1]["threads"] == 3

    def test_scan_with_extra_options(self, runner):
        mock_msf = make_mock_msf()
        dry_result = make_dry_run_result()
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = dry_result

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf), \
             patch("msf_ot.cli.OTScanner", return_value=mock_scanner):
            result = runner.invoke(
                cli,
                ["--no-banner", "scan", "192.168.1.1",
                 "-o", "TIMEOUT=10", "-o", "VERBOSE=true"],
                obj={},
            )
        assert result.exit_code == 0
        call_kwargs = mock_scanner.scan.call_args
        opts = call_kwargs[1].get("options", {})
        assert opts.get("TIMEOUT") == "10"
        assert opts.get("VERBOSE") == "true"

    def test_scan_rpc_error_exits_1(self, runner):
        mock_msf = MagicMock()
        mock_msf.__enter__ = MagicMock(side_effect=MetasploitRPCError("refused"))
        mock_msf.__exit__  = MagicMock(return_value=False)

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf):
            result = runner.invoke(
                cli,
                ["--no-banner", "scan", "192.168.1.1"],
                obj={},
            )
        assert result.exit_code == 1

    def test_scan_blocked_exits_1(self, runner):
        mock_msf = make_mock_msf()
        blocked_result = make_blocked_result()
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = blocked_result

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf), \
             patch("msf_ot.cli.OTScanner", return_value=mock_scanner):
            result = runner.invoke(
                cli,
                ["--no-banner", "scan", "192.168.1.1"],
                obj={},
            )
        assert result.exit_code == 1

    def test_scan_no_export_in_dry_run(self, runner, tmp_path):
        mock_msf = make_mock_msf()
        dry_result = make_dry_run_result()
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = dry_result

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf), \
             patch("msf_ot.cli.OTScanner", return_value=mock_scanner):
            result = runner.invoke(
                cli,
                ["--no-banner", "scan", "192.168.1.1",
                 "--export-json", "--output-dir", str(tmp_path)],
                obj={},
            )
        assert result.exit_code == 0
        # لا يجب أن يُنشئ ملف JSON في وضع Dry-Run
        json_files = list(tmp_path.glob("*.json"))
        assert len(json_files) == 0

    def test_scan_missing_target_shows_error(self, runner):
        result = runner.invoke(cli, ["--no-banner", "scan"], obj={})
        assert result.exit_code != 0


# ══════════════════════════════════════════════════════════════════════════════
# الأمر: multiscan
# ══════════════════════════════════════════════════════════════════════════════

class TestMultiscanCommand:
    def test_multiscan_with_preset_scada(self, runner):
        mock_msf = make_mock_msf()
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = make_dry_run_result()

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf), \
             patch("msf_ot.cli.OTScanner", return_value=mock_scanner):
            result = runner.invoke(
                cli,
                ["--no-banner", "multiscan", "192.168.1.1", "--preset", "scada"],
                obj={},
            )
        assert result.exit_code == 0
        # يجب أن يُشغّل عدة modules
        assert mock_scanner.scan.call_count >= 2

    def test_multiscan_with_preset_full(self, runner):
        mock_msf = make_mock_msf()
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = make_dry_run_result()

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf), \
             patch("msf_ot.cli.OTScanner", return_value=mock_scanner):
            result = runner.invoke(
                cli,
                ["--no-banner", "multiscan", "192.168.1.1", "--preset", "full"],
                obj={},
            )
        assert result.exit_code == 0
        assert mock_scanner.scan.call_count >= 4

    def test_multiscan_with_custom_modules(self, runner):
        mock_msf = make_mock_msf()
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = make_dry_run_result()

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf), \
             patch("msf_ot.cli.OTScanner", return_value=mock_scanner):
            result = runner.invoke(
                cli,
                ["--no-banner", "multiscan", "192.168.1.1",
                 "-m", "auxiliary/scanner/portscan/tcp",
                 "-m", "auxiliary/scanner/snmp/snmp_enum"],
                obj={},
            )
        assert result.exit_code == 0
        assert mock_scanner.scan.call_count == 2

    def test_multiscan_no_modules_exits_1(self, runner):
        result = runner.invoke(
            cli,
            ["--no-banner", "multiscan", "192.168.1.1"],
            obj={},
        )
        assert result.exit_code == 1

    def test_multiscan_stops_on_blocked(self, runner):
        mock_msf = make_mock_msf()
        mock_scanner = MagicMock()
        # الـ module الأول يُحظر
        mock_scanner.scan.return_value = make_blocked_result()

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf), \
             patch("msf_ot.cli.OTScanner", return_value=mock_scanner):
            result = runner.invoke(
                cli,
                ["--no-banner", "multiscan", "192.168.1.1", "--preset", "scada"],
                obj={},
            )
        # يجب أن يتوقف بعد أول blocked
        assert mock_scanner.scan.call_count == 1

    def test_multiscan_shows_summary_dashboard(self, runner):
        mock_msf = make_mock_msf()
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = make_dry_run_result()

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf), \
             patch("msf_ot.cli.OTScanner", return_value=mock_scanner):
            result = runner.invoke(
                cli,
                ["--no-banner", "multiscan", "192.168.1.1", "--preset", "snmp"],
                obj={},
            )
        assert result.exit_code == 0
        assert "Dashboard" in result.output or "Summary" in result.output

    def test_multiscan_rpc_error_exits_1(self, runner):
        mock_msf = MagicMock()
        mock_msf.__enter__ = MagicMock(side_effect=MetasploitRPCError("refused"))
        mock_msf.__exit__  = MagicMock(return_value=False)

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf):
            result = runner.invoke(
                cli,
                ["--no-banner", "multiscan", "192.168.1.1", "--preset", "scada"],
                obj={},
            )
        assert result.exit_code == 1

    def test_multiscan_missing_target_exits_error(self, runner):
        result = runner.invoke(
            cli,
            ["--no-banner", "multiscan", "--preset", "scada"],
            obj={},
        )
        assert result.exit_code != 0


# ══════════════════════════════════════════════════════════════════════════════
# اختبارات تكاملية
# ══════════════════════════════════════════════════════════════════════════════

class TestCLIIntegration:
    def test_no_banner_flag_suppresses_banner(self, runner):
        result = runner.invoke(cli, ["--no-banner", "modules"], obj={})
        assert result.exit_code == 0
        assert "MSF-OT" not in result.output or "Scanner" not in result.output

    def test_verbose_flag_accepted(self, runner):
        mock_msf = make_mock_msf()
        dry_result = make_dry_run_result()
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = dry_result

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf), \
             patch("msf_ot.cli.OTScanner", return_value=mock_scanner):
            result = runner.invoke(
                cli,
                ["--no-banner", "--verbose", "scan", "192.168.1.1"],
                obj={},
            )
        assert result.exit_code == 0

    def test_all_commands_registered(self, runner):
        result = runner.invoke(cli, ["--help"], obj={})
        for cmd in ["scan", "multiscan", "modules", "status", "config"]:
            assert cmd in result.output

    def test_scan_cidr_target_accepted(self, runner):
        mock_msf = make_mock_msf()
        dry_result = make_dry_run_result(target="192.168.1.0/24")
        mock_scanner = MagicMock()
        mock_scanner.scan.return_value = dry_result

        with patch("msf_ot.cli._make_msf_client", return_value=mock_msf), \
             patch("msf_ot.cli.OTScanner", return_value=mock_scanner):
            result = runner.invoke(
                cli,
                ["--no-banner", "scan", "192.168.1.0/24"],
                obj={},
            )
        assert result.exit_code == 0
        call_kwargs = mock_scanner.scan.call_args
        assert call_kwargs[1]["target"] == "192.168.1.0/24"
